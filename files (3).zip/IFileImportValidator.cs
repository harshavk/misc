using HRSCWinService.BusinessEntities;
using HRSCWinService.Models;

namespace HRSCWinService.BusinessInterfaces;

public interface IFileImportValidator
{
    ValidationResult ValidateEmpIdFormat(FileImportCsvRow row);

    Task<ValidationResult> ValidateEmpIdExistsAsync(FileImportCsvRow row);

    Task<ValidationResult> ValidateNationalIdAsync(FileImportCsvRow row);

    ValidationResult ValidateFileNameLength(FileImportCsvRow row);

    ValidationResult ValidateFileNameChars(FileImportCsvRow row);

    ValidationResult ValidateFileNameLeadingSpace(FileImportCsvRow row);

    Task<ValidationResult> ValidateFileExistsAsync(FileImportCsvRow row, string deptBasePath);

    Task<ValidationResult> ValidateFileMimeTypeAsync(FileImportCsvRow row, string deptBasePath);

    Task<ValidationResult> ValidateFileSizeAsync(FileImportCsvRow row, string deptBasePath);

    ValidationResult ValidateDisallowedFileType(FileImportCsvRow row);

    ValidationResult ValidateCountryFormat(FileImportCsvRow row);

    Task<ValidationResult> ValidateCountryLookupAsync(FileImportCsvRow row);

    Task<ValidationResult> ValidateCountryMappingAsync(FileImportCsvRow row);

    Task<ValidationResult> ValidateDeptAsync(FileImportCsvRow row);

    Task<ValidationResult> ValidateBarcodeAsync(FileImportCsvRow row);

    ValidationResult ValidateEffectiveDate(FileImportCsvRow row);
}
