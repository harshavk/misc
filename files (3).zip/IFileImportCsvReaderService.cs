using HRSCWinService.BusinessEntities;

namespace HRSCWinService.ServiceInterfaces;

public interface IFileImportCsvReaderService
{
    /// <summary>
    /// Detects the CSV format by matching header row against appSettings definitions.
    /// Returns the matched format name e.g. "BulkIngestion" or "BGCheck".
    /// Returns null if no format matches — caller should fail the job.
    /// </summary>
    Task<string?> DetectFormatAsync(string filePath);

    /// <summary>
    /// Reads the CSV at filePath, normalizes each row using the FieldMap
    /// for the given formatName, and streams FileImportCsvRow one at a time.
    /// </summary>
    IAsyncEnumerable<FileImportCsvRow> ReadRowsAsync(string filePath, string formatName);
}
