namespace HRSCWinService.BusinessEntities;

/// <summary>
/// Format-agnostic normalized CSV row.
/// CsvReaderService maps any format into this model via appSettings FieldMap.
/// Validator and IngestionJob always work on this — never on raw CSV columns.
/// </summary>
public class FileImportCsvRow
{
    public int RowNumber { get; set; }

    public string? EmpId { get; set; }
    public string? NationalId { get; set; }
    public string? NationalIdType { get; set; }
    public string? FileName { get; set; }
    public string? EffectiveDate { get; set; }
    public string? Barcode { get; set; }
    public string? Dept { get; set; }
    public string? Country { get; set; }
    public string? CaseId { get; set; }
    public string? AppId { get; set; }
    public string? WorkdayAppId { get; set; }

    /// <summary>
    /// Original CSV row serialized as JSON Dictionary&lt;string, string&gt;.
    /// Stored on FileImportJobError.RawRowJson — preserves original column names
    /// regardless of format. Used for error report download.
    /// </summary>
    public string RawJson { get; set; } = string.Empty;
}
