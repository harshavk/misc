// ─────────────────────────────────────────────────────────────────────────────
// ADD to HRSCWinService/Injections/ApplicationInjections.cs
// ─────────────────────────────────────────────────────────────────────────────

// 1. Bind FileImportFormats config section
//    appsettings.json must have a "FileImportFormats" root key
//    with BulkIngestion and BGCheck definitions as defined in appsettings_additions.json
services.AddOptions<FileImportFormatConfig>()
    .Bind(configuration.GetSection(nameof(FileImportFormatConfig)));

// 2. Repository (Common/DataAccess)
services.AddScoped<IFileImportJobRepository, FileImportJobRepository>();

// 3. CSV reader service
services.AddScoped<IFileImportCsvReaderService, FileImportCsvReaderService>();

// 4. Validator — all 16 rules
services.AddScoped<IFileImportValidator, FileImportValidator>();

// 5. Background job
services.AddHostedService<FileImportValidationJob>();

// ─────────────────────────────────────────────────────────────────────────────
// ALSO ADD to Web project's DI (Program.cs or WebInjections.cs)
// so the controller can resolve IFileImportJobRepository
// ─────────────────────────────────────────────────────────────────────────────
services.AddScoped<IFileImportJobRepository, FileImportJobRepository>();
