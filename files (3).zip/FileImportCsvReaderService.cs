using Common.Configuration;
using CsvHelper;
using CsvHelper.Configuration;
using HRSCWinService.BusinessEntities;
using HRSCWinService.ServiceInterfaces;
using Microsoft.Extensions.Options;
using System.Globalization;
using System.Runtime.CompilerServices;
using System.Text.Json;

namespace HRSCWinService.Services;

public class FileImportCsvReaderService : IFileImportCsvReaderService
{
    private readonly FileImportFormatConfig _formatConfig;

    public FileImportCsvReaderService(IOptions<FileImportFormatConfig> formatConfig)
    {
        _formatConfig = formatConfig.Value;
    }

    public async Task<string?> DetectFormatAsync(string filePath)
    {
        string[] headers = await ReadHeadersAsync(filePath);

        foreach (KeyValuePair<string, FileImportFormatDefinition> format
                 in _formatConfig.FileImportFormats)
        {
            if (HeadersMatch(headers, format.Value.Headers))
            {
                return format.Key;
            }
        }

        return null;
    }

    public async IAsyncEnumerable<FileImportCsvRow> ReadRowsAsync(
        string filePath,
        string formatName,
        [EnumeratorCancellation] CancellationToken cancellationToken = default)
    {
        FileImportFormatDefinition formatDef = GetFormatDefinition(formatName);

        CsvConfiguration config = BuildCsvConfiguration();

        using StreamReader reader = new(filePath);
        using CsvReader csv = new(reader, config);

        await csv.ReadAsync();
        csv.ReadHeader();

        int rowNumber = 1;

        while (await csv.ReadAsync())
        {
            if (cancellationToken.IsCancellationRequested)
            {
                yield break;
            }

            Dictionary<string, string> rawDict = BuildRawDictionary(csv);
            FileImportCsvRow row = NormalizeRow(rawDict, formatDef.FieldMap, rowNumber);

            yield return row;
            rowNumber++;
        }
    }

    // ── private helpers ───────────────────────────────────────────────────

    private async Task<string[]> ReadHeadersAsync(string filePath)
    {
        CsvConfiguration config = BuildCsvConfiguration();

        using StreamReader reader = new(filePath);
        using CsvReader csv = new(reader, config);

        await csv.ReadAsync();
        csv.ReadHeader();

        return csv.HeaderRecord ?? [];
    }

    private static bool HeadersMatch(
        string[] actualHeaders,
        List<string> expectedHeaders)
    {
        if (actualHeaders.Length == 0)
        {
            return false;
        }

        HashSet<string> actual = actualHeaders
            .Select(h => h.Trim().ToLowerInvariant())
            .ToHashSet();

        return expectedHeaders.All(
            expected => actual.Contains(expected.Trim().ToLowerInvariant()));
    }

    private FileImportFormatDefinition GetFormatDefinition(string formatName)
    {
        if (!_formatConfig.FileImportFormats.TryGetValue(
                formatName,
                out FileImportFormatDefinition? definition))
        {
            throw new InvalidOperationException(
                $"Format '{formatName}' not found in configuration.");
        }

        return definition;
    }

    private static CsvConfiguration BuildCsvConfiguration()
    {
        return new CsvConfiguration(CultureInfo.InvariantCulture)
        {
            HasHeaderRecord     = true,
            MissingFieldFound   = null,
            HeaderValidated     = null,
            TrimOptions         = TrimOptions.Trim,
            BadDataFound        = null
        };
    }

    private static Dictionary<string, string> BuildRawDictionary(CsvReader csv)
    {
        Dictionary<string, string> dict = new(StringComparer.OrdinalIgnoreCase);

        if (csv.HeaderRecord is null)
        {
            return dict;
        }

        foreach (string header in csv.HeaderRecord)
        {
            string value = csv.GetField(header) ?? string.Empty;
            dict[header] = value;
        }

        return dict;
    }

    private static FileImportCsvRow NormalizeRow(
        Dictionary<string, string> rawDict,
        Dictionary<string, string> fieldMap,
        int rowNumber)
    {
        string rawJson = JsonSerializer.Serialize(rawDict);

        return new FileImportCsvRow
        {
            RowNumber      = rowNumber,
            EmpId          = GetMappedValue(rawDict, fieldMap, "EmpId"),
            NationalId     = GetMappedValue(rawDict, fieldMap, "NationalId"),
            NationalIdType = GetMappedValue(rawDict, fieldMap, "NationalIdType"),
            FileName       = GetMappedValue(rawDict, fieldMap, "FileName"),
            EffectiveDate  = GetMappedValue(rawDict, fieldMap, "EffectiveDate"),
            Barcode        = GetMappedValue(rawDict, fieldMap, "Barcode"),
            Dept           = GetMappedValue(rawDict, fieldMap, "Dept"),
            Country        = GetMappedValue(rawDict, fieldMap, "Country"),
            CaseId         = GetMappedValue(rawDict, fieldMap, "CaseId"),
            AppId          = GetMappedValue(rawDict, fieldMap, "AppId"),
            WorkdayAppId   = GetMappedValue(rawDict, fieldMap, "WorkdayAppId"),
            RawJson        = rawJson
        };
    }

    private static string? GetMappedValue(
        Dictionary<string, string> rawDict,
        Dictionary<string, string> fieldMap,
        string domainField)
    {
        if (!fieldMap.TryGetValue(domainField, out string? csvColumn))
        {
            return null;
        }

        if (!rawDict.TryGetValue(csvColumn, out string? value))
        {
            return null;
        }

        string trimmed = value.Trim();

        return string.IsNullOrEmpty(trimmed) ? null : trimmed;
    }
}
