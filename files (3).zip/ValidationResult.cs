using Common.Enums;

namespace HRSCWinService.Models;

public class ValidationResult
{
    public bool IsValid { get; private set; }
    public FileImportErrorType? ErrorType { get; private set; }
    public string? ErrorMessage { get; private set; }

    private ValidationResult() { }

    public static ValidationResult Ok()
    {
        return new ValidationResult { IsValid = true };
    }

    public static ValidationResult Fail(
        FileImportErrorType errorType,
        string errorMessage)
    {
        return new ValidationResult
        {
            IsValid      = false,
            ErrorType    = errorType,
            ErrorMessage = errorMessage
        };
    }
}
