using Common.DataAccess;
using Common.EntityFramework.Models;
using Common.Enums;
using HRSCWinService.BusinessEntities;
using HRSCWinService.BusinessInterfaces;
using HRSCWinService.Models;
using HRSCWinService.ServiceInterfaces;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace HRSCWinService.BusinessLogic;

public class FileImportValidationJob : BackgroundService
{
    private readonly ILogger<FileImportValidationJob> _logger;
    private readonly IServiceProvider _serviceProvider;
    private readonly TimeSpan _interval = TimeSpan.FromMinutes(1);

    public FileImportValidationJob(
          ILogger<FileImportValidationJob> logger
        , IServiceProvider serviceProvider)
    {
        _logger          = logger;
        _serviceProvider = serviceProvider;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("FileImportValidationJob started.");

        using PeriodicTimer timer = new(_interval);

        while (await timer.WaitForNextTickAsync(stoppingToken))
        {
            await RunCycleAsync(stoppingToken);
        }

        _logger.LogInformation("FileImportValidationJob stopped.");
    }

    // ── cycle ─────────────────────────────────────────────────────────────

    private async Task RunCycleAsync(CancellationToken stoppingToken)
    {
        try
        {
            using IServiceScope scope = _serviceProvider.CreateScope();
            await ProcessPendingJobAsync(scope, stoppingToken);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "FileImportValidationJob cycle failed.");
        }
    }

    private async Task ProcessPendingJobAsync(
        IServiceScope scope,
        CancellationToken stoppingToken)
    {
        IFileImportJobRepository repo = scope.ServiceProvider
            .GetRequiredService<IFileImportJobRepository>();

        FileImportJob? job = await repo.GetPendingValidationJobAsync();

        if (job is null)
        {
            return;
        }

        _logger.LogInformation(
            "FileImportValidationJob processing job {JobId} — {FileName}.",
            job.Id, job.FileName);

        await ProcessSingleJobAsync(scope, repo, job, stoppingToken);
    }

    private async Task ProcessSingleJobAsync(
        IServiceScope scope,
        IFileImportJobRepository repo,
        FileImportJob job,
        CancellationToken stoppingToken)
    {
        await repo.UpdateJobStartedAsync(job.Id);

        IFileImportCsvReaderService csvReader = scope.ServiceProvider
            .GetRequiredService<IFileImportCsvReaderService>();

        string? formatName = await DetectFormatAsync(repo, csvReader, job);

        if (formatName is null)
        {
            return;
        }

        await ValidateAllRowsAsync(scope, repo, csvReader, job, formatName, stoppingToken);
    }

    private async Task<string?> DetectFormatAsync(
        IFileImportJobRepository repo,
        IFileImportCsvReaderService csvReader,
        FileImportJob job)
    {
        string? formatName = await csvReader.DetectFormatAsync(job.SavedFilePath);

        if (formatName is null)
        {
            await repo.UpdateJobFailedAsync(
                job.Id,
                "Could not detect CSV format — headers did not match any configured format.");

            _logger.LogWarning(
                "FileImportValidationJob job {JobId} — format detection failed.", job.Id);
        }

        return formatName;
    }

    private async Task ValidateAllRowsAsync(
        IServiceScope scope,
        IFileImportJobRepository repo,
        IFileImportCsvReaderService csvReader,
        FileImportJob job,
        string formatName,
        CancellationToken stoppingToken)
    {
        IFileImportValidator validator = scope.ServiceProvider
            .GetRequiredService<IFileImportValidator>();

        string deptBasePath = ResolveDeptBasePath(job.Department);

        int totalRows = 0;
        int errorRows = 0;
        List<FileImportJobError> errorBatch = [];

        await foreach (FileImportCsvRow row
                       in csvReader.ReadRowsAsync(job.SavedFilePath, formatName)
                                   .WithCancellation(stoppingToken))
        {
            totalRows++;

            List<ValidationResult> failures =
                await RunAllValidationsAsync(validator, row, deptBasePath);

            if (failures.Count > 0)
            {
                errorRows++;
                AddErrorsToList(errorBatch, job.Id, row, failures);
            }

            if (errorBatch.Count >= 500)
            {
                await FlushErrorBatchAsync(repo, errorBatch);
            }
        }

        if (errorBatch.Count > 0)
        {
            await FlushErrorBatchAsync(repo, errorBatch);
        }

        int validRows = totalRows - errorRows;

        await repo.UpdateJobCompletedAsync(
            job.Id,
            FileImportStatus.Validated,
            totalRows,
            validRows,
            errorRows);

        _logger.LogInformation(
            "FileImportValidationJob job {JobId} complete. "
          + "Total: {Total}, Valid: {Valid}, Errors: {Errors}.",
            job.Id, totalRows, validRows, errorRows);
    }

    private static async Task<List<ValidationResult>> RunAllValidationsAsync(
        IFileImportValidator validator,
        FileImportCsvRow row,
        string deptBasePath)
    {
        List<ValidationResult> results =
        [
            validator.ValidateEmpIdFormat(row),
            await validator.ValidateEmpIdExistsAsync(row),
            await validator.ValidateNationalIdAsync(row),
            validator.ValidateFileNameLength(row),
            validator.ValidateFileNameChars(row),
            validator.ValidateFileNameLeadingSpace(row),
            validator.ValidateDisallowedFileType(row),
            await validator.ValidateFileExistsAsync(row, deptBasePath),
            await validator.ValidateFileMimeTypeAsync(row, deptBasePath),
            await validator.ValidateFileSizeAsync(row, deptBasePath),
            validator.ValidateCountryFormat(row),
            await validator.ValidateCountryLookupAsync(row),
            await validator.ValidateCountryMappingAsync(row),
            await validator.ValidateDeptAsync(row),
            await validator.ValidateBarcodeAsync(row),
            validator.ValidateEffectiveDate(row)
        ];

        return results.Where(r => !r.IsValid).ToList();
    }

    private static void AddErrorsToList(
        List<FileImportJobError> errorBatch,
        int jobId,
        FileImportCsvRow row,
        List<ValidationResult> failures)
    {
        foreach (ValidationResult failure in failures)
        {
            errorBatch.Add(BuildJobError(jobId, row, failure));
        }
    }

    private static FileImportJobError BuildJobError(
        int jobId,
        FileImportCsvRow row,
        ValidationResult failure)
    {
        return new FileImportJobError
        {
            FileImportJobId = jobId,
            RowNumber       = row.RowNumber,
            RawRowJson      = row.RawJson,
            ErrorType       = failure.ErrorType!.Value,
            ErrorMessage    = failure.ErrorMessage ?? string.Empty,
            CreatedAt       = DateTime.UtcNow
        };
    }

    private static async Task FlushErrorBatchAsync(
        IFileImportJobRepository repo,
        List<FileImportJobError> errorBatch)
    {
        await repo.InsertErrorsAsync(errorBatch);
        errorBatch.Clear();
    }

    private static string ResolveDeptBasePath(string department)
    {
        // TODO: inject IDeptPathResolver or read from appSettings
        // Placeholder — returns dept-specific NetApp base path
        return Path.Combine(@"\\netapp\vstar\documents", department);
    }
}
