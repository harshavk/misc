using Common.DataAccess;
using Common.Enums;
using Common.FileStorage;
using HRSCWinService.BusinessEntities;
using HRSCWinService.BusinessInterfaces;
using HRSCWinService.Models;
using System.Text.RegularExpressions;

namespace HRSCWinService.Services;

public class FileImportValidator : IFileImportValidator
{
    private readonly IHrRosterRepository _hrRosterRepository;
    private readonly ICountryLookupRepository _countryLookupRepository;
    private readonly ICountryMappingRepository _countryMappingRepository;
    private readonly IDeptRepository _deptRepository;
    private readonly IBarcodeRepository _barcodeRepository;
    private readonly IFileStorageService _fileStorageService;

    private static readonly int EmpIdLength = 11;
    private static readonly int FileNameMaxLength = 99;

    private static readonly HashSet<string> AllowedMimeTypes =
    [
        "application/pdf",
        "image/tiff",
        "image/jpeg"
    ];

    private static readonly HashSet<string> DisallowedExtensions =
    [
        ".zip", ".rar", ".msg", ".html", ".htm",
        ".bat", ".cmd", ".sh", ".ps1", ".sql",
        ".js",  ".vbs", ".exe", ".dll"
    ];

    private static readonly Regex InvalidFileNameChars =
        new(@"[<>:""/\\|?*]", RegexOptions.Compiled);

    public FileImportValidator(
          IHrRosterRepository hrRosterRepository
        , ICountryLookupRepository countryLookupRepository
        , ICountryMappingRepository countryMappingRepository
        , IDeptRepository deptRepository
        , IBarcodeRepository barcodeRepository
        , IFileStorageService fileStorageService)
    {
        _hrRosterRepository      = hrRosterRepository;
        _countryLookupRepository = countryLookupRepository;
        _countryMappingRepository = countryMappingRepository;
        _deptRepository          = deptRepository;
        _barcodeRepository       = barcodeRepository;
        _fileStorageService      = fileStorageService;
    }

    // ── EmpId ─────────────────────────────────────────────────────────────

    public ValidationResult ValidateEmpIdFormat(FileImportCsvRow row)
    {
        if (string.IsNullOrWhiteSpace(row.EmpId))
        {
            return ValidationResult.Ok();
        }

        bool isValid = row.EmpId.Length == EmpIdLength
                    && row.EmpId.All(char.IsDigit);

        if (!isValid)
        {
            return ValidationResult.Fail(
                FileImportErrorType.InvalidEmpIdFormat,
                $"EmpId '{row.EmpId}' must be exactly {EmpIdLength} digits.");
        }

        return ValidationResult.Ok();
    }

    public async Task<ValidationResult> ValidateEmpIdExistsAsync(FileImportCsvRow row)
    {
        if (string.IsNullOrWhiteSpace(row.EmpId))
        {
            return ValidationResult.Ok();
        }

        bool exists = await _hrRosterRepository.ExistsByEmpIdAsync(row.EmpId);

        if (!exists)
        {
            return ValidationResult.Fail(
                FileImportErrorType.EmpIdNotFound,
                $"EmpId '{row.EmpId}' was not found in the HR roster.");
        }

        return ValidationResult.Ok();
    }

    // ── NationalId ────────────────────────────────────────────────────────

    public async Task<ValidationResult> ValidateNationalIdAsync(FileImportCsvRow row)
    {
        bool empIdMissing = string.IsNullOrWhiteSpace(row.EmpId);

        if (empIdMissing && string.IsNullOrWhiteSpace(row.NationalId))
        {
            return ValidationResult.Fail(
                FileImportErrorType.NationalIdRequired,
                "NationalId is required when EmpId is not provided.");
        }

        if (string.IsNullOrWhiteSpace(row.NationalId))
        {
            return ValidationResult.Ok();
        }

        bool exists = await _hrRosterRepository.ExistsByNationalIdAsync(row.NationalId);

        if (!exists)
        {
            return ValidationResult.Fail(
                FileImportErrorType.NationalIdNotFound,
                $"NationalId '{row.NationalId}' was not found in the HR roster.");
        }

        return ValidationResult.Ok();
    }

    // ── FileName ──────────────────────────────────────────────────────────

    public ValidationResult ValidateFileNameLength(FileImportCsvRow row)
    {
        if (string.IsNullOrWhiteSpace(row.FileName))
        {
            return ValidationResult.Ok();
        }

        if (row.FileName.Length >= FileNameMaxLength)
        {
            return ValidationResult.Fail(
                FileImportErrorType.FileNameTooLong,
                $"File name must be less than {FileNameMaxLength} characters. "
              + $"Current length: {row.FileName.Length}.");
        }

        return ValidationResult.Ok();
    }

    public ValidationResult ValidateFileNameChars(FileImportCsvRow row)
    {
        if (string.IsNullOrWhiteSpace(row.FileName))
        {
            return ValidationResult.Ok();
        }

        if (InvalidFileNameChars.IsMatch(row.FileName))
        {
            return ValidationResult.Fail(
                FileImportErrorType.FileNameInvalidChars,
                $"File name '{row.FileName}' contains invalid characters "
              + @"(< > : "" / \ | ? * are not allowed).");
        }

        return ValidationResult.Ok();
    }

    public ValidationResult ValidateFileNameLeadingSpace(FileImportCsvRow row)
    {
        if (string.IsNullOrWhiteSpace(row.FileName))
        {
            return ValidationResult.Ok();
        }

        if (row.FileName.StartsWith(' '))
        {
            return ValidationResult.Fail(
                FileImportErrorType.FileNameLeadingSpace,
                $"File name '{row.FileName}' must not start with a leading space.");
        }

        return ValidationResult.Ok();
    }

    public ValidationResult ValidateDisallowedFileType(FileImportCsvRow row)
    {
        if (string.IsNullOrWhiteSpace(row.FileName))
        {
            return ValidationResult.Ok();
        }

        string extension = Path.GetExtension(row.FileName).ToLowerInvariant();

        if (DisallowedExtensions.Contains(extension))
        {
            return ValidationResult.Fail(
                FileImportErrorType.DisallowedFileType,
                $"File type '{extension}' is not allowed. "
              + "Accepted types: PDF, TIFF, JPEG.");
        }

        return ValidationResult.Ok();
    }

    // ── Physical file (NetApp) ────────────────────────────────────────────

    public async Task<ValidationResult> ValidateFileExistsAsync(
        FileImportCsvRow row,
        string deptBasePath)
    {
        if (string.IsNullOrWhiteSpace(row.FileName))
        {
            return ValidationResult.Ok();
        }

        string fullPath = BuildFilePath(deptBasePath, row.FileName);

        // NetAppService placeholder — replace body with actual call
        bool exists = await _fileStorageService.FileExistsAsync(fullPath);

        if (!exists)
        {
            return ValidationResult.Fail(
                FileImportErrorType.FileNotFound,
                $"File '{row.FileName}' was not found at the configured department path.");
        }

        return ValidationResult.Ok();
    }

    public async Task<ValidationResult> ValidateFileMimeTypeAsync(
        FileImportCsvRow row,
        string deptBasePath)
    {
        if (string.IsNullOrWhiteSpace(row.FileName))
        {
            return ValidationResult.Ok();
        }

        string fullPath = BuildFilePath(deptBasePath, row.FileName);

        // NetAppService placeholder — replace body with actual call
        string mimeType = await _fileStorageService.GetMimeTypeAsync(fullPath);

        if (!AllowedMimeTypes.Contains(mimeType.ToLowerInvariant()))
        {
            return ValidationResult.Fail(
                FileImportErrorType.InvalidMimeType,
                $"File '{row.FileName}' has MIME type '{mimeType}'. "
              + "Only PDF, TIFF, and JPEG are accepted.");
        }

        return ValidationResult.Ok();
    }

    public async Task<ValidationResult> ValidateFileSizeAsync(
        FileImportCsvRow row,
        string deptBasePath)
    {
        if (string.IsNullOrWhiteSpace(row.FileName))
        {
            return ValidationResult.Ok();
        }

        string fullPath = BuildFilePath(deptBasePath, row.FileName);

        // NetAppService placeholder — replace body with actual call
        long sizeBytes = await _fileStorageService.GetFileSizeAsync(fullPath);

        if (sizeBytes == 0)
        {
            return ValidationResult.Fail(
                FileImportErrorType.EmptyFile,
                $"File '{row.FileName}' is 0 KB and cannot be ingested.");
        }

        return ValidationResult.Ok();
    }

    // ── Country ───────────────────────────────────────────────────────────

    public ValidationResult ValidateCountryFormat(FileImportCsvRow row)
    {
        if (string.IsNullOrWhiteSpace(row.Country))
        {
            return ValidationResult.Ok();
        }

        if (row.Country.Length != 3)
        {
            return ValidationResult.Fail(
                FileImportErrorType.InvalidCountryFormat,
                $"Country '{row.Country}' must be exactly 3 characters.");
        }

        return ValidationResult.Ok();
    }

    public async Task<ValidationResult> ValidateCountryLookupAsync(FileImportCsvRow row)
    {
        if (string.IsNullOrWhiteSpace(row.Country))
        {
            return ValidationResult.Ok();
        }

        bool exists = await _countryLookupRepository.ExistsAsync(row.Country);

        if (!exists)
        {
            return ValidationResult.Fail(
                FileImportErrorType.CountryNotFound,
                $"Country '{row.Country}' was not found in Vstar.dbo.CountryLookups.");
        }

        return ValidationResult.Ok();
    }

    public async Task<ValidationResult> ValidateCountryMappingAsync(FileImportCsvRow row)
    {
        if (string.IsNullOrWhiteSpace(row.Country))
        {
            return ValidationResult.Ok();
        }

        bool isUsa = row.Country.Equals("USA", StringComparison.OrdinalIgnoreCase);

        if (isUsa)
        {
            return ValidationResult.Ok();
        }

        bool exists = await _countryMappingRepository.ExistsAsync(row.Country);

        if (!exists)
        {
            return ValidationResult.Fail(
                FileImportErrorType.CountryMappingNotFound,
                $"Country '{row.Country}' was not found in VstarHrds.dbo.CountryMappings.");
        }

        return ValidationResult.Ok();
    }

    // ── Dept ──────────────────────────────────────────────────────────────

    public async Task<ValidationResult> ValidateDeptAsync(FileImportCsvRow row)
    {
        if (string.IsNullOrWhiteSpace(row.Dept))
        {
            return ValidationResult.Ok();
        }

        bool isValid = await _deptRepository.IsValidDeptAsync(row.Dept);

        if (!isValid)
        {
            return ValidationResult.Fail(
                FileImportErrorType.InvalidDepartment,
                $"Department '{row.Dept}' is not a valid department.");
        }

        return ValidationResult.Ok();
    }

    // ── Barcode ───────────────────────────────────────────────────────────

    public async Task<ValidationResult> ValidateBarcodeAsync(FileImportCsvRow row)
    {
        if (string.IsNullOrWhiteSpace(row.Barcode))
        {
            return ValidationResult.Ok();
        }

        (bool exists, bool isActive) = await _barcodeRepository
            .GetBarcodeStatusAsync(row.Barcode);

        if (!exists)
        {
            return ValidationResult.Fail(
                FileImportErrorType.InvalidBarcode,
                $"Barcode '{row.Barcode}' does not exist.");
        }

        if (!isActive)
        {
            return ValidationResult.Fail(
                FileImportErrorType.InactiveBarcode,
                $"Barcode '{row.Barcode}' is inactive.");
        }

        return ValidationResult.Ok();
    }

    // ── EffectiveDate ─────────────────────────────────────────────────────

    public ValidationResult ValidateEffectiveDate(FileImportCsvRow row)
    {
        if (string.IsNullOrWhiteSpace(row.EffectiveDate))
        {
            return ValidationResult.Ok();
        }

        bool parsed = DateTime.TryParse(
            row.EffectiveDate,
            out DateTime effectiveDate);

        if (!parsed)
        {
            return ValidationResult.Ok();
        }

        if (effectiveDate.Date > DateTime.UtcNow.Date)
        {
            return ValidationResult.Fail(
                FileImportErrorType.FutureDateNotAllowed,
                $"Effective date '{row.EffectiveDate}' cannot be a future date.");
        }

        return ValidationResult.Ok();
    }

    // ── private helpers ───────────────────────────────────────────────────

    private static string BuildFilePath(string deptBasePath, string fileName)
    {
        return Path.Combine(deptBasePath, fileName);
    }
}
