import { Component, Input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { AnswerResult } from '../../models/ai-search.models';

@Component({
  selector: 'app-answer-result-card',
  standalone: true,
  imports: [CommonModule, MatCardModule, MatIconModule],
  templateUrl: './answer-result-card.component.html',
  styleUrls: ['./answer-result-card.component.scss'],
})
export class AnswerResultCardComponent {
  @Input() answer!: AnswerResult;
}
