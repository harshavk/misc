import { ThreadMessage } from './ai-thread.models';

export interface AiReference {
  id: string;
  title: string;
  url?: string;
  snippet?: string;
  sourceType?: 'doc' | 'kb' | 'email' | 'ticket' | 'other';
}

export interface AnswerResult {
  id: string;
  title: string;
  content: string;
  type: 'summary' | 'explanation' | 'faq' | 'steps';
  confidence: number; // 0–1
  tags: string[];
  isHtml: boolean;
  references: AiReference[];
}

export interface ActionResult {
  id: string;
  label: string;
  description: string;
  icon: string;
  category: 'cloud' | 'hr' | 'access' | 'email' | 'navigation' | 'link' | 'other';
  primary: boolean;
  confidence: number;
  payload?: Record<string, unknown>;
  requiresConfirmation?: boolean;
  confirmLabel?: string;
  url?: string;
  actionType: 'link' | 'workflow';
}

export interface AiSearchMeta {
  latencyMs: number;
  model: string;
  source: 'mock' | 'python-api';
}

export interface AiSearchResponse {
  id: string;
  query: string;
  createdAt: string;
  answers: AnswerResult[];
  actions: ActionResult[];
  meta: AiSearchMeta;

  // thread context
  threadId: string;
  historyMessages: ThreadMessage[];
}

/** Left sidebar item – one row per query / thread instance */
export interface ChatHistoryItem {
  id: string;          // thread_id (+ maybe timestamp)
  query: string;       // last user query
  createdAt: string;   // timestamp
  messagesCount: number;
  lastPreview: string;
  activityHint: 'New' | 'Short' | 'Active' | 'Long';
}

/** Optional transcript message for center chat (if you need later) */
export interface ChatMessage {
  id: string;
  role: 'user' | 'assistant' | 'system';
  text: string;
  createdAt: string;
}
