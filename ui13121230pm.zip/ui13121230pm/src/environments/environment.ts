const BASE_API_URL = 'https://localhost:7152/api/';
export const environment = {
  production: true,
  apiBaseUrl: BASE_API_URL,
  mockConfig: {
    enableAuth: true,
    enableDashboard: true,
    enableChat: true
  }
};
