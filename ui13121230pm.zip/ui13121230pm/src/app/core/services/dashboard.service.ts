import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { catchError, map, delay, shareReplay } from 'rxjs/operators';
import { Employee } from '../models/employee';
import { environment } from '../../../environments/environment';
import { ApiEndpoints } from '../config/api-endpoints';

// --- WIDGET INTERFACES ---
export interface PriorityAction {
    id: string;
    type: 'high' | 'medium' | 'low';
    title: string;
    time: string;
    description: string;
    descriptionBold?: string;
    icon: string;
    actionLabel: string;
    actionId: string;
}

export interface VelocityMetric {
    day: string;
    value: number;
    active?: boolean;
}

export interface Notification {
    id: string;
    user: string;
    message: string;
    isUrgent?: boolean;
}

// Helper interface for the JSON structure
interface DashboardWidgetData {
    priorityActions: PriorityAction[];
    velocityMetrics: VelocityMetric[];
    notifications: Notification[];
}

@Injectable({
    providedIn: 'root'
})
export class DashboardService {
    private readonly http = inject(HttpClient);

    // Cache for the mock widget data to avoid multiple file reads
    private mockWidgets$: Observable<DashboardWidgetData> | null = null;

    // --- 1. GET ALL EMPLOYEES (List) ---
    getEmployees(): Observable<Employee[]> {
        if (environment.mockConfig.enableDashboard) {
            return this.http.get<Employee[]>('assets/data/employees.json').pipe(
                delay(600),
                catchError(this.handleError),
                shareReplay(1)
            );
        } else {
            const url = `${environment.apiBaseUrl}${ApiEndpoints.EMPLOYEES.GET_ALL}`;
            return this.http.get<Employee[]>(url).pipe(
                catchError(this.handleError)
            );
        }
    }

    // --- 2. GET SINGLE EMPLOYEE (Details) ---
    getEmployeeById(id: string): Observable<Employee | undefined> {
        if (environment.mockConfig.enableDashboard) {
            return this.http.get<Employee[]>('assets/data/employees.json').pipe(
                delay(400),
                map(employees => employees.find(e => e.id === id)),
                catchError(this.handleError)
            );
        } else {
            const url = `${environment.apiBaseUrl}${ApiEndpoints.EMPLOYEES.GET_BY_ID(id)}`;
            return this.http.get<Employee>(url).pipe(
                catchError(this.handleError)
            );
        }
    }

    // --- 3. GET PRIORITY ACTIONS (Widget) ---
    getPriorityActions(): Observable<PriorityAction[]> {
        if (environment.mockConfig.enableDashboard) {
            return this.getMockWidgets().pipe(
                map(data => data.priorityActions)
            );
        } else {
            // Assuming you will add this endpoint constant later
            const url = `${environment.apiBaseUrl}${ApiEndpoints.DASHBOARD.ACTIONS}`;
            return this.http.get<PriorityAction[]>(url).pipe(catchError(this.handleError));
            return throwError(() => new Error('Real API endpoint not configured'));
        }
    }

    // --- 4. GET VELOCITY METRICS (Widget) ---
    getVelocityMetrics(): Observable<VelocityMetric[]> {
        if (environment.mockConfig.enableDashboard) {
            return this.getMockWidgets().pipe(
                map(data => data.velocityMetrics)
            );
        } else {
            const url = `${environment.apiBaseUrl}${ApiEndpoints.DASHBOARD.METRICS}`;
            return this.http.get<VelocityMetric[]>(url).pipe(catchError(this.handleError));
            return throwError(() => new Error('Real API endpoint not configured'));
        }
    }

    // --- 5. GET NOTIFICATIONS (Widget) ---
    getNotifications(): Observable<Notification[]> {
        if (environment.mockConfig.enableDashboard) {
            return this.getMockWidgets().pipe(
                map(data => data.notifications)
            );
        } else {
            const url = `${environment.apiBaseUrl}${ApiEndpoints.DASHBOARD.NOTIFICATIONS}`;
            return this.http.get<Notification[]>(url).pipe(catchError(this.handleError));
            return throwError(() => new Error('Real API endpoint not configured'));
        }
    }

    // --- HELPER: MOCK DATA CACHING ---
    private getMockWidgets(): Observable<DashboardWidgetData> {
        if (!this.mockWidgets$) {
            this.mockWidgets$ = this.http.get<DashboardWidgetData>('assets/data/dashboard-widgets.json').pipe(
                delay(500), // Simulate network delay for widgets
                catchError(this.handleError),
                shareReplay(1)
            );
        }
        return this.mockWidgets$;
    }

    private handleError(error: HttpErrorResponse) {
        console.error('API Error:', error);
        return throwError(() => new Error('Something went wrong. Please try again.'));
    }
}