import { inject, Injectable } from '@angular/core';
import { Observable, of, throwError } from 'rxjs';
import { delay, tap } from 'rxjs/operators';
import { LoginResponse } from '../models/login-response';
import { environment } from '../../../environments/environment'; // Import env
import { HttpClient } from '@angular/common/http';
import { ApiEndpoints } from '../config/api-endpoints';
@Injectable({ providedIn: 'root' })
export class AuthApiService {
    private readonly http = inject(HttpClient);

    login(credentials: { userId: string; password: string }): Observable<LoginResponse> {

        if (environment.mockConfig.enableAuth) {
            let mockFile = '';

            if (credentials.userId === 'k059839' && credentials.password === 'manager') {
                mockFile = 'assets/data/login-manager.json';
            }
            else if (credentials.userId === 'k059838' && credentials.password === 'employee') {
                mockFile = 'assets/data/login-employee.json';
            }
            else {
                // Simulate 401 Unauthorized
                return throwError(() => new Error('Invalid User ID or Password'));
            }

            // Fetch the specific file based on the user
            return this.http.get<LoginResponse>(mockFile).pipe(
                delay(800), // Simulate network latency
                tap(res => console.log('✅ [Mock Login] Success:', res.role))
            );
        }

        // --- 2. REAL API MODE ---
        else {
            const url = `${environment.apiBaseUrl}${ApiEndpoints.AUTH.LOGIN}`;
            return this.http.post<LoginResponse>(url, credentials);
        }
    }
}

