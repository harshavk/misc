import { Injectable, signal, computed } from '@angular/core';
import { User } from '../models/user.model';
import { Role } from '../models/role.enum';
import { LoginResponse } from '../models/login-response'; // Import the interface we created earlier

const STORAGE_KEY = 'rbdui_current_user';
const TOKEN_KEY = 'rbdui_auth_token'; // New key for the JWT

@Injectable({ providedIn: 'root' })
export class AuthService {
  // Initialize state from local storage
  private _currentUser = signal<User | null>(this.loadFromStorage());

  // Public Signals
  currentUser = computed(() => this._currentUser());
  isAuthenticatedSignal = computed(() => !!this._currentUser());

  constructor() {
    // Optional: Check if token is expired here
  }

  // --- NEW: Handle API Login Response ---
  setSession(response: LoginResponse): void {
    console.log('Full Login Response:', response);

    // 2. Safe Role Extraction (Handle 'role', 'Role', or 'userRole')
    const rawRole = response.role || '';

    console.log('Extracted Role String:', rawRole); // Should print "Tech Director" or "Software Engineer"
    // 1. Map API Role string ("Tech Director") to App Role Enum
    const appRoles = this.mapApiRoleToAppRole(response.role);

    // 2. Create User Object
    const user: User = {
      id: response.userName, // Using userName as ID
      name: response.userName,
      email: response.email,
      roles: appRoles,
      avatarUrl: response.ImageUrl
    };

    // 3. Update State
    this._currentUser.set(user);

    // 4. Persist to LocalStorage
    localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
    localStorage.setItem(TOKEN_KEY, response.token);
  }

  logout(): void {
    this._currentUser.set(null);
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(TOKEN_KEY); // Clear token
  }

  // --- NEW: Helper for Interceptor ---
  getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  }

  // --- Role & Auth Checks (Kept from your original code) ---
  hasRole(role: Role): boolean {
    const user = this._currentUser();
    return !!user?.roles.includes(role);
  }

  hasAnyRole(roles: Role[]): boolean {
    const user = this._currentUser();
    if (!user) return false;
    return roles.some(r => user.roles.includes(r));
  }

  isAuthenticated(): boolean {
    return this.isAuthenticatedSignal();
  }

  // --- Internal Helpers ---

  private loadFromStorage(): User | null {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    try {
      return JSON.parse(raw) as User;
    } catch {
      return null;
    }
  }

  private mapApiRoleToAppRole(apiRole: string): Role[] {
    // --- FIX: Add Safety Check ---
    if (!apiRole) {
      console.warn('⚠️ No role found in login response. Defaulting to Employee.');
      return [Role.Employee];
    }

    // Existing logic
    const lowerRole = apiRole.toLowerCase();

    if (lowerRole.includes('tech director') ||
      lowerRole.includes('admin') ||
      lowerRole.includes('manager')) {
      return [Role.Manager];
    }

    return [Role.Employee];
  }
}