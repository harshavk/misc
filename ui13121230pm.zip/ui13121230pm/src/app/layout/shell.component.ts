import { Component, inject, OnInit, ViewChild, HostListener } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { MatSidenavModule, MatSidenav } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { AuthService } from '../core/services/auth.service'; // Adjust path
import { Role } from '../core/models/role.enum'; // Adjust path
import { MatRippleModule } from '@angular/material/core';
import { ThemeService } from '../core/services/theme.service';
import { MatMenu } from "@angular/material/menu";
import { MatMenuModule } from '@angular/material/menu';
import { MatBadgeModule } from '@angular/material/badge';
import { MatToolbarModule } from "@angular/material/toolbar";

interface NavItem {
  label: string;
  icon: string;
  route: string;
  roles?: Role[];
}

@Component({
  selector: 'app-shell',
  standalone: true,
  imports: [CommonModule, RouterModule, MatSidenavModule, MatIconModule, MatButtonModule, MatRippleModule, MatMenu, MatMenuModule,
    MatBadgeModule,
    MatToolbarModule],
  templateUrl: './shell.component.html',
  styleUrls: ['./shell.component.scss']
})
export class ShellComponent implements OnInit {
  protected readonly auth = inject(AuthService);
  private router = inject(Router);
  readonly themeService = inject(ThemeService);

  @ViewChild('sidenav') sidenav!: MatSidenav;

  isMobile = false;

  readonly navItems: NavItem[] = [
    { label: 'Dashboard', icon: 'dashboard', route: '/dashboard' },
    { label: 'Ally', icon: 'smart_toy', route: '/ally' },
    // { label: 'Employee', icon: 'group', route: '/employee', roles: [Role.Employee, Role.Manager] },
    // { label: 'Manager', icon: 'supervisor_account', route: '/manager', roles: [Role.Manager] },
  ];

  get currentUser() {
    return this.auth.currentUser() || { name: 'Harsha VK', avatarUrl: 'assets/harsha.jpg' };
  }

  get visibleNavItems() {
    return this.navItems.filter(i => !i.roles || this.auth.hasAnyRole(i.roles));
  }

  get currentTitle() {
    const match = this.navItems.find(n => this.router.url.startsWith(n.route));
    return match?.label || 'WF App';
  }

  ngOnInit() {
    this.checkScreenSize();
  }

  @HostListener('window:resize', [])
  onResize() {
    this.checkScreenSize();
  }

  toggleSidebar() {
    this.sidenav.toggle();
  }

  toggleTheme() {
    this.themeService.toggle();
  }

  onNavItemClick() {
    if (this.isMobile) this.sidenav.close();
  }

  onLogout() {
    this.auth.logout();
    this.router.navigate(['/login']);
  }

  private checkScreenSize() {
    this.isMobile = window.innerWidth <= 768;
    // On desktop, ensure it's open by default
    if (!this.isMobile && this.sidenav) {
      this.sidenav.open();
    }
  }
}