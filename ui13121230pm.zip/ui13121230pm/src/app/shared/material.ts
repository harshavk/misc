export { MatButtonModule } from '@angular/material/button';
export { MatIconModule } from '@angular/material/icon';
export { MatToolbarModule } from '@angular/material/toolbar';
export { MatSidenavModule } from '@angular/material/sidenav';
export { MatListModule } from '@angular/material/list';
export { MatInputModule } from '@angular/material/input';
export { MatFormFieldModule } from '@angular/material/form-field';
export { MatCard } from '@angular/material/card';
export { MatCardContent } from '@angular/material/card';
export { MatMenuModule } from '@angular/material/menu';
export { MatDialogModule } from '@angular/material/dialog';
export { MatTooltipModule } from '@angular/material/tooltip';
export { MatChipsModule } from '@angular/material/chips';
export { MatRippleModule } from '@angular/material/core';

// --- NEW MODULES ADDED FOR DASHBOARD/MYBUDDY ---
export { MatProgressBarModule } from '@angular/material/progress-bar';
export { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
export { MatDividerModule } from '@angular/material/divider';
export { MatButtonToggleModule } from '@angular/material/button-toggle';
export { MatSnackBarModule } from '@angular/material/snack-bar';