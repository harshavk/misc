import {
  Component,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  inject,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { finalize } from 'rxjs';

import { AuthService } from '../../core/services/auth.service';
import { AuthApiService } from '../../core/services/auth-api.service';

// Material Imports
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  standalone: true,
  selector: 'app-login',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatInputModule,
    MatFormFieldModule,
    MatProgressBarModule,
    MatIconModule,
    MatProgressSpinnerModule
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="login-container">
      <div class="login-card">
        
        <div class="login-left">
          <div class="brand-header">
            <div class="wf-logo-box">WF</div>
            <div class="brand-text">
              <span class="company">Wells Fargo</span>
              <span class="product">Onboard Assistant</span>
            </div>
          </div>
          
          <div class="left-content">
            <h1>Welcome Back!</h1>

          </div>

          <div class="decor-circle"></div>
        </div>

        <div class="login-right">
          <div class="form-header">
            <h2>Login</h2>
          </div>

          <div class="error-banner" *ngIf="loginError">
            <mat-icon class="error-icon">error</mat-icon>
            <span>{{ loginError }}</span>
          </div>

          <form
            [formGroup]="form"
            (ngSubmit)="onSubmit()"
            class="form"
            autocomplete="off"
          >
            <mat-form-field appearance="outline" class="full-width">
              <mat-label>User ID</mat-label>
              <mat-icon matPrefix class="input-icon">person_outline</mat-icon>
              <input
                matInput
                formControlName="userId"
                placeholder="Ex: u12345"
                autocomplete="off"
              />
              <mat-error *ngIf="userIdControl.hasError('required')">
                User ID is required
              </mat-error>
            </mat-form-field>

            <mat-form-field appearance="outline" class="full-width">
              <mat-label>Password</mat-label>
              <mat-icon matPrefix class="input-icon">lock_outline</mat-icon>
              <input
                matInput
                [type]="hidePassword ? 'password' : 'text'"
                formControlName="password"
                autocomplete="current-password"
              />
              <button
                mat-icon-button
                matSuffix
                type="button"
                (click)="hidePassword = !hidePassword"
                [attr.aria-label]="'Hide password'"
                [attr.aria-pressed]="hidePassword"
                class="visibility-btn"
              >
                <mat-icon>{{ hidePassword ? 'visibility_off' : 'visibility' }}</mat-icon>
              </button>
              <mat-error *ngIf="passwordControl.hasError('required')">
                Password is required
              </mat-error>
            </mat-form-field>

            <button
              mat-flat-button
              color="warn"
              class="login-btn full-width"
              [disabled]="isSubmitting || form.invalid"
              type="submit"
            >
              <span *ngIf="!isSubmitting">Login</span>
              <mat-spinner *ngIf="isSubmitting" diameter="24" class="btn-spinner"></mat-spinner>
            </button>
          </form>

          <div class="form-footer">
            <p>Need help? <a href="#" (click)="$event.preventDefault()">Contact Support</a></p>
          </div>

          <div class="login-bottom-loader" *ngIf="isSubmitting">
             <mat-progress-bar mode="indeterminate" color="accent"></mat-progress-bar>
          </div>
        </div>

      </div>
    </div>
  `,
  styles: [`
    :host {
      --wf-red: #d71e28;
      --wf-red-dark: #b01b25;
      --wf-gold: #ffcd41;
      --text-dark: #111827;
      --text-gray: #6b7280;
      --bg-surface: #f4f4f6;
    }

    .login-container {
      height: 100vh;
      display: flex;
      justify-content: center;
      align-items: center;
      background-color: var(--bg-surface);
      padding: 16px;
    }

    .login-card {
      width: 100%;
      max-width: 900px;
      min-height: 520px;
      display: flex;
      border-radius: 20px;
      overflow: hidden;
      background-color: #ffffff;
      box-shadow: 0 20px 40px rgba(0, 0, 0, 0.12);
      position: relative;
    }

    /* --- LEFT HALF (BRANDING) --- */
    .login-left {
      width: 45%;
      background: linear-gradient(135deg, var(--wf-red) 0%, var(--wf-red-dark) 100%);
      color: #ffffff;
      padding: 40px;
      display: flex;
      flex-direction: column;
      justify-content: space-between;
      position: relative;
      border-right: 5px solid var(--wf-gold);
    }

    .brand-header {
      display: flex;
      align-items: center;
      gap: 12px;
    }

    .wf-logo-box {
      width: 42px;
      height: 42px;
      border-radius: 8px;
      background-color: var(--wf-red);
      color: var(--wf-white);
      display: flex;
      align-items: center;
      justify-content: center;
      font-weight: 800;
      font-size: 1rem;
      box-shadow: 0 4px 10px rgba(0,0,0,0.2);
    }

    .brand-text {
      display: flex;
      flex-direction: column;
    }

    .brand-text .company {
      font-weight: 700;
      font-size: 1.1rem;
      line-height: 1.1;
    }

    .brand-text .product {
      font-size: 0.85rem;
      opacity: 0.9;
    }

    .left-content h1 {
      font-size: 2.2rem;
      font-weight: 700;
      margin: 0 0 16px;
      line-height: 1.1;
    }

    .left-content p {
      font-size: 1rem;
      line-height: 1.5;
      opacity: 0.9;
      max-width: 90%;
    }

    /* Subtle circle decoration */
    .decor-circle {
      position: absolute;
      bottom: -60px;
      right: -60px;
      width: 240px;
      height: 240px;
      border-radius: 50%;
      background: rgba(255,255,255,0.06);
      pointer-events: none;
    }

    /* --- RIGHT HALF (FORM) --- */
    .login-right {
      width: 55%;
      padding: 48px 56px;
      display: flex;
      flex-direction: column;
      justify-content: center;
      position: relative;
    }

    .form-header {
      margin-bottom: 24px;
    }

    .form-header h2 {
      font-size: 1.8rem;
      font-weight: 700;
      color: var(--text-dark);
      margin: 0 0 8px;
    }

    .form-header p {
      color: var(--text-gray);
      margin: 0;
    }

    .form {
      display: flex;
      flex-direction: column;
    }

    .full-width {
      width: 100%;
      margin-bottom: 16px;
    }

    /* Icons inside inputs */
    .input-icon {
      margin-right: 12px;
      color: #9ca3af;
    }

    .visibility-btn {
      color: #6b7280;
    }

    /* Forgot Password */
    .form-actions {
      display: flex;
      justify-content: flex-end;
      margin-top: -8px;
      margin-bottom: 24px;
    }

    .forgot-link {
      color: var(--wf-red);
      font-size: 0.9rem;
      font-weight: 600;
      text-decoration: none;
    }
    .forgot-link:hover { text-decoration: underline; }

    /* Button */
    .login-btn {
      height: 52px;
      border-radius: 8px;
      font-size: 1rem;
      font-weight: 600;
      background: linear-gradient(to right, var(--wf-red), var(--wf-red-dark)) !important;
      color: white !important;
      transition: transform 0.2s;
    }

    .login-btn:hover:not([disabled]) {
      transform: translateY(-2px);
      box-shadow: 0 4px 12px rgba(215, 30, 40, 0.3);
    }

    .btn-spinner ::ng-deep circle {
      stroke: #ffffff !important;
    }

    /* Footer */
    .form-footer {
      margin-top: 32px;
      text-align: center;
      font-size: 0.9rem;
      color: var(--text-gray);
    }

    .form-footer a {
      color: var(--wf-red);
      font-weight: 600;
      text-decoration: none;
    }

    /* Error Banner */
    .error-banner {
      display: flex;
      align-items: center;
      gap: 10px;
      background-color: #fee2e2;
      border: 1px solid #fecaca;
      color: #b91c1c;
      padding: 10px 16px;
      border-radius: 8px;
      font-size: 0.9rem;
      margin-bottom: 24px;
    }
    .error-icon { font-size: 20px; height: 20px; width: 20px; }

    /* Bottom Loader */
    .login-bottom-loader {
      position: absolute;
      bottom: 0;
      left: 0;
      right: 0;
    }
    
    .login-bottom-loader ::ng-deep .mdc-linear-progress__bar-inner {
      border-color: var(--wf-gold) !important;
    }
    .login-bottom-loader ::ng-deep .mdc-linear-progress__buffer-bar {
      background-color: rgba(255, 205, 65, 0.2) !important;
    }

    /* Responsive */
    @media (max-width: 800px) {
      .login-card {
        flex-direction: column;
        max-width: 450px;
        min-height: auto;
      }
      .login-left {
        width: 100%;
        padding: 30px;
        border-right: none;
        border-bottom: 5px solid var(--wf-gold);
      }
      .login-right {
        width: 100%;
        padding: 30px;
      }
      .decor-circle { display: none; }
    }
  `],
})
export class LoginComponent {
  private readonly fb = inject(FormBuilder);
  private readonly auth = inject(AuthService);
  private readonly api = inject(AuthApiService);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  private readonly cdr = inject(ChangeDetectorRef);

  isSubmitting = false;
  loginError: string | null = null;
  hidePassword = true; // State for password toggle

  readonly form: FormGroup = this.fb.group({
    userId: ['', Validators.required],
    password: ['', Validators.required],
  });

  get userIdControl() {
    return this.form.get('userId')!;
  }

  get passwordControl() {
    return this.form.get('password')!;
  }

  onSubmit(): void {
    if (this.isSubmitting) return;

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.setSubmitting(true);
    this.setLoginError(null);

    const { userId, password } = this.form.value;

    this.api.login({ userId, password })
      .pipe(finalize(() => this.setSubmitting(false)))
      .subscribe({
        next: (response) => {
          // Pass the full API response to AuthService
          this.auth.setSession(response);

          // Navigate
          const returnUrl = this.route.snapshot.queryParamMap.get('returnUrl') || '/dashboard';
          this.router.navigateByUrl(returnUrl);
        },
        error: () => this.handleInvalidCredentials()
      });
  }

  // ---- helpers -------------------------------------------------------------

  private setSubmitting(value: boolean): void {
    this.isSubmitting = value;
    this.cdr.markForCheck();
  }

  private setLoginError(message: string | null): void {
    this.loginError = message;
    this.cdr.markForCheck();
  }

  private handleInvalidCredentials(): void {
    this.setLoginError(
      'Invalid credentials. Please check your User ID and password.'
    );
  }
}