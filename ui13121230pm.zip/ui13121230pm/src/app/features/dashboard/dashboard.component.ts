import { Component, ChangeDetectionStrategy, signal, computed, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';

import { AuthService } from '../../core/services/auth.service';
// Ensure Notification is imported if exported, or use any if not strict
import { DashboardService, PriorityAction, VelocityMetric, Notification } from '../../core/services/dashboard.service';
import { Role } from '../../core/models/role.enum';
import { Employee } from '../../core/models/employee';

// MATERIAL MODULES
import {
  MatButtonModule,
  MatIconModule,
  MatProgressBarModule,
  MatProgressSpinnerModule,
  MatInputModule,
  MatFormFieldModule,
  MatDividerModule,
  MatRippleModule
} from '../../shared/material';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    MatButtonModule,
    MatIconModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatInputModule,
    MatFormFieldModule,
    MatDividerModule,
    MatRippleModule
  ],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DashboardComponent implements OnInit {
  private readonly auth = inject(AuthService);
  private readonly dashboardService = inject(DashboardService);
  private readonly router = inject(Router);

  // --- DATA SIGNALS ---
  readonly userRole = signal<Role>(Role.Employee);
  readonly employees = signal<Employee[]>([]);

  // New Widgets Signals
  readonly priorityActions = signal<PriorityAction[]>([]);
  readonly velocityChart = signal<VelocityMetric[]>([]);
  readonly notifications = signal<Notification[]>([]);

  // Selection State
  readonly selectedEmployeeId = signal<string | null>(null);
  readonly selectedEmployee = signal<Employee | null>(null);

  // Loading State
  readonly isLoadingList = signal(true);
  readonly isLoadingDetail = signal(false);
  readonly error = signal<string | null>(null);

  // UI State
  readonly searchQuery = signal('');
  readonly activeFilter = signal('All'); // All, Starting Soon, In Progress
  readonly isBulkMode = signal(false);
  readonly selectedIds = signal<Set<string>>(new Set());

  // Tab State for Center Panel
  activeTab = 'pre'; // 'pre', 'first3', 'week1'

  // --- COMPUTED PROPERTIES ---
  readonly isManager = computed(() => this.userRole() === Role.Manager);
  readonly currentUser = computed(() => this.auth.currentUser());

  // Filter Logic
  readonly filteredEmployees = computed(() => {
    let data = this.employees();
    const query = this.searchQuery().toLowerCase();
    const filter = this.activeFilter();

    if (query) {
      data = data.filter(e =>
        e.name.toLowerCase().includes(query) ||
        e.id.toLowerCase().includes(query)
      );
    }

    if (filter === 'Starting Soon') {
      data = data.filter(e => e.status === 'Not Started');
    } else if (filter === 'In Progress') {
      data = data.filter(e => e.status === 'In Progress');
    }

    return data;
  });

  // Metrics
  readonly totalJoiners = computed(() => this.employees().length);
  readonly startingSoonCount = computed(() => this.employees().filter(e => e.status === 'Not Started').length);
  readonly avgProgress = computed(() => {
    const list = this.employees();
    if (!list.length) return 0;
    const total = list.reduce((acc, curr) => acc + (curr.progress || 0), 0);
    return Math.round(total / list.length);
  });

  // Count urgent tasks for the header
  readonly criticalTaskCount = computed(() => this.priorityActions().length);

  ngOnInit() {
    this.loadDashboardData();
  }

  private loadDashboardData() {
    this.isLoadingList.set(true);
    this.error.set(null);

    const user = this.auth.currentUser();
    const isMgr = user?.roles.includes(Role.Manager) ?? false;
    this.userRole.set(isMgr ? Role.Manager : Role.Employee);

    // 1. Fetch Employees
    this.dashboardService.getEmployees().subscribe({
      next: (data) => {
        if (isMgr) {
          this.employees.set(data);
        } else {
          // Filter for self if not manager
          const myProfile = data.find(e => e.id === user?.id || e.email === user?.email);
          this.employees.set(myProfile ? [myProfile] : []);
          if (myProfile) this.onEmployeeClick(myProfile.id);
        }
        this.isLoadingList.set(false);
      },
      error: (err) => {
        this.error.set(err.message);
        this.isLoadingList.set(false);
      }
    });

    // 2. Fetch Manager Widgets (if Manager)
    if (isMgr) {
      this.dashboardService.getPriorityActions().subscribe({
        next: (actions) => this.priorityActions.set(actions),
        error: (err) => console.error('Failed to load priority actions', err)
      });

      this.dashboardService.getVelocityMetrics().subscribe({
        next: (metrics) => this.velocityChart.set(metrics),
        error: (err) => console.error('Failed to load velocity chart', err)
      });

      this.dashboardService.getNotifications().subscribe({
        next: (notifs) => this.notifications.set(notifs),
        error: (err) => console.error('Failed to load notifications', err)
      });
    }
  }

  // --- ACTIONS ---

  onEmployeeClick(id: string) {
    this.selectedEmployeeId.set(id);
    this.isLoadingDetail.set(true);

    this.dashboardService.getEmployeeById(id).subscribe({
      next: (details) => {
        if (details) this.selectedEmployee.set(details);
        this.isLoadingDetail.set(false);
      },
      error: () => this.isLoadingDetail.set(false)
    });
  }

  toggleSelection(id: string, event: Event) {
    event.stopPropagation();
    const current = this.selectedIds();
    if (current.has(id)) current.delete(id);
    else current.add(id);
    this.selectedIds.set(new Set(current)); // Trigger signal update
  }

  toggleBulkMode() {
    this.isBulkMode.update(v => !v);
    this.selectedIds().clear();
  }

  setFilter(filter: string) {
    this.activeFilter.set(filter);
  }

  // Quick Action Handler (Detail Panel & Right Panel)
  performQuickAction(actionType: string) {
    let prompt = '';

    // 1. CHECK BULK SELECTION FIRST
    if (this.isManager() && this.isBulkMode() && this.selectedIds().size > 0) {
      const selectedNames = this.employees()
        .filter(e => this.selectedIds().has(e.id))
        .map(e => e.name)
        .join(', ');

      switch (actionType) {
        case 'buddy': prompt = `Assign an onboarding buddy to these employees: ${selectedNames}`; break;
        case 'cloud': prompt = `Request cloud access for: ${selectedNames}`; break;
        case 'equipment': prompt = `Order equipment for: ${selectedNames}`; break;
        case 'meeting': prompt = `Schedule a group 1:1 or sync with: ${selectedNames}`; break;
        default: prompt = `Help with onboarding for: ${selectedNames}`;
      }
    }
    // 2. FALLBACK TO SINGLE SELECTION
    else {
      const emp = this.selectedEmployee();
      const name = emp?.name || 'the employee';

      if (this.isManager()) {
        switch (actionType) {
          case 'buddy': prompt = `Assign an onboarding buddy to ${name}`; break;
          case 'cloud': prompt = `Request cloud access for ${name}`; break;
          case 'equipment': prompt = `Order equipment for ${name}`; break;
          case 'meeting': prompt = `Schedule a 1:1 with ${name}`; break;
          default: prompt = `Help with ${name}`;
        }
      } else {
        // Employee Actions
        switch (actionType) {
          case 'my_buddy': prompt = `Who is my onboarding buddy?`; break;
          case 'my_equipment': prompt = `Track my laptop order`; break;
          case 'my_goals': prompt = `Set my Workday goals`; break;
        }
      }
    }

    // Navigate to Chat
    this.router.navigate(['/ally'], { queryParams: { q: prompt } });
  }

  // Action Stream Handler
  triggerAction(action: string) {
    let prompt = '';

    switch (action) {
      case 'add_new':
        prompt = 'I need to onboard a new hire. Can you guide me through the process?';
        break;
      case 'equipment':
        prompt = 'Review pending equipment requests.';
        break;
      case 'buddy':
        prompt = 'Show me employees who need a buddy assigned.';
        break;
      default:
        prompt = `I need help with ${action}`;
    }

    this.router.navigate(['/ally'], { queryParams: { q: prompt } });
  }

  handleNotificationClick(name: string) {
    this.router.navigate(['/ally'], { queryParams: { q: `Check status for ${name}` } });
  }
}