import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Employee } from '../../../../core/models/employee';
import { MatIconModule, MatProgressBarModule, MatDividerModule } from '../../../../shared/material';

@Component({
  selector: 'app-employee-detail',
  standalone: true,
  imports: [CommonModule, MatIconModule, MatProgressBarModule, MatDividerModule],
  templateUrl: './employee-detail.html',
  styleUrls: ['./employee-detail.css']
})
export class EmployeeDetailComponent {
  @Input() employee: Employee | null = null;
  @Input() isLoading: boolean = false;
  @Input() isManager: boolean = false;
  @Input() summaryStats: any = {};

  @Output() action = new EventEmitter<string>();

  activeTab = 'pre';

  performAction(act: string) {
    this.action.emit(act);
  }
}