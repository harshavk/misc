import { Component, Input, Output, EventEmitter, signal, computed, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Employee } from '../../../../core/models/employee';
import {
  MatIconModule, MatButtonModule, MatInputModule, MatProgressBarModule
} from '../../../../shared/material';

@Component({
  selector: 'app-employee-list',
  standalone: true,
  imports: [CommonModule, FormsModule, MatIconModule, MatButtonModule, MatInputModule, MatProgressBarModule],
  templateUrl: './employee-list.html',
  styleUrls: ['./employee-list.css']
})
export class EmployeeListComponent implements OnChanges { // 1. Add OnChanges
  @Input() employees: Employee[] = [];
  @Input() selectedId: string | null = null;
  @Input() isManager: boolean = false;
  @Input() isLoading: boolean = false;
  @Input() error: string | null = null;

  @Output() select = new EventEmitter<string>();

  // 2. Internal Signals to track Inputs
  private readonly _sourceEmployees = signal<Employee[]>([]);

  // UI State
  readonly searchQuery = signal('');
  readonly activeFilter = signal('All');
  readonly isBulkMode = signal(false);
  readonly selectedIds = signal<Set<string>>(new Set());

  // 3. React to Input Changes
  ngOnChanges(changes: SimpleChanges): void {
    if (changes['employees']) {
      this._sourceEmployees.set(this.employees || []);
    }
  }

  // 4. Computed Filter (Now tracks _sourceEmployees signal)
  readonly filteredEmployees = computed(() => {
    let data = this._sourceEmployees(); // <--- Now Reactive!
    const q = this.searchQuery().toLowerCase();
    const filter = this.activeFilter();

    if (q) {
      data = data.filter(e => e.name.toLowerCase().includes(q) || e.id.toLowerCase().includes(q));
    }

    if (filter === 'Starting Soon') return data.filter(e => e.status === 'Not Started');
    if (filter === 'In Progress') return data.filter(e => e.status === 'In Progress');

    return data;
  });

  onSelect(id: string) {
    this.select.emit(id);
  }

  setFilter(filter: string) { this.activeFilter.set(filter); }
  toggleBulkMode() { this.isBulkMode.update(v => !v); }

  toggleSelection(id: string, event: Event) {
    event.stopPropagation();
    const current = this.selectedIds();
    if (current.has(id)) current.delete(id);
    else current.add(id);
    this.selectedIds.set(new Set(current));
  }
}