import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { RouterLink } from '@angular/router';

@Component({
    selector: 'app-credits',
    standalone: true,
    imports: [CommonModule, MatCardModule, MatButtonModule, MatIconModule, RouterLink],
    template: `
    <div class="credits-container">
      
      <div class="credits-header">
        <button mat-icon-button routerLink="/ally" class="back-btn">
          <mat-icon>arrow_back</mat-icon>
        </button>
        <h1>App Created Credits</h1>
        <div class="gold-bar"></div>
      </div>

      <div class="team-grid">
        @for (member of teamMembers; track member.role) {
          <div class="member-card">
            
            <div class="image-wrapper">
              <img [src]="member.image" 
                   alt="{{ member.role }}" 
                   class="member-img"
                   onerror="this.src='https://ui-avatars.com/api/?name=WF&background=d71e28&color=fff&size=200'">
            </div>

            <div class="member-info">
              <h3>{{ member.role }}</h3>
              <p>Contributor</p>
            </div>
          </div>
        }
      </div>

      <div class="footer-note">
        Built with ❤️ for Wells Fargo Onboarding
      </div>

    </div>
  `,
    styles: [`
    :host {
      display: block;
      height: 100%;
      background-color: var(--wf-bg, #f5f5f7);
      overflow-y: auto;
    }

    .credits-container {
      max-width: 1000px;
      margin: 0 auto;
      padding: 40px 24px;
    }

    /* HEADER */
    .credits-header {
      text-align: center;
      margin-bottom: 60px;
      position: relative;
    }

    .back-btn {
      position: absolute;
      left: 0;
      top: -10px;
      color: #64748b;
    }

    h1 {
      font-size: 2rem;
      font-weight: 800;
      color: #d71e28;
      margin: 0 0 16px 0;
      font-family: 'Georgia', serif;
    }

    .gold-bar {
      width: 60px;
      height: 4px;
      background-color: #ffce00;
      margin: 0 auto;
      border-radius: 2px;
    }

    /* GRID */
    .team-grid {
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
      gap: 24px;
      margin-bottom: 40px;
    }

    .member-card {
      background: white;
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 4px 12px rgba(0,0,0,0.05);
      transition: transform 0.2s, box-shadow 0.2s;
      border: 1px solid #e5e7eb;
      text-align: center;
      padding-bottom: 20px;
    }

    .member-card:hover {
      transform: translateY(-5px);
      box-shadow: 0 12px 24px rgba(0,0,0,0.1);
      border-color: #ffce00;
    }

    /* IMAGE STYLES */
    .image-wrapper {
      height: 200px;
      width: 100%;
      background-color: #f3f4f6;
      overflow: hidden;
      border-bottom: 1px solid #e5e7eb;
      margin-bottom: 16px;
    }

    .member-img {
      width: 100%;
      height: 100%;
      object-fit: cover; /* Ensures image fills box without stretching */
      object-position: center top;
      transition: transform 0.4s ease;
    }

    .member-card:hover .member-img {
      transform: scale(1.05); /* Subtle zoom on hover */
    }

    .member-info h3 {
      margin: 0;
      font-size: 1.1rem;
      font-weight: 700;
      color: #1f2937;
    }

    .member-info p {
      margin: 4px 0 0 0;
      font-size: 0.85rem;
      color: #6b7280;
    }

    .footer-note {
      text-align: center;
      color: #9ca3af;
      font-size: 0.9rem;
      margin-top: 40px;
    }
  `]
})
export class CreditsComponent {
    // Update these paths to match your actual assets
    teamMembers = [
        { role: 'Lead Python AI Engineer', image: 'assets/team/R.jpeg' },
        { role: 'Python AI Developer', image: 'assets/team/S.jpeg' },
        { role: 'Lead Workday AI Developer', image: 'assets/team/Ro.jpeg' },
        { role: '.NET Angular Engineer', image: 'assets/team/H.jpeg' },
    ];
}