import { Component, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';

interface TimelineItem {
  label: string;
  description: string;
}

interface QuickCard {
  title: string;
  description: string;
}

@Component({
  standalone: true,
  selector: 'app-onboard',
  imports: [
    CommonModule,
    MatCardModule,
    MatButtonModule,
    MatIconModule,
    MatFormFieldModule,
    MatInputModule,
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="onboard-container wf-fade-in">
      <!-- LEFT COLUMN: Role + Journey -->
      <section class="onboard-left">
        <div class="left-section wf-elevate">
          <h3 class="section-title">Select Role</h3>
          <div class="role-buttons">
            <button mat-stroked-button color="primary" class="role-btn">
              <mat-icon>workspace_premium</mat-icon>
              <span>Manager</span>
            </button>

            <button mat-flat-button color="primary" class="role-btn primary">
              <mat-icon>person</mat-icon>
              <span>New Joinee</span>
            </button>
          </div>
        </div>

        <div class="left-section timeline wf-elevate">
          <h3 class="section-title">Journey Timeline</h3>

          <div
            class="timeline-item"
            *ngFor="let item of timeline"
          >
            <div class="timeline-line"></div>
            <div class="timeline-content">
              <div class="timeline-label">{{ item.label }}</div>
              <div class="timeline-desc">{{ item.description }}</div>
            </div>
          </div>
        </div>
      </section>

      <!-- CENTER COLUMN: Header + Chat -->
      <section class="onboard-center">
        <div class="center-header">
          <h1>OnboardAI – Conversational Assistant</h1>
          <p class="center-subtitle">
            Get quick answers to all your onboarding questions.
          </p>
        </div>

        <div class="center-body">
          <div class="chat-placeholder wf-elevate">
            Ask onboarding related queries here.
          </div>
        </div>

        <div class="center-footer">
          <mat-form-field appearance="outline" class="chat-input-field">
            <mat-label>Ask onboarding related queries here</mat-label>
            <input matInput />
          </mat-form-field>

          <button mat-flat-button color="primary" class="send-btn">
            Send
          </button>

          <button mat-icon-button class="mic-btn" matTooltip="Voice input">
            <mat-icon>mic</mat-icon>
          </button>
        </div>
      </section>

      <!-- RIGHT COLUMN: Quick Knowledge Cards -->
      <section class="onboard-right wf-elevate">
        <h3 class="section-title">Quick Knowledge Cards</h3>

        <mat-card
          class="quick-card"
          *ngFor="let card of quickCards"
        >
          <div class="quick-card-title">{{ card.title }}</div>
          <div class="quick-card-desc">{{ card.description }}</div>
        </mat-card>
      </section>
    </div>
  `,
  styles: [
    `
      .onboard-container {
        display: grid;
        grid-template-columns: 280px minmax(0, 1.6fr) 260px;
        gap: 24px;
        height: calc(100vh - 64px);
        box-sizing: border-box;
      }

      .onboard-left,
      .onboard-center,
      .onboard-right {
        display: flex;
        flex-direction: column;
      }

      .section-title {
        margin: 0 0 12px;
        font-size: 0.9rem;
        font-weight: 600;
        color: var(--wf-text-subtle);
        text-transform: uppercase;
        letter-spacing: 0.04em;
      }

      .left-section {
        padding: 16px 18px;
        border-radius: 18px;
        background: var(--wf-surface);
        border: 1px solid var(--wf-border);
        margin-bottom: 16px;
      }

      .role-buttons {
        display: flex;
        flex-direction: column;
        gap: 10px;
      }

      .role-btn {
        justify-content: flex-start;
        gap: 10px;
        border-radius: 999px;
        text-transform: none;
        width: 100%;
      }

      .role-btn.primary {
        font-weight: 600;
        background-color: rgba(215, 31, 42, 0.08);
        color: var(--wf-red);
      }

      .role-btn.primary .mat-icon {
        color: var(--wf-red);
      }

      .timeline {
        flex: 1;
      }

      .timeline-item {
        display: flex;
        align-items: flex-start;
        margin-bottom: 14px;
      }

      .timeline-line {
        width: 2px;
        height: 44px;
        border-left: 2px solid var(--wf-red);
        margin-right: 10px;
        margin-top: 2px;
        border-radius: 999px;
      }

      .timeline-content {
        flex: 1;
      }

      .timeline-label {
        font-size: 0.95rem;
        font-weight: 500;
      }

      .timeline-desc {
        font-size: 0.8rem;
        color: var(--wf-text-subtle);
      }

      .onboard-center {
        padding: 8px 4px;
      }

      .center-header h1 {
        margin: 0;
        font-size: 1.35rem;
        font-weight: 600;
      }

      .center-subtitle {
        margin: 4px 0 0;
        font-size: 0.85rem;
        color: var(--wf-text-subtle);
      }

      .center-body {
        flex: 1;
        display: flex;
        padding-top: 16px;
      }

      .chat-placeholder {
        flex: 1;
        border-radius: 18px;
        border: 1px solid var(--wf-border);
        background-color: var(--wf-surface);
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 0.9rem;
        color: var(--wf-text-subtle);
      }

      .center-footer {
        display: flex;
        align-items: center;
        gap: 8px;
        padding-top: 16px;
      }

      .chat-input-field {
        flex: 1;
      }

      .send-btn {
        text-transform: none;
        border-radius: 999px;
      }

      .mic-btn {
        border-radius: 999px;
      }

      .onboard-right {
        padding: 16px 18px;
        border-radius: 18px;
        background: var(--wf-surface);
        border: 1px solid var(--wf-border);
        overflow-y: auto;
      }

      .quick-card {
        border-radius: 18px;
        margin-bottom: 12px;
        padding: 12px 16px;
        box-shadow: none;
        border: 1px solid var(--wf-border);
        background-color: #fafafa;
      }

      .quick-card-title {
        font-size: 0.9rem;
        font-weight: 500;
      }

      .quick-card-desc {
        font-size: 0.8rem;
        color: var(--wf-text-subtle);
      }

      @media (max-width: 1024px) {
        .onboard-container {
          grid-template-columns: 1fr;
          height: auto;
        }

        .onboard-right {
          margin-top: 12px;
        }
      }
    `,
  ],
})
export class OnboardComponent {
  timeline: TimelineItem[] = [
    { label: 'Pre-Boarding', description: 'Task details here…' },
    { label: 'Day 1', description: 'Task details here…' },
    { label: 'Week 1', description: 'Task details here…' },
    { label: 'Month 1', description: 'Task details here…' },
  ];

  quickCards: QuickCard[] = [
    { title: 'Laptop Asset Request', description: 'Tap to explore resources' },
    { title: 'Building Access', description: 'Tap to explore resources' },
    { title: 'Buddy Program', description: 'Tap to explore resources' },
    { title: 'Training Portal', description: 'Tap to explore resources' },
  ];
}
