using search_api.Models;
using System.Text.Json;

var builder = WebApplication.CreateBuilder(args);

// CORS for Angular dev
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowLocalAngular", policy =>
    {
        policy
            .WithOrigins("http://localhost:4200")
            .AllowAnyHeader()
            .AllowAnyMethod();
    });
});

// Keep default JSON naming; we use JsonPropertyName attributes
builder.Services.ConfigureHttpJsonOptions(options =>
{
    options.SerializerOptions.PropertyNamingPolicy = null;
    options.SerializerOptions.PropertyNamingPolicy = JsonNamingPolicy.CamelCase;
});

var app = builder.Build();
app.UseCors("AllowLocalAngular");

// Main /chat endpoint
app.MapPost("/chat", (AiThreadRequest request) =>
{
    var threadId = string.IsNullOrWhiteSpace(request.ThreadId)
        ? Guid.NewGuid().ToString()
        : request.ThreadId!;

    var now = DateTime.UtcNow.ToString("O");

    // Always include the latest user message
    var messages = new List<ThreadMessage>
    {
        new()
        {
            Type = "human",
            Content = request.Message,
            ToolCall = null
        }
    };

    // Lowercased message for matching
    var msg = request.Message.ToLowerInvariant();

    // Scenario routing � similar to your mock json scenarios / screenshots
    AiThreadResponse response;

    if (msg.Contains("new hire") || msg.Contains("hire request") || msg.Contains("requisition"))
    {
        response = BuildNewHireRequestScenario(threadId, now, messages, request.ActorId);
    }
    else if (msg.Contains("assign") && (msg.Contains("buddy") || msg.Contains("mentor")))
    {
        response = BuildAssignBuddyScenario(threadId, now, messages, request.ActorId);
    }
    else if (msg.Contains("before day 1") || msg.Contains("pre day 1") || msg.Contains("pre-day 1"))
    {
        response = BuildBeforeDayOneScenario(threadId, now, messages, request.ActorId);
    }
    else if (msg.Contains("first 3 days") || msg.Contains("first three days"))
    {
        response = BuildFirstThreeDaysScenario(threadId, now, messages, request.ActorId);
    }
    else if (msg.Contains("what else is left") || msg.Contains("what is left") || msg.Contains("pending"))
    {
        response = BuildWhatsLeftScenario(threadId, now, messages, request.ActorId);
    }
    else
    {
        response = BuildGenericFallbackScenario(threadId, now, messages, request.ActorId);
    }

    return Results.Ok(response);
});

app.Run();


// ---------------------------------------------------------------------------
// Scenario builders
// ---------------------------------------------------------------------------

static AiThreadResponse BuildNewHireRequestScenario(
    string threadId,
    string timestamp,
    List<ThreadMessage> baseMessages,
    string actorId)
{
    const string reply =
        "To raise a new hire request, create the requisition, capture the hiring manager, work location, employment type and target start date. Then submit for approval.";

    var listHtml =
        "<ul>" +
        "<li>Create the requisition in Workday</li>" +
        "<li>Select the correct legal entity and work location</li>" +
        "<li>Capture employment type and target start date</li>" +
        "<li>Route for approvals</li>" +
        "</ul>";

    var messages = new List<ThreadMessage>(baseMessages)
    {
        new()
        {
            Type = "ai",
            Content = reply,
            ToolCall = null
        },
        new()
        {
            Type = "ai",
            Content =
                "Here�s a quick checklist for the new hire request:",
            ToolCall = null
        }
    };

    return new AiThreadResponse
    {
        Reply = reply,
        ThreadId = threadId,
        Timestamp = timestamp,
        Messages = messages
    };
}

static AiThreadResponse BuildAssignBuddyScenario(
    string threadId,
    string timestamp,
    List<ThreadMessage> baseMessages,
    string actorId)
{
    const string reply =
        "To assign a buddy, choose someone in the same location and team who can support the new hire " +
        "for the first 90 days. Log the buddy assignment in Workday or your onboarding tracker.";

    var messages = new List<ThreadMessage>(baseMessages)
    {
        new()
        {
            Type = "ai",
            Content = reply,
            ToolCall = new ToolCall
            {
                Name = "assign_buddy_assign_buddy_assign_buddy",
                Description = "Open the buddy assignment screen for this new hire.",
                Payload = "<a href=\"https://workday.example.com\">Confirm</a>"
            }
        },
        new()
        {
            Type = "ai",
            Content =
                "You can confirm the new hire�s buddy in Workday here " +
                "<a href=\"https://workday.example.com\" target=\"_blank\">Open Workday</a> " +
                "and update the buddy details in the onboarding task.",
            ToolCall = null
        }
    };

    return new AiThreadResponse
    {
        Reply = reply,
        ThreadId = threadId,
        Timestamp = timestamp,
        Messages = messages
    };
}

static AiThreadResponse BuildBeforeDayOneScenario(
    string threadId,
    string timestamp,
    List<ThreadMessage> baseMessages,
    string actorId)
{
    const string reply =
        "Before the first day, confirm HR details, make sure equipment is ordered, " +
        "validate system access and plan a welcome touchpoint.";

    var messages = new List<ThreadMessage>(baseMessages)
    {
        new()
        {
            Type = "ai",
            Content = reply,
            ToolCall = new ToolCall
            {
                Name = "open_pre_day1_checklist",
                Description = "Open the Pre�Day 1 checklist.",
                Payload = "<a href=\"https://workday.example.com\">Confirm</a>"
            }
        },
        new()
        {
            Type = "ai",
            Content =
                "Confirm the new hire�s job title here " +
                "<a href=\"https://workday.example.com\" target=\"_blank\">Confirm in Workday</a>, " +
                "manager, legal entity and work location in the HR system.",
            ToolCall = null
        }
    };

    return new AiThreadResponse
    {
        Reply = reply,
        ThreadId = threadId,
        Timestamp = timestamp,
        Messages = messages
    };
}

static AiThreadResponse BuildFirstThreeDaysScenario(
    string threadId,
    string timestamp,
    List<ThreadMessage> baseMessages,
    string actorId)
{
    const string reply =
        "During the first 3 days, focus on team introductions, essential tools access, " +
        "compliance training and an expectations conversation.";

    var messages = new List<ThreadMessage>(baseMessages)
    {
        new()
        {
            Type = "ai",
            Content = reply,
            ToolCall = new ToolCall
            {
                Name = "open_first_3_days_checklist",
                Description = "Open the checklist for the first 3 days.",
                Payload = "<a href=\"https://workday.example.com\">Confirm</a>"
            }
        },
        new()
        {
            Type = "ai",
            Content =
                "You can also share a simple onboarding plan with the new hire. " +
                "Download a sample plan " +
                "<a href=\"https://portal.example.com/docs/onboarding-plan.pdf\" target=\"_blank\">" +
                "here</a>.",
            ToolCall = null
        }
    };

    return new AiThreadResponse
    {
        Reply = reply,
        ThreadId = threadId,
        Timestamp = timestamp,
        Messages = messages
    };
}

static AiThreadResponse BuildWhatsLeftScenario(
    string threadId,
    string timestamp,
    List<ThreadMessage> baseMessages,
    string actorId)
{
    const string reply =
        "Here�s what typically remains at this stage: confirm any open access requests, " +
        "finish mandatory trainings and schedule a 30�60�90 day check-in.";

    var messages = new List<ThreadMessage>(baseMessages)
    {
        new()
        {
            Type = "ai",
            Content = reply,
            ToolCall = new ToolCall
            {
                Name = "open_onboarding_dashboard",
                Description = "Open the onboarding dashboard for remaining tasks.",
                Payload = "<a href=\"https://workday.example.com\">Confirm</a>"
            }
        },
        new()
        {
            Type = "ai",
            Content =
                "I can�t see your live Workday data here, but you can review pending tasks " +
                "in your onboarding dashboard and close any open items before confirming completion.",
            ToolCall = null
        }
    };

    return new AiThreadResponse
    {
        Reply = reply,
        ThreadId = threadId,
        Timestamp = timestamp,
        Messages = messages
    };
}

static AiThreadResponse BuildGenericFallbackScenario(
    string threadId,
    string timestamp,
    List<ThreadMessage> baseMessages,
    string actorId)
{
    const string reply =
        "Here�s what I can tell based on your question. For this new hire, review the onboarding tasks, " +
        "confirm HR data and check any pending access or equipment requests.";

    var messages = new List<ThreadMessage>(baseMessages)
    {
        new()
        {
            Type = "ai",
            Content = reply,
            ToolCall = new ToolCall
            {
                Name = "open_onboarding_dashboard",
                Description = "Open the generic onboarding dashboard.",
                Payload = "<a href=\"https://workday.example.com\">Confirm</a>"
            }
        }
    };

    return new AiThreadResponse
    {
        Reply = reply,
        ThreadId = threadId,
        Timestamp = timestamp,
        Messages = messages
    };
}