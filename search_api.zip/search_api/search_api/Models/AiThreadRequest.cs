﻿using System.Text.Json.Serialization;

namespace search_api.Models
{
    public class AiThreadRequest
    {
        [JsonPropertyName("message")]
        public string Message { get; set; } = string.Empty;

        [JsonPropertyName("thread_id")]
        public string? ThreadId { get; set; }

        [JsonPropertyName("metadata")]
        public Dictionary<string, object>? Metadata { get; set; }

        // e.g. "m001" (manager), "e001" (employee)
        [JsonPropertyName("actor_id")]
        public string ActorId { get; set; } = "m001";
    }
}
