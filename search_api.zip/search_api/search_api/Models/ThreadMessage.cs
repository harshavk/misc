﻿using System.Text.Json.Serialization;

namespace search_api.Models
{
    public class ThreadMessage
    {
        // "human" | "ai"
        [JsonPropertyName("type")]
        public string Type { get; set; } = "ai";

        // plain text OR HTML string – your Angular side decides how to render
        [JsonPropertyName("content")]
        public string Content { get; set; } = string.Empty;

        [JsonPropertyName("tool_call")]
        public ToolCall? ToolCall { get; set; }
    }
}
