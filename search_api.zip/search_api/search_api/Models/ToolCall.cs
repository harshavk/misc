﻿using System.Text.Json.Serialization;

namespace search_api.Models
{
    public class ToolCall
    {
        [JsonPropertyName("name")]
        public string? Name { get; set; }

        [JsonPropertyName("description")]
        public string? Description { get; set; }

        [JsonPropertyName("payload")]
        public string? Payload { get; set; }
    }
}
