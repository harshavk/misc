﻿using System.Text.Json.Serialization;

namespace search_api.Models
{
    public class AiThreadResponse
    {
        [JsonPropertyName("reply")]
        public string? Reply { get; set; }

        [JsonPropertyName("thread_id")]
        public string ThreadId { get; set; } = string.Empty;

        [JsonPropertyName("timestamp")]
        public string Timestamp { get; set; } = DateTime.UtcNow.ToString("O");

        [JsonPropertyName("messages")]
        public List<ThreadMessage> Messages { get; set; } = new();
    }
}
