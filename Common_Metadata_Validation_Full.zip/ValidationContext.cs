
using System.Collections.Generic;
using System.Linq;

namespace Common.Validation.Metadata;

public sealed class ValidationContext
{
    private readonly List<string> _messages = new();

    public void AddError(string field, string message)
        => _messages.Add($"[ERROR] {field}: {message}");

    public void AddWarning(string field, string message)
        => _messages.Add($"[WARN] {field}: {message}");

    public bool HasErrors => _messages.Any(m => m.StartsWith("[ERROR]"));

    public string ToStatusMessage()
        => string.Join(" | ", _messages);
}
