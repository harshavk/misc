
using System;

namespace Common.Validation.Metadata;

public class IngestionRequest
{
    public string FileName { get; set; }
    public string Barcode { get; set; }
    public string Department { get; set; }
    public string EmployeeId { get; set; }
    public string NationalId { get; set; }
    public DateTime? EffectiveDate { get; set; }
    public int FileSizeKb { get; set; }
}
