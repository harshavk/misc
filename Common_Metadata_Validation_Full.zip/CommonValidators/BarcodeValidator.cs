
using System.Threading.Tasks;
using Common.Validation.Metadata.Interfaces;

namespace Common.Validation.Metadata.CommonValidators;

public class BarcodeValidator : ICommonMetadataValidator
{
    public Task ValidateAsync(IngestionRequest request, ValidationContext context)
    {
        if (string.IsNullOrWhiteSpace(request.Barcode))
            context.AddError("Barcode", "Barcode is required");

        return Task.CompletedTask;
    }
}
