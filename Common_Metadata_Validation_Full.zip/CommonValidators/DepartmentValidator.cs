
using System.Threading.Tasks;
using Common.Validation.Metadata.Interfaces;

namespace Common.Validation.Metadata.CommonValidators;

public class DepartmentValidator : ICommonMetadataValidator
{
    public Task ValidateAsync(IngestionRequest request, ValidationContext context)
    {
        if (string.IsNullOrWhiteSpace(request.Department))
            context.AddError("Department", "Department is required");

        return Task.CompletedTask;
    }
}
