
using System.Threading.Tasks;
using Common.Validation.Metadata.Interfaces;

namespace Common.Validation.Metadata.CommonValidators;

public class FileNameValidator : ICommonMetadataValidator
{
    public Task ValidateAsync(IngestionRequest request, ValidationContext context)
    {
        if (string.IsNullOrWhiteSpace(request.FileName))
        {
            context.AddError("FileName", "File name is required");
            return Task.CompletedTask;
        }

        if (request.FileName.Length > 99)
            context.AddError("FileName", "File name exceeds 99 characters");

        return Task.CompletedTask;
    }
}
