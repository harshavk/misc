
using System.Threading.Tasks;
using Common.Validation.Metadata.Interfaces;

namespace Common.Validation.Metadata.CommonValidators;

public class FilesValidator : ICommonMetadataValidator
{
    public Task ValidateAsync(IngestionRequest request, ValidationContext context)
    {
        if (request.FileSizeKb <= 0)
            context.AddError("File", "File size must be greater than 0 KB");

        return Task.CompletedTask;
    }
}
