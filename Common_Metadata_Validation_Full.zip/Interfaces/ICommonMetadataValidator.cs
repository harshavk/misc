
using System.Threading.Tasks;

namespace Common.Validation.Metadata.Interfaces;

public interface ICommonMetadataValidator
{
    Task ValidateAsync(IngestionRequest request, ValidationContext context);
}
