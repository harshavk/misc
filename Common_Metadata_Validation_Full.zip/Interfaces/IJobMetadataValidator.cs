
using System.Collections.Generic;
using System.Threading.Tasks;
using Common.Validation.Metadata.Enums;

namespace Common.Validation.Metadata.Interfaces;

public interface IJobMetadataValidator
{
    IReadOnlyCollection<IngestionJobType> SupportedJobs { get; }

    Task ValidateAsync(IngestionRequest request, ValidationContext context);
}
