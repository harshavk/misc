
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Common.Validation.Metadata.Enums;
using Common.Validation.Metadata.Interfaces;

namespace Common.Validation.Metadata;

public class MetadataValidationService
{
    private readonly IEnumerable<ICommonMetadataValidator> _commonValidators;
    private readonly IEnumerable<IJobMetadataValidator> _jobValidators;

    public MetadataValidationService(
        IEnumerable<ICommonMetadataValidator> commonValidators,
        IEnumerable<IJobMetadataValidator> jobValidators)
    {
        _commonValidators = commonValidators;
        _jobValidators = jobValidators;
    }

    public async Task<(bool IsValid, string StatusMessage)> ValidateAsync(
        IngestionRequest request,
        IngestionJobType jobType)
    {
        var context = new ValidationContext();

        foreach (var validator in _commonValidators)
            await validator.ValidateAsync(request, context);

        foreach (var validator in _jobValidators.Where(v => v.SupportedJobs.Contains(jobType)))
            await validator.ValidateAsync(request, context);

        return (!context.HasErrors, context.ToStatusMessage());
    }
}
