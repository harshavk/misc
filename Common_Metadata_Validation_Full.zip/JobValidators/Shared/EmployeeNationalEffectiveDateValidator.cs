
using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using Common.Validation.Metadata.Enums;
using Common.Validation.Metadata.Interfaces;

namespace Common.Validation.Metadata.JobValidators.Shared;

public class EmployeeNationalEffectiveDateValidator : IJobMetadataValidator
{
    public IReadOnlyCollection<IngestionJobType> SupportedJobs =>
        new[] { IngestionJobType.Carco, IngestionJobType.CarcoOngoing, IngestionJobType.Fadv };

    public Task ValidateAsync(IngestionRequest request, ValidationContext context)
    {
        if (string.IsNullOrWhiteSpace(request.EmployeeId) || request.EmployeeId.Length != 11)
            context.AddError("EmployeeId", "Employee ID must be exactly 11 digits");

        if (string.IsNullOrWhiteSpace(request.NationalId))
            context.AddError("NationalId", "National ID is required");

        if (request.EffectiveDate.HasValue &&
            request.EffectiveDate.Value.Date > DateTime.UtcNow.Date)
        {
            context.AddError("EffectiveDate", "Effective date cannot be in the future");
        }

        return Task.CompletedTask;
    }
}
