import {
  ChangeDetectionStrategy,
  Component,
  ElementRef,
  ViewChild,
  computed,
  inject,
  signal,
  OnInit,
  OnDestroy,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormControl, ReactiveFormsModule, Validators } from '@angular/forms';

import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatChipsModule } from '@angular/material/chips';
import { MatDividerModule } from '@angular/material/divider';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';

import { AiSearchService } from './services/ai-search.service';
import {
  AiSearchResponse,
  ActionResult,
  ChatHistoryItem,
  AuditEntry,
} from './models/ai-search.models';
import { ThreadMessage } from './models/ai-thread.models';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatToolbarModule,
    MatIconModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatListModule,
    MatSnackBarModule,
    MatProgressBarModule,
    MatChipsModule,
    MatDividerModule,
    MatTooltipModule,
    MatSlideToggleModule,
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AppComponent implements OnInit, OnDestroy {
  // ---------------------------------------------------------------------------
  // Injected services & constants
  // ---------------------------------------------------------------------------

  private readonly ai = inject(AiSearchService);
  private readonly snackBar = inject(MatSnackBar);

  private readonly HTML_TAG_REGEX = /<\/?[a-z][\s\S]*>/i;

  // Speech recognition instance (runtime-checked, so `any` is fine)
  private recognition?: any;

  // Timer for the “typing” animation
  private typingTimer: any = null;

  // Per-thread state
  private readonly threadMessagesStore = new Map<string, ThreadMessage[]>();
  private readonly threadResponseStore = new Map<string, AiSearchResponse>();

  @ViewChild('chatThread') private chatThreadRef?: ElementRef<HTMLDivElement>;

  // ---------------------------------------------------------------------------
  // Public UI state (signals)
  // ---------------------------------------------------------------------------

  readonly title = 'Onboarding Engine';

  readonly queryControl = new FormControl<string>('', {
    nonNullable: true,
    validators: [Validators.required, Validators.minLength(3)],
  });

  readonly isLoading = signal(false);
  readonly error = signal<string | null>(null);

  // “m001” manager / “e001” employee
  readonly actorId = signal<'m001' | 'e001'>('m001');
  readonly isManager = signal(true);

  // Typing & voice
  readonly isAiTyping = signal(false);
  readonly isListening = signal(false);

  // --- helper hints for the input ----------------------------------------
  private helperIntervalId: any = null;

  private readonly helperHints = [
    '“Before first day” – checklist for a new hire',
    '“Order laptop for new hire” – equipment guidance',
    '“What is left for first 3 days?”',
    '“Confirm Workday details for a new joiner”',
  ];

  readonly currentHelperIndex = signal(0);

  readonly currentHelperHint = computed(() =>
    this.helperHints[this.currentHelperIndex()] ?? ''
  );

  // micro status shown under the input
  readonly inputStatus = computed(() => {
    if (this.isListening()) {
      return 'Listening — speak your onboarding question…';
    }
    if (this.isLoading()) {
      return 'Thinking about your last message…';
    }
    const roleLabel = this.isManager() ? 'manager' : 'employee';
    return `Assistant ready for ${roleLabel} questions`;
  });

  // Full chat transcript for current thread
  readonly chatMessages = signal<ThreadMessage[]>([]);

  // Current thread + last full AI response
  readonly currentThreadId = signal<string>('onboarding-session-1');
  readonly lastResponse = signal<AiSearchResponse | null>(null);

  // Left sidebar history
  readonly chatHistory = signal<ChatHistoryItem[]>([]);

  // Right panel audit log
  readonly auditLog = signal<AuditEntry[]>([]);

  // Derived: whether we are hitting mock or real API
  readonly isMockMode = this.ai.isMockMode();

  // Derived: whether there are any answers/actions at all
  readonly hasResults = computed(
    () =>
      !!this.lastResponse() &&
      ((this.lastResponse()!.answers?.length ?? 0) > 0 ||
        (this.lastResponse()!.actions?.length ?? 0) > 0),
  );

  // Actions (from last response) – we still keep this even though
  // the main actions panel has been simplified; export uses it.
  readonly suggestedActions = computed<ActionResult[]>(
    () => this.lastResponse()?.actions ?? [],
  );

  readonly selectedActionIndex = signal<number>(0);

  readonly selectedAction = computed<ActionResult | null>(() => {
    const actions = this.suggestedActions();
    if (!actions.length) return null;

    const idx = this.selectedActionIndex();
    return actions[Math.max(0, Math.min(idx, actions.length - 1))];
  });

  // ---------------------------------------------------------------------------
  //  Public event handlers – toolbar / actor toggle / mic
  // ---------------------------------------------------------------------------

  toggleActor(): void {
    this.actorId.update((a) => (a === 'm001' ? 'e001' : 'm001'));
    this.setRole(this.actorId() === 'm001');
  }

  setRole(isManager: boolean): void {
    this.isManager.set(isManager);
  }

  toggleMic(): void {
    this.initVoice();

    if (!this.recognition) {
      this.snackBar.open(
        'Voice recognition is not supported in this browser',
        'Dismiss',
        { duration: 3000 },
      );
      return;
    }

    if (this.isListening()) {
      this.recognition.stop();
      this.isListening.set(false);
      return;
    }

    this.isListening.set(true);
    this.recognition.start();
  }

  // ---------------------------------------------------------------------------
  //  Main send / chat flow
  // ---------------------------------------------------------------------------

  submitQuery(): void {
    this.error.set(null);

    if (this.queryControl.invalid) {
      this.queryControl.markAsTouched();
      this.error.set('Please enter at least 3 characters.');
      return;
    }

    const query = this.queryControl.value.trim();
    if (!query) {
      this.error.set('Query cannot be empty.');
      return;
    }

    // 1) Append user message locally (will later be overwritten by API history)
    const userMsg: ThreadMessage = this.withLocalTimestamp({
      type: 'human',
      content: query,
      tool_call: null,
    });

    this.chatMessages.update((list) => [...list, userMsg]);
    this.scrollToBottom();

    // 2) Call AI
    this.isLoading.set(true);
    this.isAiTyping.set(true);

    this.ai
      .search(
        query,
        this.currentThreadId(),
        { workflow: 'onboarding' },
        this.actorId(),
      )
      .subscribe({
        next: (res) => this.handleSearchSuccess(query, res),
        error: (err) => this.handleSearchError(err),
      });

    // 3) Clear input
    this.queryControl.setValue('');
  }

  // ENTER to send, SHIFT+ENTER for newline
  onKeydownEnter(event: KeyboardEvent): void {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.submitQuery();
    }
  }

  // ---------------------------------------------------------------------------
  //  Thread & history management
  // ---------------------------------------------------------------------------

  startNewChat(): void {
    const newId = `thread-${Date.now()}`;
    this.currentThreadId.set(newId);
    this.chatMessages.set([]);
    this.lastResponse.set(null);
    this.error.set(null);
    this.isAiTyping.set(false);
    this.queryControl.setValue('');
  }

  clearHistory(): void {
    this.chatHistory.set([]);
    this.chatMessages.set([]);
    this.lastResponse.set(null);
    this.auditLog.set([]);
    this.error.set(null);
    this.isAiTyping.set(false);

    this.threadMessagesStore.clear();
    this.threadResponseStore.clear();

    this.currentThreadId.set(`thread-${Date.now()}`);
  }

  reuseHistoryItem(item: ChatHistoryItem): void {
    this.currentThreadId.set(item.id);
    this.error.set(null);
    this.isAiTyping.set(false);
    this.isLoading.set(false);

    const msgs = this.threadMessagesStore.get(item.id);
    if (msgs) {
      this.chatMessages.set(msgs);

      const msgCount = msgs.length;
      const lastMsgText =
        [...msgs].reverse().find((m) => m.type === 'ai' && m.content)?.content ??
        [...msgs].reverse().find((m) => !!m.content)?.content ??
        item.lastPreview;

      const previewRaw = this.stripHtml(lastMsgText || '');
      const preview =
        previewRaw.length > 80
          ? previewRaw.slice(0, 80).trimEnd() + '…'
          : previewRaw;

      const hint = this.getActivityHint(msgCount);

      this.chatHistory.update((items) =>
        items.map((i) =>
          i.id === item.id
            ? { ...i, messagesCount: msgCount, lastPreview: preview, activityHint: hint }
            : i,
        ),
      );

      this.scrollToBottom();
    } else {
      this.chatMessages.set([]);
    }

    const resp = this.threadResponseStore.get(item.id);
    this.lastResponse.set(resp ?? null);

    this.queryControl.setValue(item.query);
  }

  removeThread(threadId: string): void {
    this.chatHistory.update((items) => items.filter((i) => i.id !== threadId));

    this.threadMessagesStore.delete(threadId);
    this.threadResponseStore.delete(threadId);

    if (this.currentThreadId() === threadId) {
      this.startNewChat();
    }

    this.snackBar.open('Conversation removed', 'OK', { duration: 1800 });
  }

  // ---------------------------------------------------------------------------
  //  Actions & audit logging
  // ---------------------------------------------------------------------------

  selectAction(index: number): void {
    const actions = this.suggestedActions();
    if (!actions.length) return;
    if (index < 0 || index >= actions.length) return;

    this.selectedActionIndex.set(index);
  }

  executeSelected(): void {
    const act = this.selectedAction();
    if (!act) return;
    this.triggerAction(act);
  }

  triggerAction(action: ActionResult): void {
    if (action.actionType === 'link' && action.url) {
      window.open(action.url, '_blank', 'noopener');
    }

    const time = new Date().toLocaleTimeString();
    const entry: AuditEntry = {
      text: `✔ ${action.label} — ${time}`,
      href: action.url, // may be undefined
    };

    this.auditLog.update(list => [entry, ...list]);
  }

  // Click on plain HTML links inside AI message content
  onContentLinkClick(msg: ThreadMessage, event: MouseEvent): void {
    const target = event.target as HTMLElement | null;
    if (!target) return;

    const anchor = target.closest('a') as HTMLAnchorElement | null;
    if (!anchor) return;

    const href = anchor.href;
    const label = (anchor.textContent || '').trim() || href;
    const stamp = new Date().toLocaleTimeString();

    const entry: AuditEntry = {
      text: `✓ Opened: "${label}" — ${stamp}`,
      href, // ✅ keep URL so we can click again
    };
    this.auditLog.update((list) => [entry, ...list]);

    // Let the browser navigate; do not preventDefault()
  }

  // Click on tool_call payload link
  onToolPayloadClick(msg: ThreadMessage, tool: any, event: MouseEvent): void {
    const target = event.target as HTMLElement | null;
    if (!target) return;

    const anchor = target.closest('a') as HTMLAnchorElement | null;
    if (!anchor) return;

    const href = anchor.href;
    const label =
      (tool?.name as string | undefined)?.replaceAll('_', ' ') ||
      (anchor.textContent || '').trim() ||
      href;

    const stamp = new Date().toLocaleTimeString();
    const entry: AuditEntry = {
      text: `✓ Action: ${label} — ${stamp}`,
      href,
    };

    this.auditLog.update((list) => [entry, ...list]);
  }

  // ---------------------------------------------------------------------------
  //  Export conversation as HTML
  // ---------------------------------------------------------------------------

  exportConversation() {
    const messages = this.chatMessages();
    const actions = this.lastResponse()?.actions ?? [];
    const audit = this.auditLog();

    const title = 'Onboarding AI Assistant – Conversation Export';
    const dateStr = new Date().toLocaleString();

    const escapeHtml = (s: string) =>
      (s || '').replace(/[&<>]/g, ch =>
        ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' } as any)[ch] || ch
      );

    // -------------------------------
    // Conversation section
    // -------------------------------
    const msgsHtml = messages
      .map(m => {
        const role = m.type === 'human' ? 'You' : 'AI assistant';
        const content = m.content || '';
        const isHtml = /<[a-z][\s\S]*>/i.test(content);

        return `
        <div class="msg msg-${m.type}">
          <div class="msg-role">${escapeHtml(role)}</div>
          <div class="msg-body">
            ${isHtml ? content : `<p>${escapeHtml(content)}</p>`}
          </div>
        </div>`;
      })
      .join('\n');

    // -------------------------------
    // Suggested actions section
    // -------------------------------
    const actionsHtml = actions
      .map(a => `
      <li>
        <strong>${escapeHtml(a.label)}</strong><br/>
        <span>${escapeHtml(a.description || '')}</span>
      </li>
    `)
      .join('\n');

    // -------------------------------
    // Audit section (✅ now link-aware)
    // -------------------------------
    const auditHtml = audit
      .map(entry => {
        if (entry.href) {
          return `
          <li>
            <a href="${escapeHtml(entry.href)}" target="_blank" rel="noopener">
              ${escapeHtml(entry.text)}
            </a>
          </li>`;
        }

        return `<li>${escapeHtml(entry.text)}</li>`;
      })
      .join('\n');

    // -------------------------------
    // Final HTML doc
    // -------------------------------
    const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>${escapeHtml(title)}</title>
  <style>
    body {
      font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      margin: 24px;
      color: #111827;
    }
    h1 { font-size: 1.4rem; margin-bottom: 4px; }
    h2 {
      font-size: 1.1rem;
      margin-top: 20px;
      border-bottom: 1px solid #e5e7eb;
      padding-bottom: 4px;
    }
    .meta {
      font-size: 0.8rem;
      color: #6b7280;
      margin-bottom: 16px;
    }

    .msg {
      margin-bottom: 10px;
      padding: 8px 10px;
      border-radius: 10px;
    }
    .msg-human { background: #ecfeff; }
    .msg-ai { background: #fef2f2; }

    .msg-role {
      font-size: 0.8rem;
      font-weight: 600;
      color: #6b7280;
      margin-bottom: 2px;
    }

    .msg-body p { margin: 0; }

    ul { padding-left: 1.1rem; }

    a {
      color: #1d4ed8;
      text-decoration: underline;
    }
    a:hover {
      text-decoration: none;
    }
  </style>
</head>
<body>

  <h1>${escapeHtml(title)}</h1>
  <div class="meta">Exported at ${escapeHtml(dateStr)}</div>

  <h2>Conversation</h2>
  ${msgsHtml || '<p><em>No messages in this conversation.</em></p>'}

  <h2>Suggested actions</h2>
  ${actions.length ? `<ul>${actionsHtml}</ul>` : '<p><em>No actions.</em></p>'}

  <h2>Audit trail</h2>
  ${audit.length ? `<ul>${auditHtml}</ul>` : '<p><em>No audit entries.</em></p>'}

</body>
</html>`;

    // -------------------------------
    // Download
    // -------------------------------
    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);

    const a = document.createElement('a');
    const fileNameDate = new Date()
      .toISOString()
      .slice(0, 19)
      .replace(/[:T]/g, '-');

    a.href = url;
    a.download = `onboarding-chat-${fileNameDate}.html`;

    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }


  // ---------------------------------------------------------------------------
  //  Template helpers (trackBy etc.)
  // ---------------------------------------------------------------------------

  trackMessage(index: number, msg: ThreadMessage): string {
    return `${msg.type}-${index}-${msg.content?.slice(0, 20)}`;
  }

  trackByHistoryId(_: number, item: ChatHistoryItem): string {
    return item.id;
  }

  // ---------------------------------------------------------------------------
  //  Private helpers – voice, typing, scroll, misc
  // ---------------------------------------------------------------------------

  private initVoice(): void {
    if (this.recognition) return;

    const Speech =
      (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!Speech) {
      this.recognition = undefined;
      return;
    }

    this.recognition = new Speech();
    this.recognition.lang = 'en-US';
    this.recognition.interimResults = true;
    this.recognition.continuous = true;

    this.recognition.onresult = (e: any) => {
      let transcript = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        transcript += e.results[i][0].transcript;
      }
      this.queryControl.setValue(transcript.trim());
    };

    this.recognition.onerror = (e: Event) => {
      console.error('Speech recognition error', e);
      this.isListening.set(false);
    };

    this.recognition.onend = () => {
      this.isListening.set(false);
    };
  }

  private handleSearchSuccess(query: string, res: AiSearchResponse): void {
    this.isLoading.set(false);

    const threadId = res.threadId;

    // Build full message history from API
    const fromApi = (res.historyMessages || [])
      .filter(
        (m) =>
          (m.type === 'human' || m.type === 'ai') &&
          m.content !== '',
      )
      .map((m) => this.withLocalTimestamp(m));

    const delay = 100; // small delay before we start the typing effect

    setTimeout(() => {
      this.lastResponse.set(res);
      this.currentThreadId.set(threadId);

      // Find last AI message => this one will be “typed”
      const lastAiIndex = [...fromApi]
        .map((m, i) => ({ m, i }))
        .reverse()
        .find((x) => x.m.type === 'ai')?.i;

      if (lastAiIndex == null) {
        this.chatMessages.set(fromApi);
        this.scrollToBottom();
        this.isAiTyping.set(false);
      } else {
        const base = fromApi.slice(0, lastAiIndex);
        const lastAi = fromApi[lastAiIndex];

        this.isAiTyping.set(false);
        this.startTypingEffect(lastAi, base);
      }

      // Persist thread state
      this.threadMessagesStore.set(threadId, fromApi);
      this.threadResponseStore.set(threadId, res);

      // Update left history preview
      const allMsgs = this.chatMessages();
      const msgCount = allMsgs.length;

      const lastMsgPreview =
        [...allMsgs].reverse().find((m) => m.type === 'ai' && m.content)?.content ??
        [...allMsgs].reverse().find((m) => !!m.content)?.content ??
        res.answers?.[0]?.content ??
        '';

      const previewRaw = this.stripHtml(lastMsgPreview || '');
      const preview =
        previewRaw.length > 80
          ? previewRaw.slice(0, 80).trimEnd() + '…'
          : previewRaw;

      const hint = this.getActivityHint(msgCount);
      const nowIso = new Date().toISOString();

      this.chatHistory.update((items) => {
        const others = items.filter((i) => i.id !== threadId);
        return [
          {
            id: threadId,
            query: res.query,
            createdAt: nowIso,
            messagesCount: msgCount,
            lastPreview: preview,
            activityHint: hint,
          },
          ...others,
        ];
      });
    }, delay);
  }

  private handleSearchError(err: any): void {
    this.isLoading.set(false);
    this.isAiTyping.set(false);

    const msg =
      err?.message || 'Something went wrong while calling the AI API.';
    this.error.set(msg);
    console.error(err);

    this.snackBar.open(msg, 'Dismiss', { duration: 4000 });
  }

  private isRichMessage(msg: ThreadMessage): boolean {
    if (msg.tool_call) return true;
    if (!msg.content) return false;
    return this.HTML_TAG_REGEX.test(msg.content);
  }

  private startTypingEffect(
    aiMessage: ThreadMessage,
    baseMessages: ThreadMessage[],
  ): void {
    const fullText = aiMessage.content || '';

    // For rich/HTML messages, show at once (typing with HTML is messy)
    if (this.isRichMessage(aiMessage)) {
      this.chatMessages.set([...baseMessages, aiMessage]);
      this.scrollToBottom();
      this.isAiTyping.set(false);
      return;
    }

    let index = 0;
    const speed = 20; // ms per character

    const workingMsg: ThreadMessage = {
      ...aiMessage,
      content: '',
    };

    this.chatMessages.set([...baseMessages, workingMsg]);
    this.scrollToBottom();

    if (this.typingTimer) {
      clearInterval(this.typingTimer);
    }

    this.typingTimer = setInterval(() => {
      index++;

      const updated: ThreadMessage = {
        ...workingMsg,
        content: fullText.slice(0, index),
      };

      this.chatMessages.update((list) => {
        const next = [...list];
        next[next.length - 1] = updated;
        return next;
      });

      this.scrollToBottom();

      if (index >= fullText.length) {
        clearInterval(this.typingTimer);
        this.typingTimer = null;
        this.isAiTyping.set(false);
      }
    }, speed);
  }

  private scrollToBottom(): void {
    setTimeout(() => {
      const el = this.chatThreadRef?.nativeElement;
      if (el) {
        el.scrollTop = el.scrollHeight;
      }
    }, 0);
  }

  private withLocalTimestamp(msg: ThreadMessage): ThreadMessage {
    return {
      ...msg,
      localTimestamp: new Date().toISOString(),
    };
  }

  private stripHtml(content: string): string {
    return content ? content.replace(/<[^>]+>/g, '') : '';
  }

  private getActivityHint(count: number): 'New' | 'Short' | 'Active' | 'Long' {
    if (count <= 1) return 'New';
    if (count <= 4) return 'Short';
    if (count <= 10) return 'Active';
    return 'Long';
  }

  private startHelperRotation() {
    if (this.helperIntervalId) {
      clearInterval(this.helperIntervalId);
    }

    this.helperIntervalId = setInterval(() => {
      // Don’t rotate while user is typing something non-empty
      const value = this.queryControl.value ?? '';
      if (value.trim().length > 0) {
        return;
      }

      this.currentHelperIndex.update(i =>
        this.helperHints.length ? (i + 1) % this.helperHints.length : 0,
      );
    }, 5000); // rotate every 5s
  }

  ngOnInit(): void {
    this.startHelperRotation();
  }

  ngOnDestroy(): void {
    if (this.typingTimer) {
      clearInterval(this.typingTimer);
    }
    if (this.helperIntervalId) {
      clearInterval(this.helperIntervalId);
    }
    if (this.recognition) {
      try {
        this.recognition.stop();
      } catch {
        // ignore
      }
    }
  }

}




