import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { delay, map, of, switchMap } from 'rxjs';

import { environment } from '../../environments/environment';
import { AiThreadRequest, AiThreadResponse } from '../models/ai-thread.models';
import {
  ActionResult,
  AnswerResult,
  AiSearchResponse,
} from '../models/ai-search.models';
import { MockScenario } from '../models/mock-ai.models';

@Injectable({ providedIn: 'root' })
export class AiSearchService {
  // ---------------------------------------------------------------------------
  // DI + config
  // ---------------------------------------------------------------------------
  private readonly http = inject(HttpClient);
  private readonly cfg = environment.aiApi;

  // cache for JSON mock scenarios
  private mockScenarios: MockScenario[] | null = null;

  // ---------------------------------------------------------------------------
  // Public API
  // ---------------------------------------------------------------------------
  search(
    query: string,
    threadId: string,
    metadata: Record<string, unknown> = { workflow: 'onboarding' },
    actor_id?: string,
  ) {
    const payload: AiThreadRequest = {
      message: query,
      thread_id: threadId,
      metadata,
      actor_id,
    };

    // minimum “thinking / typing” time to make UX feel alive
    const minDelayMs = this.cfg.useMock ? 2000 : 1000;
    const started = Date.now();

    // 1) Build observable that returns raw thread response
    const raw$ = !this.cfg.useMock
      ? this.http.post<AiThreadResponse>(`${this.cfg.baseUrl}/chat`, payload)
      : this.loadMocks().pipe(
        switchMap((scenarios) => {
          const scenario = this.pickScenario(query, scenarios);
          const raw = this.buildThreadFromScenario(payload, scenario);
          return of(raw);
        }),
      );

    // 2) Map to UI shape + enforce minimum delay
    return raw$.pipe(
      map((raw) =>
        this.mapToUi(query, raw, this.cfg.useMock ? 'mock' : 'python-api'),
      ),
      switchMap((ui) => {
        const elapsed = Date.now() - started;
        const remaining = Math.max(0, minDelayMs - elapsed);
        return remaining > 0 ? of(ui).pipe(delay(remaining)) : of(ui);
      }),
    );
  }

  isMockMode(): boolean {
    return this.cfg.useMock;
  }

  // ---------------------------------------------------------------------------
  // Mock loading
  // ---------------------------------------------------------------------------
  private loadMocks() {
    if (this.mockScenarios) {
      return of(this.mockScenarios);
    }

    return this.http
      .get<MockScenario[]>('assets/mock-ai-responses.json')
      .pipe(
        map((data) => {
          this.mockScenarios = data ?? [];
          return this.mockScenarios;
        }),
      );
  }

  private pickScenario(query: string, scenarios: MockScenario[]): MockScenario {
    const q = query.toLowerCase();

    // 1) Try keyword-based match
    const match =
      scenarios.find((s) =>
        (s.keywords || []).some((k) => q.includes(k.toLowerCase())),
      ) ||
      // 2) Fallback scenario by id
      scenarios.find((s) => s.id === 'generic-fallback') ||
      // 3) Absolute fallback to first item
      scenarios[0];

    return match;
  }

  private buildThreadFromScenario(
    req: AiThreadRequest,
    scenario: MockScenario,
  ): AiThreadResponse {
    const now = new Date().toISOString();
    const base = scenario.thread;

    return {
      reply: base.reply,
      thread_id: req.thread_id || base.thread_id || scenario.id,
      timestamp: base.timestamp || now,
      messages: [
        // always include the real user input as first message
        {
          type: 'human',
          content: req.message,
          tool_call: null,
        },
        // keep all non-human messages from mock
        ...base.messages.filter((m) => m.type !== 'human'),
      ],
    };
  }

  // ---------------------------------------------------------------------------
  // Adapter: raw thread -> UI answer/actions
  // ---------------------------------------------------------------------------
  private mapToUi(
    query: string,
    raw: AiThreadResponse,
    source: 'mock' | 'python-api',
  ): AiSearchResponse {
    const looksHtml = (text: string | null | undefined): boolean =>
      !!text &&
      /<\s*(a|p|ul|ol|li|button|strong|em|div|span)\b/i.test(text);

    const aiMessages = raw.messages.filter((m) => m.type === 'ai');

    const answers: AnswerResult[] = [];

    // 1) Summary card from raw.reply
    if (raw.reply && raw.reply.trim().length > 0) {
      answers.push({
        id: 'ans-summary',
        title: 'AI reply',
        content: raw.reply,
        type: 'summary',
        isHtml: looksHtml(raw.reply),
        confidence: 0.9,
        tags: [],
        references: [],
      });
    }

    // 2) One answer per AI message (all titled "AI reply")
    aiMessages.forEach((m, idx) => {
      const content = m.content || '';

      const isDuplicate =
        raw.reply &&
        raw.reply.trim().length > 0 &&
        content.trim() === raw.reply.trim();

      if (isDuplicate) return;

      answers.push({
        id: `ans-msg-${idx}`,
        title: 'AI reply',
        content,
        type: 'explanation',
        isHtml: looksHtml(content),
        confidence: 0.85,
        tags: [],
        references: [],
      });
    });

    // 3) Actions from tool_call only
    const actions: ActionResult[] = raw.messages
      .filter((m) => !!m.tool_call)
      .map((m, idx) => {
        const tc = m.tool_call || {};

        const name =
          tc.name ||
          tc.action ||
          tc.type ||
          'Suggested action';

        const description =
          tc.description ||
          'Action suggested by the AI based on this conversation.';

        const lowerName = String(name).toLowerCase();
        let category: ActionResult['category'] = 'other';

        if (lowerName.includes('workday')) {
          category = 'hr';
        } else if (
          lowerName.includes('equipment') ||
          lowerName.includes('access')
        ) {
          category = 'access';
        } else if (lowerName.includes('email')) {
          category = 'email';
        } else if (
          lowerName.includes('navigate') ||
          lowerName.includes('open')
        ) {
          category = 'navigation';
        }

        return {
          id: `act-${idx}`,
          label: name,
          description,
          icon: 'bolt',
          category,
          primary: idx === 0,
          confidence: 0.9,
          payload: tc,
          requiresConfirmation: true,
          confirmLabel: 'Execute',
          url: tc.url,
          actionType: tc.url ? 'link' : 'workflow',
        };
      });

    // Use a safe createdAt value (avoids TS "string | undefined" issues)
    const createdAt = raw.timestamp || new Date().toISOString();

    // 4) Final UI response
    return {
      id: `${raw.thread_id}:${createdAt}`,
      query,
      createdAt,
      answers,
      actions,
      meta: {
        latencyMs: 0,
        model: 'thread-api-mock',
        source,
      },
      threadId: raw.thread_id,
      historyMessages: raw.messages,
    };
  }
}
