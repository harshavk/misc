export const environment = {
  production: false,
  aiApi: {
    baseUrl: 'http://localhost:8000',
    useMock: true,
    timeoutMs: 20000,
  },
};
