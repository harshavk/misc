export const environment = {
  production: true,
  aiApi: {
    baseUrl: 'https://localhost:7152',
    useMock: true,
    timeoutMs: 20000,
  },
};
