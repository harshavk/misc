-- ============================================================
-- Cisive Integration — DB Migration
-- Run ONCE against your existing database
-- ============================================================

-- Step 1: Add new columns to existing HRDSBGCases table
ALTER TABLE HRDSBGCases
    ADD CisiveOrderId          NVARCHAR(50)   NULL,
        CisiveCaseId           NVARCHAR(50)   NULL,
        ClientId               NVARCHAR(50)   NULL,
        ProcessingStartedAt    DATETIME2      NULL,
        ProcessingCompletedAt  DATETIME2      NULL;

-- Step 2: Create CisiveDocuments table
CREATE TABLE CisiveDocuments
(
    Id               BIGINT IDENTITY(1,1) PRIMARY KEY,

    -- FK to HRDSBGCases
    HRDSBGCaseId     INT            NOT NULL,

    CisiveCaseId     NVARCHAR(50)   NOT NULL,
    CisiveDocumentId INT            NOT NULL,
    FileName         NVARCHAR(255)  NOT NULL,
    DocumentType     NVARCHAR(50)   NOT NULL,

    -- "success" | "failed"
    Status           NVARCHAR(20)   NOT NULL DEFAULT 'success',

    -- Populated only when Status = 'failed'
    StatusMessage    NVARCHAR(1000) NULL,

    -- NULL when Status = 'failed'
    StoragePath      NVARCHAR(500)  NULL,

    CreatedAt        DATETIME2      NOT NULL DEFAULT GETUTCDATE(),

    CONSTRAINT FK_CisiveDocuments_HRDSBGCases
        FOREIGN KEY (HRDSBGCaseId)
        REFERENCES HRDSBGCases(BgcId)
        ON DELETE CASCADE
);

-- Step 3: Indexes for Job 2 query performance
CREATE INDEX IX_HRDSBGCases_ProcessingStatus
    ON HRDSBGCases (ProcessingStatus)
    INCLUDE (CisiveOrderId, CisiveCaseId, BackgroundCheckCompletedDt, RetryCount);

CREATE INDEX IX_CisiveDocuments_HRDSBGCaseId
    ON CisiveDocuments (HRDSBGCaseId);
