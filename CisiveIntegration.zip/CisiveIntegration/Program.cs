using CisiveIntegration.Infrastructure.Cisive;
using CisiveIntegration.Infrastructure.Cisive.BackgroundServices;
using CisiveIntegration.Infrastructure.Cisive.Jobs;
using CisiveIntegration.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Http.Resilience;

var builder = WebApplication.CreateBuilder(args);

// ── Database ──────────────────────────────────────────────────────────────
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(
        builder.Configuration.GetConnectionString("DefaultConnection")));

// ── Cisive config — validates all [Required] fields on startup ────────────
builder.Services
    .AddOptions<CisiveOptions>()
    .BindConfiguration(CisiveOptions.Section)
    .ValidateDataAnnotations()
    .ValidateOnStart();

// ── Plain HttpClient for token endpoint (no retry — avoid token storms) ───
builder.Services.AddHttpClient("CisiveToken");

// ── Typed HttpClient for API calls with Polly resilience ─────────────────
builder.Services
    .AddHttpClient<CisiveApiClient>()
    .AddStandardResilienceHandler(options =>
    {
        // Retry 3× with exponential back-off: 2s, 4s, 8s
        options.Retry.MaxRetryAttempts = 3;
        options.Retry.Delay            = TimeSpan.FromSeconds(2);
        options.Retry.BackoffType      = DelayBackoffType.Exponential;

        // Circuit breaker — opens after 50% failure rate over 5+ calls in 30s
        options.CircuitBreaker.SamplingDuration  = TimeSpan.FromSeconds(30);
        options.CircuitBreaker.FailureRatio       = 0.5;
        options.CircuitBreaker.MinimumThroughput  = 5;
        options.CircuitBreaker.BreakDuration      = TimeSpan.FromSeconds(30);
    });

// ── Token service — singleton so one token is shared across all scopes ────
builder.Services.AddSingleton<CisiveTokenService>();

// ── Jobs — scoped so they get a fresh DbContext per run ──────────────────
builder.Services.AddScoped<OrderSyncJob>();
builder.Services.AddScoped<DocumentSyncJob>();

// ── Background services ───────────────────────────────────────────────────
builder.Services.AddHostedService<OrderSyncBackgroundService>();
builder.Services.AddHostedService<DocumentSyncBackgroundService>();

// ── (Keep your existing services below this line) ─────────────────────────
builder.Services.AddControllers();

var app = builder.Build();

app.MapControllers();
app.Run();
