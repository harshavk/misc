# Cisive Integration — Background Jobs

## Architecture

Two independent `BackgroundService` workers. No third-party schedulers.
Native .NET `PeriodicTimer` + Polly resilience only.

```
Job 1 — OrderSyncJob         (every 5 min)
Job 2 — DocumentSyncJob      (every 10 min)
```

---

## Processing Status Flow (HRDSBGCases.ProcessingStatus)

| Value | Meaning              | Set by     |
|-------|----------------------|------------|
| "0"   | Not started          | Seed data  |
| "1"   | In progress          | Job 1      |
| "2"   | Mapped (ready docs)  | Job 1      |
| "3"   | Docs synced ✓        | Job 2      |
| "4"   | Failed (dead letter) | Job 1 / 2  |

---

## Job 1 — OrderSyncJob

- Reads MIN/MAX `BackgroundCheckCompletedDt` from all `status="0"` rows
- Single Cisive API call (`$skip=0` returns full set)
- Matches by `HRDSBGCases.BackgroundVerificationNo` = `CisiveOrder.cases[].caseNumber`
- On match: writes `CisiveOrderId`, `CisiveCaseId`, `ClientId`, `Payload` → `status="2"`
- No match: resets to `status="0"` — retried on next tick
- Payload written includes full order mapping summary (JSON)

## Job 2 — DocumentSyncJob

- Picks 50 rows where `status="2"` per tick
- Calls `GET /cases/{caseId}/documents` → updates `DocumentCount` immediately
- Downloads each document stream → saves to `DocumentStorePath/{OrderId}/{CaseId}/`
- Inserts `CisiveDocuments` row per document (success or failed)
- All docs succeed → `status="3"`, Payload enriched with doc paths
- Any failure → `RetryCount++`, stays at `status="2"` (retried next tick)
- `RetryCount >= MaxDocRetries` → `status="4"` (dead letter)

---

## Setup

### 1. Run the SQL migration
```sql
-- Run Migration.sql against your database
```

### 2. Configure appsettings.json
Fill in:
- `Cisive:TenantId`
- `Cisive:ClientId`
- `Cisive:ClientSecret`
- `Cisive:Scope`
- `Cisive:DocumentStorePath`  (local folder or UNC path)
- `ConnectionStrings:DefaultConnection`

### 3. Register in Program.cs
Already done — `OrderSyncBackgroundService` and `DocumentSyncBackgroundService`
are registered as `AddHostedService`.

### 4. EF Migration (if using Code First)
```bash
dotnet ef migrations add AddCisiveColumnsToHRDSBGCases
dotnet ef database update
```
Or just run `Migration.sql` directly if you manage schema manually.

---

## File layout

```
Infrastructure/
  Cisive/
    CisiveOptions.cs                   — typed config
    CisiveTokenService.cs              — singleton token cache
    CisiveApiClient.cs                 — typed HttpClient (Polly attached)
    Dtos.cs                            — all API response records
    Jobs/
      OrderSyncJob.cs                  — Job 1 logic (scoped)
      DocumentSyncJob.cs               — Job 2 logic (scoped)
    BackgroundServices/
      OrderSyncBackgroundService.cs    — Job 1 timer host
      DocumentSyncBackgroundService.cs — Job 2 timer host
  Persistence/
    AppDbContext.cs
    Entities/
      Entities.cs                      — HRDSBGCase + CisiveDocumentRecord
Program.cs
appsettings.json
Migration.sql
```

---

## Document storage path

```
{DocumentStorePath}/
  {CisiveOrderId}/
    {CaseId}/
      REND_01261230_002.PDF
      10596357_MasterPDF_20260202072527.PDF
```
