using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace CisiveIntegration.Infrastructure.Persistence.Entities;

// ── Existing table — add new columns via EF migration ────────────────────
// Run: dotnet ef migrations add AddCisiveColumnsToHRDSBGCases
[Table("HRDSBGCases")]
public class HRDSBGCase
{
    // ── Existing columns (map to your actual column names) ────────────────
    [Key]
    public int BgcId { get; set; }

    [MaxLength(50)]
    public string? CandidateId { get; set; }

    public DateTime? BackgroundCheckCompletedDt { get; set; }

    [MaxLength(100)]
    public string? BackgroundVerificationNo { get; set; }  // = Cisive caseNumber

    [MaxLength(100)]
    public string? CandidateEmployeeId { get; set; }

    [MaxLength(50)]
    public string? NationalId { get; set; }

    [MaxLength(50)]
    public string? NationalIdType { get; set; }

    [MaxLength(50)]
    public string? WorkerType { get; set; }

    public DateTime? CreatedDate { get; set; }

    // ProcessingStatus values:
    // "0" = not started
    // "1" = in progress (Job 1 picked up)
    // "2" = mapped (CisiveOrderId written, ready for doc sync)
    // "3" = docs downloaded successfully
    // "4" = failed (max retries exhausted)
    [MaxLength(10)]
    public string ProcessingStatus { get; set; } = "0";

    public int RetryCount { get; set; } = 0;

    [MaxLength(2000)]
    public string? ErrorMessage { get; set; }

    public int? DocumentCount { get; set; }

    // Payload stores JSON summary written by Job 1 and enriched by Job 2
    public string? Payload { get; set; }

    // ── NEW columns added by Cisive integration ───────────────────────────
    [MaxLength(50)]
    public string? CisiveOrderId { get; set; }      // orderId from Cisive

    [MaxLength(50)]
    public string? CisiveCaseId { get; set; }       // caseId (available once API exposes it)

    [MaxLength(50)]
    public string? ClientId { get; set; }            // clientCode from Cisive order

    public DateTime? ProcessingStartedAt   { get; set; }
    public DateTime? ProcessingCompletedAt { get; set; }

    // Navigation
    public ICollection<CisiveDocumentRecord> Documents { get; set; } = [];
}

// ── New table ─────────────────────────────────────────────────────────────
// Lightweight — just what you asked for:
// PK, FK, path, success/failed status, message on failure
[Table("CisiveDocuments")]
public class CisiveDocumentRecord
{
    [Key]
    public long Id { get; set; }

    // FK → HRDSBGCases.BgcId
    public int HRDSBGCaseId { get; set; }

    [ForeignKey(nameof(HRDSBGCaseId))]
    public HRDSBGCase? Case { get; set; }

    [MaxLength(50)]
    public string CisiveCaseId { get; set; } = default!;

    public int CisiveDocumentId { get; set; }

    [MaxLength(255)]
    public string FileName { get; set; } = default!;

    [MaxLength(50)]
    public string DocumentType { get; set; } = default!;

    // "success" | "failed"
    [MaxLength(20)]
    public string Status { get; set; } = "success";

    // Populated only when Status = "failed"
    [MaxLength(1000)]
    public string? StatusMessage { get; set; }

    [MaxLength(500)]
    public string? StoragePath { get; set; }   // null when Status = "failed"

    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
