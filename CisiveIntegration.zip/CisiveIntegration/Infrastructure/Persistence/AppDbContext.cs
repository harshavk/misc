using CisiveIntegration.Infrastructure.Persistence.Entities;
using Microsoft.EntityFrameworkCore;

namespace CisiveIntegration.Infrastructure.Persistence;

public class AppDbContext : DbContext
{
    public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

    // Existing table
    public DbSet<HRDSBGCase> HRDSBGCases { get; set; }

    // New table
    public DbSet<CisiveDocumentRecord> CisiveDocuments { get; set; }

    protected override void OnModelCreating(ModelBuilder modelBuilder)
    {
        base.OnModelCreating(modelBuilder);

        modelBuilder.Entity<HRDSBGCase>(e =>
        {
            e.ToTable("HRDSBGCases");
            e.HasKey(x => x.BgcId);

            e.HasMany(x => x.Documents)
             .WithOne(d => d.Case)
             .HasForeignKey(d => d.HRDSBGCaseId)
             .OnDelete(DeleteBehavior.Cascade);
        });

        modelBuilder.Entity<CisiveDocumentRecord>(e =>
        {
            e.ToTable("CisiveDocuments");
            e.HasKey(x => x.Id);

            e.Property(x => x.Status)
             .HasDefaultValue("success");

            e.Property(x => x.CreatedAt)
             .HasDefaultValueSql("GETUTCDATE()");
        });
    }
}
