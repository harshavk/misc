using CisiveIntegration.Infrastructure.Cisive.Jobs;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace CisiveIntegration.Infrastructure.Cisive.BackgroundServices;

/// <summary>
/// Runs OrderSyncJob on a PeriodicTimer.
/// Creates a fresh DI scope per tick so DbContext and scoped services are clean.
/// Errors are caught and logged — the service never crashes; next tick retries.
/// </summary>
public class OrderSyncBackgroundService : BackgroundService
{
    private readonly IServiceScopeFactory                    _scopeFactory;
    private readonly CisiveOptions                           _opts;
    private readonly ILogger<OrderSyncBackgroundService>     _logger;

    public OrderSyncBackgroundService(
        IServiceScopeFactory                _scopeFactory,
        IOptions<CisiveOptions>             opts,
        ILogger<OrderSyncBackgroundService> logger)
    {
        this._scopeFactory = _scopeFactory;
        _opts              = opts.Value;
        _logger            = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken ct)
    {
        _logger.LogInformation(
            "OrderSyncBackgroundService: started — interval {Interval} min",
            _opts.OrderSyncIntervalMinutes);

        using var timer = new PeriodicTimer(
            TimeSpan.FromMinutes(_opts.OrderSyncIntervalMinutes));

        // Run immediately on startup, then wait for each tick
        do
        {
            try
            {
                _logger.LogInformation(
                    "OrderSyncBackgroundService: tick at {Time:u}", DateTime.UtcNow);

                await using var scope = _scopeFactory.CreateAsyncScope();
                var job = scope.ServiceProvider.GetRequiredService<OrderSyncJob>();
                await job.RunAsync(ct);
            }
            catch (OperationCanceledException)
            {
                break; // clean shutdown
            }
            catch (Exception ex)
            {
                // Never let an unhandled exception kill the hosted service
                _logger.LogError(ex,
                    "OrderSyncBackgroundService: unhandled error — will retry on next tick");
            }
        }
        while (await timer.WaitForNextTickAsync(ct));

        _logger.LogInformation("OrderSyncBackgroundService: stopped");
    }
}
