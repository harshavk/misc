using CisiveIntegration.Infrastructure.Cisive.Jobs;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace CisiveIntegration.Infrastructure.Cisive.BackgroundServices;

/// <summary>
/// Runs DocumentSyncJob on a PeriodicTimer.
/// Self-exhausting: once all rows reach status "3" or "4" it logs idle and sleeps.
/// Automatically picks up new rows when Job 1 sets status="2".
/// </summary>
public class DocumentSyncBackgroundService : BackgroundService
{
    private readonly IServiceScopeFactory                     _scopeFactory;
    private readonly CisiveOptions                            _opts;
    private readonly ILogger<DocumentSyncBackgroundService>   _logger;

    public DocumentSyncBackgroundService(
        IServiceScopeFactory                 scopeFactory,
        IOptions<CisiveOptions>              opts,
        ILogger<DocumentSyncBackgroundService> logger)
    {
        _scopeFactory = scopeFactory;
        _opts         = opts.Value;
        _logger       = logger;
    }

    protected override async Task ExecuteAsync(CancellationToken ct)
    {
        _logger.LogInformation(
            "DocumentSyncBackgroundService: started — interval {Interval} min",
            _opts.DocSyncIntervalMinutes);

        using var timer = new PeriodicTimer(
            TimeSpan.FromMinutes(_opts.DocSyncIntervalMinutes));

        do
        {
            try
            {
                _logger.LogInformation(
                    "DocumentSyncBackgroundService: tick at {Time:u}", DateTime.UtcNow);

                await using var scope = _scopeFactory.CreateAsyncScope();
                var job = scope.ServiceProvider.GetRequiredService<DocumentSyncJob>();
                await job.RunAsync(ct);
            }
            catch (OperationCanceledException)
            {
                break;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex,
                    "DocumentSyncBackgroundService: unhandled error — will retry on next tick");
            }
        }
        while (await timer.WaitForNextTickAsync(ct));

        _logger.LogInformation("DocumentSyncBackgroundService: stopped");
    }
}
