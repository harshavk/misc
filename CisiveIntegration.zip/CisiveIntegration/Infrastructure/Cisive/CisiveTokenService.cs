using CisiveIntegration.Infrastructure.Cisive.Dtos;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace CisiveIntegration.Infrastructure.Cisive;

/// <summary>
/// Singleton. Manages bearer token lifecycle — auto-refreshes 60 s before expiry.
/// Thread-safe via SemaphoreSlim double-check pattern.
/// </summary>
public class CisiveTokenService
{
    private readonly IHttpClientFactory              _factory;
    private readonly CisiveOptions                   _opts;
    private readonly ILogger<CisiveTokenService>     _logger;

    private string          _cachedToken = string.Empty;
    private DateTimeOffset  _expiresAt   = DateTimeOffset.MinValue;
    private readonly SemaphoreSlim _lock = new(1, 1);

    public CisiveTokenService(
        IHttpClientFactory          factory,
        IOptions<CisiveOptions>     opts,
        ILogger<CisiveTokenService> logger)
    {
        _factory = factory;
        _opts    = opts.Value;
        _logger  = logger;
    }

    public async Task<string> GetTokenAsync(CancellationToken ct = default)
    {
        // Fast path — still valid
        if (!string.IsNullOrEmpty(_cachedToken) && DateTimeOffset.UtcNow < _expiresAt)
            return _cachedToken;

        await _lock.WaitAsync(ct);
        try
        {
            // Double-check after lock acquisition
            if (!string.IsNullOrEmpty(_cachedToken) && DateTimeOffset.UtcNow < _expiresAt)
                return _cachedToken;

            _logger.LogInformation("CisiveTokenService: requesting new bearer token");

            var http = _factory.CreateClient("CisiveToken");

            var form = new Dictionary<string, string>
            {
                ["grant_type"]    = "client_credentials",
                ["client_id"]     = _opts.ClientId,
                ["client_secret"] = _opts.ClientSecret,
                ["scope"]         = _opts.Scope
            };

            var response = await http.PostAsync(
                $"https://login.microsoftonline.com/{_opts.TenantId}/oauth2/v2.0/token",
                new FormUrlEncodedContent(form),
                ct);

            response.EnsureSuccessStatusCode();

            var token = await response.Content
                .ReadFromJsonAsync<TokenResponse>(cancellationToken: ct)
                ?? throw new InvalidOperationException("Cisive token response was null");

            _cachedToken = token.AccessToken;
            _expiresAt   = DateTimeOffset.UtcNow.AddSeconds(token.ExpiresIn - 60);

            _logger.LogInformation(
                "CisiveTokenService: token acquired, valid until {ExpiresAt:u}", _expiresAt);

            return _cachedToken;
        }
        finally
        {
            _lock.Release();
        }
    }
}
