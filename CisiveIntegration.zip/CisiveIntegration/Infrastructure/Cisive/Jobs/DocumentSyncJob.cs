using System.Text.Json;
using CisiveIntegration.Infrastructure.Persistence;
using CisiveIntegration.Infrastructure.Persistence.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace CisiveIntegration.Infrastructure.Cisive.Jobs;

/// <summary>
/// Job 2 — Document sync.
///
/// Flow (runs every 10 min until all rows reach terminal status):
///   1. Pick batch of 50 rows where status="2" (mapped, ready for doc download)
///   2. For each case: GET /cases/{caseId}/documents → list
///   3. Update HRDSBGCases.DocumentCount immediately after list call
///   4. For each document: download stream → save to disk
///   5. Insert CisiveDocumentRecord (PK, FK, path, status, message)
///   6. All docs succeed  → HRDSBGCases status="3", Payload enriched
///      Any doc fails     → RetryCount++, stays at status="2" (retried next tick)
///      RetryCount >= max → status="4" (dead letter)
/// </summary>
public class DocumentSyncJob
{
    private readonly AppDbContext              _db;
    private readonly CisiveApiClient           _api;
    private readonly CisiveOptions             _opts;
    private readonly ILogger<DocumentSyncJob>  _logger;

    public DocumentSyncJob(
        AppDbContext             db,
        CisiveApiClient          api,
        IOptions<CisiveOptions>  opts,
        ILogger<DocumentSyncJob> logger)
    {
        _db     = db;
        _api    = api;
        _opts   = opts.Value;
        _logger = logger;
    }

    public async Task RunAsync(CancellationToken ct)
    {
        // ── Step 1: Pick next batch of mapped rows ────────────────────────
        var batch = await _db.HRDSBGCases
            .Where(x => x.ProcessingStatus == "2"
                     && x.CisiveOrderId != null
                     && x.RetryCount < _opts.MaxDocRetries)
            .OrderBy(x => x.BackgroundCheckCompletedDt)
            .Take(50)
            .ToListAsync(ct);

        if (batch.Count == 0)
        {
            _logger.LogInformation(
                "DocumentSyncJob: no rows ready for doc sync — sleeping until next tick");
            return;
        }

        _logger.LogInformation(
            "DocumentSyncJob: processing batch of {Count} cases", batch.Count);

        foreach (var bgCase in batch)
        {
            if (ct.IsCancellationRequested) break;
            await ProcessCaseAsync(bgCase, ct);
        }

        // Save all row-level changes (status, retryCount, payload, docCount)
        await _db.SaveChangesAsync(ct);

        _logger.LogInformation("DocumentSyncJob: batch saved");
    }

    private async Task ProcessCaseAsync(HRDSBGCase bgCase, CancellationToken ct)
    {
        // Resolve caseId — use CisiveCaseId if API has populated it,
        // fall back to BackgroundVerificationNo until then
        var caseId = !string.IsNullOrWhiteSpace(bgCase.CisiveCaseId)
            ? bgCase.CisiveCaseId
            : bgCase.BackgroundVerificationNo;

        if (string.IsNullOrWhiteSpace(caseId))
        {
            _logger.LogWarning(
                "DocumentSyncJob: row {BgcId} — no caseId available, skipping", bgCase.BgcId);
            return;
        }

        try
        {
            // ── Step 2: Get document list ─────────────────────────────────
            var docs = await _api.GetDocumentsAsync(caseId, ct);

            // ── Step 3: Update DocumentCount immediately after list call ──
            bgCase.DocumentCount = docs.Count;

            _logger.LogInformation(
                "DocumentSyncJob: case {CaseId} — {Count} documents found", caseId, docs.Count);

            if (docs.Count == 0)
            {
                bgCase.ProcessingStatus      = "3";
                bgCase.ProcessingCompletedAt = DateTime.UtcNow;
                EnrichPayload(bgCase, caseId, 0, []);
                return;
            }

            var successPaths  = new List<string>();
            bool anyFailure   = false;

            // ── Step 4 + 5: Download each doc, insert CisiveDocumentRecord ──
            foreach (var doc in docs)
            {
                if (ct.IsCancellationRequested) break;

                var record = new CisiveDocumentRecord
                {
                    HRDSBGCaseId     = bgCase.BgcId,
                    CisiveCaseId     = caseId,
                    CisiveDocumentId = doc.Id,
                    FileName         = doc.FileName,
                    DocumentType     = doc.DocumentType,
                    CreatedAt        = DateTime.UtcNow
                };

                try
                {
                    var path = await DownloadAndSaveAsync(bgCase, caseId, doc, ct);

                    record.StoragePath   = path;
                    record.Status        = "success";
                    record.StatusMessage = null;

                    successPaths.Add(path);

                    _logger.LogInformation(
                        "DocumentSyncJob: downloaded {FileName} → {Path}",
                        doc.FileName, path);
                }
                catch (Exception ex)
                {
                    anyFailure           = true;
                    record.Status        = "failed";
                    record.StatusMessage = ex.Message;
                    record.StoragePath   = null;

                    _logger.LogError(ex,
                        "DocumentSyncJob: FAILED download docId={DocId} fileName={FileName} " +
                        "case={CaseId}", doc.Id, doc.FileName, caseId);
                }

                // Insert doc record regardless of success/failure
                _db.CisiveDocuments.Add(record);
            }

            // ── Step 6: Update case row based on overall outcome ──────────
            if (!anyFailure)
            {
                bgCase.ProcessingStatus      = "3"; // success
                bgCase.ProcessingCompletedAt = DateTime.UtcNow;
                bgCase.ErrorMessage          = null;
                EnrichPayload(bgCase, caseId, docs.Count, successPaths);

                _logger.LogInformation(
                    "DocumentSyncJob: case {CaseId} COMPLETE — {Count} docs",
                    caseId, docs.Count);
            }
            else
            {
                bgCase.RetryCount++;
                bgCase.ErrorMessage =
                    $"Partial failure: {successPaths.Count}/{docs.Count} docs downloaded.";

                if (bgCase.RetryCount >= _opts.MaxDocRetries)
                {
                    bgCase.ProcessingStatus = "4"; // dead letter
                    _logger.LogError(
                        "DocumentSyncJob: case {CaseId} hit max retries ({Max}) — marked FAILED",
                        caseId, _opts.MaxDocRetries);
                }
                else
                {
                    // Stays at "2" — retried on next tick
                    _logger.LogWarning(
                        "DocumentSyncJob: case {CaseId} partial failure — retry {Attempt}/{Max}",
                        caseId, bgCase.RetryCount, _opts.MaxDocRetries);
                }
            }
        }
        catch (Exception ex)
        {
            bgCase.RetryCount++;
            bgCase.ErrorMessage = ex.Message;

            if (bgCase.RetryCount >= _opts.MaxDocRetries)
            {
                bgCase.ProcessingStatus = "4";
                _logger.LogError(ex,
                    "DocumentSyncJob: case {CaseId} FATAL after {Max} retries",
                    caseId, _opts.MaxDocRetries);
            }
            else
            {
                _logger.LogError(ex,
                    "DocumentSyncJob: case {CaseId} error — retry {Attempt}/{Max}",
                    caseId, bgCase.RetryCount, _opts.MaxDocRetries);
            }
        }
    }

    // ── Download stream → save to disk ────────────────────────────────────
    private async Task<string> DownloadAndSaveAsync(
        HRDSBGCase bgCase, string caseId,
        Dtos.CisiveDocument doc, CancellationToken ct)
    {
        // Folder: {DocumentStorePath}/{CisiveOrderId}/{caseId}/
        var folder = Path.Combine(
            _opts.DocumentStorePath,
            bgCase.CisiveOrderId ?? "unknown",
            caseId);

        Directory.CreateDirectory(folder);

        // Sanitize filename — strip any invalid path chars
        var safeFileName = string.Concat(
            doc.FileName.Split(Path.GetInvalidFileNameChars()));

        var filePath = Path.Combine(folder, safeFileName);

        await using var remoteStream = await _api.DownloadDocumentAsync(caseId, doc.Id, ct);
        await using var fileStream   = new FileStream(
            filePath,
            FileMode.Create,
            FileAccess.Write,
            FileShare.None,
            bufferSize: 81920,   // 80 KB — efficient for PDF streaming
            useAsync: true);

        await remoteStream.CopyToAsync(fileStream, ct);
        return filePath;
    }

    // ── Enrich the Payload column with doc sync summary ───────────────────
    private static void EnrichPayload(
        HRDSBGCase bgCase, string caseId, int docCount, List<string> paths)
    {
        // Parse existing payload written by Job 1, then add doc info
        var existing = new Dictionary<string, object>();
        if (!string.IsNullOrWhiteSpace(bgCase.Payload))
        {
            try
            {
                existing = JsonSerializer.Deserialize<Dictionary<string, object>>(
                    bgCase.Payload) ?? [];
            }
            catch { /* ignore — overwrite if malformed */ }
        }

        existing["DocumentCount"]  = docCount;
        existing["DocumentPaths"]  = paths;
        existing["DocsSyncedAt"]   = DateTime.UtcNow;

        bgCase.Payload = JsonSerializer.Serialize(existing);
    }
}
