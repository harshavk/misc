using System.Text.Json;
using CisiveIntegration.Infrastructure.Cisive.Dtos;
using CisiveIntegration.Infrastructure.Persistence;
using CisiveIntegration.Infrastructure.Persistence.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace CisiveIntegration.Infrastructure.Cisive.Jobs;

/// <summary>
/// Job 1 — Order sync.
///
/// Flow:
///   1. Find MIN/MAX BackgroundCheckCompletedDt from status="0" rows (data-driven window)
///   2. Single call to Cisive orders API (skip=0 returns full set)
///   3. Build lookup: caseNumber → order
///   4. Match each unprocessed HRDSBGCase row by BackgroundVerificationNo = caseNumber
///   5. On match:  write CisiveOrderId, CisiveCaseId, ClientId, Payload → status="2"
///   6. No match:  reset to status="0" (retried on next tick)
/// </summary>
public class OrderSyncJob
{
    private readonly AppDbContext             _db;
    private readonly CisiveApiClient          _api;
    private readonly CisiveOptions            _opts;
    private readonly ILogger<OrderSyncJob>    _logger;

    public OrderSyncJob(
        AppDbContext          db,
        CisiveApiClient       api,
        IOptions<CisiveOptions> opts,
        ILogger<OrderSyncJob> logger)
    {
        _db     = db;
        _api    = api;
        _opts   = opts.Value;
        _logger = logger;
    }

    public async Task RunAsync(CancellationToken ct)
    {
        // ── Step 1: Derive date window from unprocessed rows ──────────────
        var dateRange = await _db.HRDSBGCases
            .Where(x => x.ProcessingStatus == "0"
                     && x.BackgroundCheckCompletedDt != null)
            .GroupBy(_ => 1)
            .Select(g => new
            {
                From = g.Min(x => x.BackgroundCheckCompletedDt!.Value),
                To   = g.Max(x => x.BackgroundCheckCompletedDt!.Value)
            })
            .FirstOrDefaultAsync(ct);

        if (dateRange is null)
        {
            _logger.LogInformation(
                "OrderSyncJob: no unprocessed rows found — nothing to do");
            return;
        }

        var from = DateOnly.FromDateTime(dateRange.From);
        var to   = DateOnly.FromDateTime(dateRange.To);

        _logger.LogInformation(
            "OrderSyncJob: date window {From} → {To}", from, to);

        // ── Step 2: Single API call — skip=0 returns full result set ──────
        var allOrders = await _api.GetOrdersAsync(from, to, ct);

        _logger.LogInformation(
            "OrderSyncJob: Cisive returned {Count} orders", allOrders.Count);

        if (allOrders.Count == 0)
        {
            _logger.LogWarning(
                "OrderSyncJob: 0 orders from Cisive for window {From}→{To}", from, to);
            return;
        }

        // ── Step 3: Flatten to caseNumber lookup ──────────────────────────
        // One order can have multiple cases — each caseNumber maps to its parent order
        var lookup = allOrders
            .SelectMany(o => o.Cases.Select(c => (CaseNumber: c.CaseNumber, Order: o, Case: c)))
            .GroupBy(x => x.CaseNumber)
            .ToDictionary(g => g.Key, g => g.First());

        _logger.LogInformation(
            "OrderSyncJob: built lookup with {Count} distinct caseNumbers", lookup.Count);

        // ── Step 4: Load all unprocessed rows ─────────────────────────────
        var unprocessed = await _db.HRDSBGCases
            .Where(x => x.ProcessingStatus == "0"
                     && x.BackgroundCheckCompletedDt != null)
            .ToListAsync(ct);

        _logger.LogInformation(
            "OrderSyncJob: {Count} unprocessed HRDSBGCases rows to match",
            unprocessed.Count);

        int matched = 0, unmatched = 0;

        foreach (var bgCase in unprocessed)
        {
            if (ct.IsCancellationRequested) break;

            var caseNumber = bgCase.BackgroundVerificationNo;

            if (string.IsNullOrWhiteSpace(caseNumber))
            {
                _logger.LogWarning(
                    "OrderSyncJob: row {Id} — BackgroundVerificationNo is null/empty, skipping",
                    bgCase.BgcId);
                continue;
            }

            // Mark in-progress immediately so parallel runs don't double-pick
            bgCase.ProcessingStatus    = "1";
            bgCase.ProcessingStartedAt = DateTime.UtcNow;

            if (lookup.TryGetValue(caseNumber, out var hit))
            {
                // ── Match found ───────────────────────────────────────────
                var order = hit.Order;
                var @case = hit.Case;

                bgCase.CisiveOrderId = order.OrderId.ToString();

                // Use numeric caseId from API if available, else fall back to caseNumber string
                bgCase.CisiveCaseId  = @case.CaseId?.ToString() ?? caseNumber;

                bgCase.ClientId      = order.ClientCode;

                // Payload: full mapping summary written to the row
                bgCase.Payload = JsonSerializer.Serialize(new
                {
                    CisiveOrderId  = order.OrderId,
                    CisiveCaseId   = @case.CaseId?.ToString() ?? caseNumber,
                    CaseNumber     = caseNumber,
                    ClientCode     = order.ClientCode,
                    ClientGroup    = order.ClientGroup,
                    Status         = order.Status,
                    CompletedDate  = order.CompletedDate,
                    UdfFields      = order.UdfFields,
                    ReferenceFields = order.ReferenceFields,
                    MappedAt       = DateTime.UtcNow
                });

                bgCase.ProcessingStatus = "2"; // ready for doc sync
                matched++;

                _logger.LogInformation(
                    "OrderSyncJob: MATCH row {BgcId} ← orderId={OrderId} caseNumber={CaseNumber}",
                    bgCase.BgcId, order.OrderId, caseNumber);
            }
            else
            {
                // ── No match — reset so it retries next tick ──────────────
                bgCase.ProcessingStatus    = "0";
                bgCase.ProcessingStartedAt = null;
                unmatched++;

                _logger.LogWarning(
                    "OrderSyncJob: NO MATCH for caseNumber={CaseNumber} (row {BgcId}) — will retry",
                    caseNumber, bgCase.BgcId);
            }
        }

        await _db.SaveChangesAsync(ct);

        _logger.LogInformation(
            "OrderSyncJob: DONE — Matched={Matched}, Unmatched={Unmatched}",
            matched, unmatched);
    }
}
