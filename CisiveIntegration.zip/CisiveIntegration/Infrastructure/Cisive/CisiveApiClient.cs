using CisiveIntegration.Infrastructure.Cisive.Dtos;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace CisiveIntegration.Infrastructure.Cisive;

/// <summary>
/// Typed HttpClient wrapping all Cisive API calls.
/// Polly resilience (retry + circuit breaker) is attached at registration in Program.cs.
/// </summary>
public class CisiveApiClient
{
    private readonly HttpClient               _http;
    private readonly CisiveTokenService       _tokenService;
    private readonly CisiveOptions            _opts;
    private readonly ILogger<CisiveApiClient> _logger;

    public CisiveApiClient(
        HttpClient                  http,
        CisiveTokenService          tokenService,
        IOptions<CisiveOptions>     opts,
        ILogger<CisiveApiClient>    logger)
    {
        _http         = http;
        _tokenService = tokenService;
        _opts         = opts.Value;
        _logger       = logger;
    }

    // ── Orders summary (single call, skip=0 returns full set) ────────────
    public async Task<List<CisiveOrder>> GetOrdersAsync(
        DateOnly from, DateOnly to, CancellationToken ct)
    {
        var filter =
            $"status eq 'Completed' " +
            $"and completedDate ge {from:yyyy-MM-dd} " +
            $"and completedDate le {to:yyyy-MM-dd}";

        var url =
            $"{_opts.BaseUrl}/order-management/clients/{_opts.ClientCode}" +
            $"/orders/summary" +
            $"?$skip=0" +
            $"&$filter={Uri.EscapeDataString(filter)}" +
            $"&$orderby=orderId";

        _logger.LogDebug("CisiveApiClient: GET orders — {Url}", url);

        var req  = await BuildRequestAsync(HttpMethod.Get, url, ct);
        var resp = await _http.SendAsync(req, ct);
        resp.EnsureSuccessStatusCode();

        return await resp.Content
            .ReadFromJsonAsync<List<CisiveOrder>>(cancellationToken: ct) ?? [];
    }

    // ── Document list for a case ──────────────────────────────────────────
    public async Task<List<CisiveDocument>> GetDocumentsAsync(
        string caseId, CancellationToken ct)
    {
        var url =
            $"{_opts.BaseUrl}/order-management/clients/{_opts.ClientCode}" +
            $"/cases/{caseId}/documents";

        var req  = await BuildRequestAsync(HttpMethod.Get, url, ct);
        var resp = await _http.SendAsync(req, ct);
        resp.EnsureSuccessStatusCode();

        return await resp.Content
            .ReadFromJsonAsync<List<CisiveDocument>>(cancellationToken: ct) ?? [];
    }

    // ── Download single document as raw stream ────────────────────────────
    public async Task<Stream> DownloadDocumentAsync(
        string caseId, int documentId, CancellationToken ct)
    {
        var url =
            $"{_opts.BaseUrl}/order-management/clients/{_opts.ClientCode}" +
            $"/cases/{caseId}/document/{documentId}";

        var req = await BuildRequestAsync(HttpMethod.Get, url, ct);

        // ResponseHeadersRead = don't buffer entire file in memory
        var resp = await _http.SendAsync(
            req, HttpCompletionOption.ResponseHeadersRead, ct);

        resp.EnsureSuccessStatusCode();
        return await resp.Content.ReadAsStreamAsync(ct);
    }

    // ── Shared: inject bearer token + api-version on every request ────────
    private async Task<HttpRequestMessage> BuildRequestAsync(
        HttpMethod method, string url, CancellationToken ct)
    {
        var token = await _tokenService.GetTokenAsync(ct);
        var req   = new HttpRequestMessage(method, url);
        req.Headers.Authorization = new System.Net.Http.Headers.AuthenticationHeaderValue(
            "Bearer", token);
        req.Headers.Add("api-version", "1");
        return req;
    }
}
