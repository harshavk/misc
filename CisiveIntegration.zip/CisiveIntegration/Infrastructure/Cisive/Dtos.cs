using System.Text.Json.Serialization;

namespace CisiveIntegration.Infrastructure.Cisive.Dtos;

// ── Token ─────────────────────────────────────────────────────────────────
public record TokenResponse(
    [property: JsonPropertyName("access_token")] string AccessToken,
    [property: JsonPropertyName("expires_in")]   int    ExpiresIn,
    [property: JsonPropertyName("token_type")]   string TokenType
);

// ── Orders ────────────────────────────────────────────────────────────────
public record CisiveOrder(
    [property: JsonPropertyName("orderId")]         int            OrderId,
    [property: JsonPropertyName("clientCode")]      string         ClientCode,
    [property: JsonPropertyName("clientGroup")]     string         ClientGroup,
    [property: JsonPropertyName("status")]          string         Status,
    [property: JsonPropertyName("completedDate")]   DateTime?      CompletedDate,
    [property: JsonPropertyName("cases")]           List<CisiveCase> Cases,
    [property: JsonPropertyName("udfFields")]       UdfFields      UdfFields,
    [property: JsonPropertyName("referenceFields")] ReferenceFields ReferenceFields
);

public record CisiveCase(
    [property: JsonPropertyName("caseId")]     int?   CaseId,       // coming soon in API
    [property: JsonPropertyName("caseNumber")] string CaseNumber
);

public record UdfFields(
    [property: JsonPropertyName("udf1")] string Udf1,
    [property: JsonPropertyName("udf2")] string Udf2,
    [property: JsonPropertyName("udf3")] string Udf3
);

public record ReferenceFields(
    [property: JsonPropertyName("JobCode")]             string JobCode,
    [property: JsonPropertyName("CostCenter")]          string CostCenter,
    [property: JsonPropertyName("ExternalRequestId")]   string ExternalRequestId,
    [property: JsonPropertyName("ExternalCandidateId")] string ExternalCandidateId,
    [property: JsonPropertyName("RequisitionNumber")]   string RequisitionNumber
);

// ── Documents ─────────────────────────────────────────────────────────────
public record CisiveDocument(
    [property: JsonPropertyName("id")]           int    Id,
    [property: JsonPropertyName("fileName")]     string FileName,
    [property: JsonPropertyName("documentType")] string DocumentType,
    [property: JsonPropertyName("description")]  string Description,
    [property: JsonPropertyName("fileType")]     string FileType
);
