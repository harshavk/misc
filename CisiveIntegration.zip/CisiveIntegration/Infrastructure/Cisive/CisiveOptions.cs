using System.ComponentModel.DataAnnotations;

namespace CisiveIntegration.Infrastructure.Cisive;

public class CisiveOptions
{
    public const string Section = "Cisive";

    [Required] public string TenantId         { get; set; } = default!;
    [Required] public string ClientId         { get; set; } = default!;
    [Required] public string ClientSecret     { get; set; } = default!;
    [Required] public string Scope            { get; set; } = default!;
    [Required] public string BaseUrl          { get; set; } = default!;
    [Required] public string ClientCode       { get; set; } = default!;
    [Required] public string DocumentStorePath{ get; set; } = default!;

    public int PageSize                 { get; set; } = 100;
    public int BootstrapMonths          { get; set; } = 6;
    public int OrderSyncIntervalMinutes { get; set; } = 5;
    public int DocSyncIntervalMinutes   { get; set; } = 10;
    public int MaxDocRetries            { get; set; } = 3;
}
