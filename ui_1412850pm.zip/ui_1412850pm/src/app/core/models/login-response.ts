export interface LoginResponse {
    token: string;
    expiration: string;
    userId: string;
    name: string;
    email: string;
    role: string;
    ImageUrl: string;
}