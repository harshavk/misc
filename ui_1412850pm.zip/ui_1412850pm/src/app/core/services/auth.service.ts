import { Injectable, signal, computed } from '@angular/core';
import { User } from '../models/user.model';
import { Role } from '../models/role.enum';
import { LoginResponse } from '../models/login-response';

const STORAGE_KEY = 'rbdui_current_user';
const TOKEN_KEY = 'rbdui_auth_token';

/**
 * Service responsible for managing user authentication state, session persistence,
 * and role-based access control (RBAC).
 */
@Injectable({ providedIn: 'root' })
export class AuthService {
  // ---------------------------------------------------------------------------
  // STATE MANAGEMENT
  // ---------------------------------------------------------------------------

  // Internal signal holding the current user state
  private _currentUser = signal<User | null>(this.loadFromStorage());

  /** Read-only signal for the current logged-in user. */
  readonly currentUser = computed(() => this._currentUser());

  /** Read-only signal indicating if a user is currently authenticated. */
  readonly isAuthenticatedSignal = computed(() => !!this._currentUser());

  constructor() {
    // Optional: Add logic here to validate token expiration on app startup
  }

  // ---------------------------------------------------------------------------
  // SESSION MANAGEMENT
  // ---------------------------------------------------------------------------

  /**
   * Initializes a user session from a successful login response.
   * Maps API roles to application roles and persists data to LocalStorage.
   * * @param response The raw response object from the Login API.
   */
  setSession(response: LoginResponse): void {
    console.log('✅ [Auth] Setting Session for:', response.userId);

    // 1. Map dynamic API role strings to our static App Role Enum
    const appRoles = this.mapApiRoleToAppRole(response.role);

    // 2. Construct the standardized User object
    const user: User = {
      id: response.userId, // Defaulting ID to userName if unique ID is missing
      name: response.name,
      email: response.email,
      roles: appRoles,
      avatarUrl: response.ImageUrl
    };

    // 3. Update application state
    this._currentUser.set(user);

    // 4. Persist to LocalStorage for page reloads
    localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
    localStorage.setItem(TOKEN_KEY, response.token);
  }

  /**
   * Clears the current user session and removes all persistence data.
   */
  logout(): void {
    console.log('👋 [Auth] Logging out');
    this._currentUser.set(null);
    localStorage.removeItem(STORAGE_KEY);
    localStorage.removeItem(TOKEN_KEY);
  }

  /**
   * Retrieves the JWT token for HTTP Interceptors.
   */
  getToken(): string | null {
    return localStorage.getItem(TOKEN_KEY);
  }

  // ---------------------------------------------------------------------------
  // ROLE & PERMISSION CHECKS
  // ---------------------------------------------------------------------------

  /**
   * Checks if the current user possesses a specific role.
   */
  hasRole(role: Role): boolean {
    const user = this._currentUser();
    return !!user?.roles.includes(role);
  }

  /**
   * Checks if the current user possesses *any* of the provided roles.
   * Useful for guards protecting routes accessible by multiple role types.
   */
  hasAnyRole(roles: Role[]): boolean {
    const user = this._currentUser();
    if (!user) return false;
    return roles.some(r => user.roles.includes(r));
  }

  /**
   * Legacy method for non-reactive auth checks. 
   * Prefer using `isAuthenticatedSignal()` in templates.
   */
  isAuthenticated(): boolean {
    return this.isAuthenticatedSignal();
  }

  // ---------------------------------------------------------------------------
  // INTERNAL HELPERS
  // ---------------------------------------------------------------------------

  /**
   * safe way to map loose string roles from the API (e.g., "Tech Director")
   * into strict Application Roles (e.g., Role.Manager).
   */
  private mapApiRoleToAppRole(apiRole: string | undefined): Role[] {
    if (!apiRole) {
      console.warn('⚠️ [Auth] No role found in response. Defaulting to Employee.');
      return [Role.Employee];
    }

    const lowerRole = apiRole.toLowerCase();

    // Mapping Logic: Add more keywords here as business rules evolve
    if (
      lowerRole.includes('tech director') ||
      lowerRole.includes('admin') ||
      lowerRole.includes('manager')
    ) {
      return [Role.Manager];
    }

    // Default fallback
    return [Role.Employee];
  }

  /**
   * Restores user state from LocalStorage on service initialization.
   */
  private loadFromStorage(): User | null {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    try {
      return JSON.parse(raw) as User;
    } catch (e) {
      console.error('❌ [Auth] Failed to parse user from storage', e);
      return null;
    }
  }
}