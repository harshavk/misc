import { Injectable, signal, effect, inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';

// Constants for storage keys and class names to ensure consistency
const THEME_STORAGE_KEY = 'rbdui_theme_preference';
const DARK_THEME_CLASS = 'dark-theme';

/**
 * Service responsible for managing the application's visual theme (Light vs. Dark).
 * Uses Angular Signals to reactively update the DOM body class.
 */
@Injectable({
    providedIn: 'root'
})
export class ThemeService {
    private readonly document = inject(DOCUMENT);

    // ---------------------------------------------------------------------------
    // STATE
    // ---------------------------------------------------------------------------

    /** Signal tracking whether Dark Mode is currently active. */
    readonly isDarkMode = signal<boolean>(false);

    constructor() {
        // 1. Initialize State based on Storage or System Preference
        this.initializeThemeState();

        // 2. Register Effect: Automatically applies classes/storage whenever the signal changes
        effect(() => {
            const isDark = this.isDarkMode();

            if (isDark) {
                this.document.body.classList.add(DARK_THEME_CLASS);
                localStorage.setItem(THEME_STORAGE_KEY, 'dark');
            } else {
                this.document.body.classList.remove(DARK_THEME_CLASS);
                localStorage.setItem(THEME_STORAGE_KEY, 'light');
            }
        });
    }

    // ---------------------------------------------------------------------------
    // PUBLIC API
    // ---------------------------------------------------------------------------

    /**
     * Toggles the current theme between Light and Dark.
     */
    toggle(): void {
        this.isDarkMode.update(current => !current);
    }

    /**
     * Explicitly sets the theme mode.
     * @param isDark True for Dark Mode, False for Light Mode.
     */
    setTheme(isDark: boolean): void {
        this.isDarkMode.set(isDark);
    }

    // ---------------------------------------------------------------------------
    // INTERNAL HELPERS
    // ---------------------------------------------------------------------------

    private initializeThemeState(): void {
        // Check LocalStorage first
        const savedPreference = localStorage.getItem(THEME_STORAGE_KEY);

        if (savedPreference) {
            this.isDarkMode.set(savedPreference === 'dark');
        } else {
            // Fallback to System Preference (Media Query)
            // Note: We check if window is defined to be safe (though usually fine in SPAs)
            if (typeof window !== 'undefined' && window.matchMedia) {
                const systemDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
                this.isDarkMode.set(systemDark);
            }
        }
    }
}