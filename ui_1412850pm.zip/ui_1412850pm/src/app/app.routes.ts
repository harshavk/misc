import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';

export const appRoutes: Routes = [
  {
    path: 'login',
    loadComponent: () =>
      import('./features/auth/login.component').then(m => m.LoginComponent),
  },
  {
    path: '',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./layout/shell.component').then(m => m.ShellComponent),
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'dashboard' },
      {
        path: 'ally',
        loadComponent: () =>
          import('./features/mybuddy/mybuddy').then(
            m => m.Mybuddy
          ),
      },
      {
        path: 'dashboard',
        loadComponent: () =>
          import('./features/dashboard/dashboard.component').then(
            m => m.DashboardComponent
          ),
      },
      {
        path: 'credits',
        loadComponent: () =>
          import('./features/credits/credits.component').then(
            m => m.CreditsComponent
          ),
      },
      {
        path: 'forbidden',
        loadComponent: () =>
          import('./features/error/forbidden.component').then(
            m => m.ForbiddenComponent
          ),
      },
      {
        path: '**',
        loadComponent: () =>
          import('./features/error/not-found.component').then(
            m => m.NotFoundComponent
          ),
      },
    ],
  },
  { path: '**', redirectTo: '' },
];