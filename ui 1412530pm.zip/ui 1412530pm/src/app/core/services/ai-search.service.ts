import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { delay, map, switchMap, shareReplay } from 'rxjs/operators';

import { environment } from '../../../environments/environment';
import {
    AiThreadRequest,
    AiThreadResponse,
    ThreadMessage
} from '../models/ai-thread.models';
import {
    ActionResult,
    AnswerResult,
    AiSearchResponse,
} from '../models/ai-search.models';
import { MockScenario } from '../models/mock-ai.models';

const MOCK_DATA_URL = 'assets/mock-ai-responses.json';

@Injectable({ providedIn: 'root' })
export class AiSearchService {
    // ---------------------------------------------------------------------------
    // DEPENDENCIES & STATE
    // ---------------------------------------------------------------------------
    private readonly http = inject(HttpClient);

    // Cache for mock scenarios to avoid repeated HTTP calls
    private mockScenarios$: Observable<MockScenario[]> | null = null;

    // ---------------------------------------------------------------------------
    // PUBLIC API
    // ---------------------------------------------------------------------------

    /**
     * Performs an AI search or chat interaction.
     * Handles switching between Mock mode and Real API mode based on environment config.
     *
     * @param query The user's input message.
     * @param threadId The current conversation thread ID.
     * @param metadata Additional context (e.g., workflow name).
     * @param actor_id Optional ID of the user performing the action.
     */
    search(
        query: string,
        threadId: string,
        metadata: Record<string, unknown> = { workflow: 'onboarding' },
        actor_id?: string
    ): Observable<AiSearchResponse> {
        const payload: AiThreadRequest = {
            message: query,
            thread_id: threadId,
            metadata,
            actor_id,
        };

        // UX: Add artificial delay for "thinking" effect if needed
        const minDelayMs = environment.mockConfig.enableChat ? 1500 : 0;
        const started = Date.now();

        // 1. Determine Source (Mock vs Real)
        const rawResponse$ = environment.mockConfig.enableChat
            ? this.getMockResponse(query, payload)
            : this.http.post<AiThreadResponse>(`${environment.apiBaseUrl}/chat`, payload);

        // 2. Process & Map Response
        return rawResponse$.pipe(
            map((raw) =>
                this.mapToUi(query, raw, environment.mockConfig.enableChat ? 'mock' : 'python-api')
            ),
            switchMap((uiResponse) => {
                // Enforce minimum delay for better UX
                const elapsed = Date.now() - started;
                const remainingDelay = Math.max(0, minDelayMs - elapsed);
                return remainingDelay > 0 ? of(uiResponse).pipe(delay(remainingDelay)) : of(uiResponse);
            })
        );
    }

    /**
     * Checks if the service is currently running in Mock mode.
     */
    isMockMode(): boolean {
        return environment.mockConfig.enableChat;
    }

    // ---------------------------------------------------------------------------
    // PRIVATE: MOCK LOGIC
    // ---------------------------------------------------------------------------

    private getMockResponse(query: string, payload: AiThreadRequest): Observable<AiThreadResponse> {
        return this.loadMocks().pipe(
            map((scenarios) => {
                const scenario = this.pickScenario(query, scenarios);
                return this.buildThreadFromScenario(payload, scenario);
            })
        );
    }

    private loadMocks(): Observable<MockScenario[]> {
        if (!this.mockScenarios$) {
            this.mockScenarios$ = this.http.get<MockScenario[]>(MOCK_DATA_URL).pipe(
                shareReplay(1) // Cache the result
            );
        }
        return this.mockScenarios$;
    }

    private pickScenario(query: string, scenarios: MockScenario[]): MockScenario {
        const q = query.toLowerCase();

        // 1. Priority: Keyword match
        const match = scenarios.find((s) =>
            (s.keywords || []).some((k) => q.includes(k.toLowerCase()))
        );

        // 2. Fallback: Generic scenario
        if (match) return match;
        const fallback = scenarios.find((s) => s.id === 'generic-fallback');

        // 3. Last Resort: First item
        return fallback || scenarios[0];
    }

    private buildThreadFromScenario(
        req: AiThreadRequest,
        scenario: MockScenario
    ): AiThreadResponse {
        const now = new Date().toISOString();
        const base = scenario.thread;

        // Construct the message history
        const messages: ThreadMessage[] = [
            // Always echo the real user input first
            {
                type: 'human',
                content: req.message,
                tool_call: null,
            },
            // Append non-human messages from the mock scenario
            ...base.messages.filter((m) => m.type !== 'human'),
        ];

        return {
            reply: base.reply,
            thread_id: req.thread_id || base.thread_id || scenario.id,
            timestamp: base.timestamp || now,
            messages: messages,
        };
    }

    // ---------------------------------------------------------------------------
    // PRIVATE: UI MAPPING (ADAPTER)
    // ---------------------------------------------------------------------------

    private mapToUi(
        query: string,
        raw: AiThreadResponse,
        source: 'mock' | 'python-api'
    ): AiSearchResponse {
        const createdAt = raw.timestamp || new Date().toISOString();

        return {
            id: `${raw.thread_id}:${createdAt}`,
            query,
            createdAt,
            answers: this.extractAnswers(raw),
            actions: this.extractActions(raw),
            meta: {
                latencyMs: 0,
                model: 'thread-api-model',
                source,
            },
            threadId: raw.thread_id,
            historyMessages: raw.messages,
        };
    }

    /**
     * Extracts text responses (AnswerResult) from the AI thread.
     */
    private extractAnswers(raw: AiThreadResponse): AnswerResult[] {
        const answers: AnswerResult[] = [];
        const aiMessages = raw.messages.filter((m) => m.type === 'ai');

        // Helper to detect HTML content
        const looksHtml = (text: string | null | undefined): boolean =>
            !!text && /<\s*(a|p|ul|ol|li|button|strong|em|div|span)\b/i.test(text);

        // 1. Add Summary if available (from raw.reply)
        if (raw.reply && raw.reply.trim().length > 0) {
            answers.push({
                id: 'ans-summary',
                title: 'AI reply',
                content: raw.reply,
                type: 'summary',
                isHtml: looksHtml(raw.reply),
                confidence: 0.9,
                tags: [],
                references: [],
            });
        }

        // 2. Add individual message explanations, avoiding duplicates
        aiMessages.forEach((m, idx) => {
            const content = m.content || '';
            // Skip if this message is identical to the main reply we just added
            if (raw.reply && content.trim() === raw.reply.trim()) return;

            answers.push({
                id: `ans-msg-${idx}`,
                title: 'AI reply',
                content,
                type: 'explanation',
                isHtml: looksHtml(content),
                confidence: 0.85,
                tags: [],
                references: [],
            });
        });

        return answers;
    }

    /**
     * Extracts executable actions (ActionResult) from tool calls.
     */
    private extractActions(raw: AiThreadResponse): ActionResult[] {
        return raw.messages
            .filter((m) => !!m.tool_call)
            .map((m, idx) => {
                const tc = m.tool_call || {};

                // Determine Label & Description
                const name = tc.name || tc.action || tc.type || 'Suggested action';
                const description = tc.description || 'Action suggested by the AI.';

                // Categorize based on keywords
                const lowerName = String(name).toLowerCase();
                let category: ActionResult['category'] = 'other';

                if (lowerName.includes('workday')) category = 'hr';
                else if (lowerName.includes('equipment') || lowerName.includes('access')) category = 'access';
                else if (lowerName.includes('email')) category = 'email';
                else if (lowerName.includes('navigate') || lowerName.includes('open')) category = 'navigation';

                return {
                    id: `act-${idx}`,
                    label: name,
                    description,
                    icon: 'bolt', // Default icon
                    category,
                    primary: idx === 0, // First action is primary
                    confidence: 0.9,
                    payload: tc,
                    requiresConfirmation: true,
                    confirmLabel: 'Execute',
                    url: tc.url,
                    actionType: tc.url ? 'link' : 'workflow',
                };
            });
    }
}