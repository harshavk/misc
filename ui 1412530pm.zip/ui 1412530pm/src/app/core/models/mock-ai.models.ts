import { AiThreadResponse } from './ai-thread.models';

export interface MockScenario {
    id: string;
    title: string;
    keywords: string[];          // simple keyword routing
    thread: AiThreadResponse;    // raw thread-style response
}
