export interface LoginResponse {
    token: string;
    expiration: string;
    userName: string;
    email: string;
    role: string;
    ImageUrl: string;
}