export interface EmailDraft {
    subject: string;
    body: string;
    to: string;
}