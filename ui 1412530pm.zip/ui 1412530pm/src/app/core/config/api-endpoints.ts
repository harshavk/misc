import { DASH } from "@angular/cdk/keycodes";

export const ApiEndpoints = {
    AUTH: {
        LOGIN: '/login'
    },
    EMPLOYEES: {
        GET_ALL: '/employees',
        GET_BY_ID: (id: string) => `/employees/${id}`
    },
    CHAT: {
        SEND_MESSAGE: '/chat'
    },
    DASHBOARD: {
        ACTIONS: '/dashboard/priority-actions',
        METRICS: '/dashboard/velocity-metrics',
        NOTIFICATIONS: '/dashboard/notifications'
    }
};