import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

// ✅ DIRECT MATERIAL IMPORTS (Prevents Build Errors)
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatChipsModule } from '@angular/material/chips';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';

import { Employee } from '../../../../core/models/employee';

@Component({
  selector: 'app-employee-list',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    // Material
    MatButtonModule,
    MatIconModule,
    MatProgressBarModule,
    MatCheckboxModule,
    MatChipsModule,
    MatFormFieldModule,
    MatInputModule
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './employee-list.html',
  styleUrls: ['./employee-list.css']
})
export class EmployeeListComponent {
  @Input() employees: Employee[] = [];
  @Input() selectedId: string | null = null;
  @Input() isManager: boolean = false;
  @Input() isBulkMode: boolean = false;
  @Input() selectedIds: Set<string> = new Set();
  @Input() error: string | null = null;

  @Output() selectEmployee = new EventEmitter<string>();
  @Output() toggleBulk = new EventEmitter<void>();
  @Output() toggleSelection = new EventEmitter<string>();
  @Output() search = new EventEmitter<string>();
  @Output() filter = new EventEmitter<string>();

  searchQuery = '';
  activeFilter = 'All';

  onSearch(query: string) {
    this.searchQuery = query;
    this.search.emit(query);
  }

  onFilter(filterType: string) {
    this.activeFilter = filterType;
    this.filter.emit(filterType);
  }

  handleCardClick(emp: Employee, event: Event) {
    if (this.isBulkMode) {
      this.toggleSelection.emit(emp.id);
      event.preventDefault(); // Prevent text selection
      event.stopPropagation();
    } else {
      this.selectEmployee.emit(emp.id);
    }
  }

  // Helper to check if a specific ID is in the set (Angular templates struggle with Set.has)
  isSelected(id: string): boolean {
    return this.selectedIds.has(id);
  }
}