import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';

// ✅ DIRECT MATERIAL IMPORTS
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatRippleModule } from '@angular/material/core';

import { PriorityAction, VelocityMetric } from '../../../../core/services/dashboard.service';

@Component({
  selector: 'app-command-center',
  standalone: true,
  imports: [CommonModule, MatButtonModule, MatIconModule, MatRippleModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './command-center.html',
  styleUrls: ['./command-center.css']
})
export class CommandCenterComponent {
  @Input() currentUser: any;
  @Input() totalJoiners = 0;
  @Input() startingSoon = 0;
  @Input() avgProgress = 0;
  @Input() criticalCount = 0;
  @Input() actions: PriorityAction[] = [];
  @Input() metrics: VelocityMetric[] = [];

  @Output() actionTrigger = new EventEmitter<string>();

  onAction(actionId: string) {
    this.actionTrigger.emit(actionId);
  }
}