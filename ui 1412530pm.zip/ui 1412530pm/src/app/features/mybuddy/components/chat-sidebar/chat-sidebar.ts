import { Component, EventEmitter, Input, Output, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';

// ✅ DIRECT MATERIAL IMPORTS
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTooltipModule } from '@angular/material/tooltip';

import { ChatHistoryItem } from '../../../../core/models/ai-search.models';

@Component({
  selector: 'app-chat-sidebar',
  standalone: true,
  imports: [CommonModule, MatButtonModule, MatIconModule, MatTooltipModule],
  templateUrl: './chat-sidebar.html',
  styleUrls: ['./chat-sidebar.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChatSidebarComponent {
  // ✅ Inputs matching parent binding [chatHistory]
  @Input('chatHistory') history: ChatHistoryItem[] = [];
  @Input('currentThreadId') activeThreadId: string | null = null;

  @Output() newChat = new EventEmitter<void>(); // Matches (startNew)
  @Output() clearHistory = new EventEmitter<void>(); // Matches (clearAll)
  @Output() selectThread = new EventEmitter<ChatHistoryItem>();
  @Output() deleteThread = new EventEmitter<string>();

  // Aliases to match Parent Output names if needed, 
  // but better to align template with these names:
  // Parent uses: (startNew)="startNewChat()" -> so mapped to @Output() startNew
  // Parent uses: (clearAll)="clearHistory()" -> so mapped to @Output() clearHistory
}