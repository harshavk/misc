import { Component, EventEmitter, Input, Output, ElementRef, ViewChild, AfterViewChecked, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormControl } from '@angular/forms';

// ✅ DIRECT MATERIAL IMPORTS
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatChipsModule } from '@angular/material/chips';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

import { ThreadMessage } from '../../../../core/models/ai-thread.models';
import { ActionResult } from '../../../../core/models/ai-search.models';

@Component({
  selector: 'app-chat-area',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatIconModule,
    MatButtonModule,
    MatInputModule,
    MatFormFieldModule,
    MatTooltipModule,
    MatChipsModule,
    MatProgressSpinnerModule
  ],
  templateUrl: './chat-area.html',
  styleUrls: ['./chat-area.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChatAreaComponent implements AfterViewChecked {
  @Input() messages: ThreadMessage[] = [];
  @Input() isTyping = false;
  @Input() isLoading = false;
  @Input() isListening = false;
  @Input() error: string | null = null;
  @Input() helperHint = '';
  @Input() inputStatus = '';
  @Input() queryControl!: FormControl<string>;
  @Input() userName: string = 'Employee';

  // ✅ Added to match Parent bindings
  @Input() suggestedActions: ActionResult[] = [];
  @Input() isManager: boolean = false;

  @Output() submitQuery = new EventEmitter<void>();
  @Output() toggleMic = new EventEmitter<void>();
  @Output() exportChat = new EventEmitter<void>();

  // ✅ Renamed to match Parent (was linkClick)
  @Output() contentLinkClick = new EventEmitter<{ msg: ThreadMessage, event: MouseEvent }>();
  @Output() toolPayloadClick = new EventEmitter<{ msg: ThreadMessage, tool: any, event: MouseEvent }>();

  // ✅ Added to match Parent (was missing)
  @Output() actionClick = new EventEmitter<string>();

  @ViewChild('scrollContainer') private scrollContainer!: ElementRef;

  // New Capabilities List for Empty State
  readonly capabilities = [
    { label: 'Order new hire equipment', icon: 'laptop_mac', query: 'How do I order a laptop and headset for my new hire?' },
    { label: 'Assign an onboarding buddy', icon: 'group_add', query: 'What is the process to assign a buddy to a new employee?' },
    { label: 'Set goals in Workday', icon: 'flag', query: 'Guide me through setting performance goals in Workday.' },
    { label: 'Request Cloud/LAN Access', icon: 'vpn_key', query: 'How do I request Cloud access and check LAN ID status?' },
    { label: 'View Benefits Summary', icon: 'health_and_safety', query: 'What benefits information should I review with the new hire?' }
  ];

  ngAfterViewChecked() {
    this.scrollToBottom();
  }

  private scrollToBottom(): void {
    try {
      this.scrollContainer.nativeElement.scrollTop = this.scrollContainer.nativeElement.scrollHeight;
    } catch (err) { }
  }

  onKeydownEnter(event: KeyboardEvent): void {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.submitQuery.emit();
    }
  }

  // Internal trigger for empty state tiles
  triggerAction(query: string) {
    this.queryControl.setValue(query);
    this.submitQuery.emit();
  }

  trackMessage(index: number, msg: ThreadMessage): string {
    return `${msg.type}-${index}-${msg.content?.slice(0, 20)}`;
  }
}