import { Component, ChangeDetectionStrategy, ChangeDetectorRef, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, FormGroup, ReactiveFormsModule, Validators } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { finalize } from 'rxjs';

// ✅ DIRECT MATERIAL IMPORTS
import { MatButtonModule } from '@angular/material/button';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

// Services
import { AuthService } from '../../core/services/auth.service';
import { AuthApiService } from '../../core/services/auth-api.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatInputModule,
    MatFormFieldModule,
    MatProgressBarModule,
    MatIconModule,
    MatProgressSpinnerModule
  ],
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class LoginComponent {
  private readonly fb = inject(FormBuilder);
  private readonly auth = inject(AuthService);
  private readonly api = inject(AuthApiService);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  private readonly cdr = inject(ChangeDetectorRef);

  isSubmitting = false;
  loginError: string | null = null;
  hidePassword = true;

  readonly form: FormGroup = this.fb.group({
    userId: ['', Validators.required],
    password: ['', Validators.required],
  });

  get userIdControl() { return this.form.get('userId')!; }
  get passwordControl() { return this.form.get('password')!; }

  onSubmit(): void {
    if (this.isSubmitting) return;

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.setSubmitting(true);
    this.setLoginError(null);

    const { userId, password } = this.form.value;

    this.api.login({ userId, password })
      .pipe(finalize(() => this.setSubmitting(false)))
      .subscribe({
        next: (response) => {
          this.auth.setSession(response);
          const returnUrl = this.route.snapshot.queryParamMap.get('returnUrl') || '/dashboard';
          this.router.navigateByUrl(returnUrl);
        },
        error: () => {
          this.setLoginError('Invalid credentials. Please check your User ID and password.');
        }
      });
  }

  private setSubmitting(value: boolean): void {
    this.isSubmitting = value;
    this.cdr.markForCheck();
  }

  private setLoginError(message: string | null): void {
    this.loginError = message;
    this.cdr.markForCheck();
  }
}