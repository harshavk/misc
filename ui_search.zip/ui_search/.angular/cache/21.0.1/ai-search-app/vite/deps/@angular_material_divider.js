import {
  MatDivider,
  MatDividerModule
} from "./chunk-E4CIPQBY.js";
import "./chunk-42QFQP6S.js";
import "./chunk-N4DOILP3.js";
import "./chunk-AOQ4RCD5.js";
import "./chunk-SZYYS24I.js";
import "./chunk-WKLQYTUL.js";
import "./chunk-PJVWDKLX.js";
export {
  MatDivider,
  MatDividerModule
};
