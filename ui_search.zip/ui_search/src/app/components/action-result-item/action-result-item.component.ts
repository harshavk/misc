import { Component, Input, Output, EventEmitter } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { ActionResult } from '../../models/ai-search.models';

@Component({
  selector: 'app-action-result-item',
  standalone: true,
  imports: [CommonModule, MatButtonModule, MatIconModule],
  templateUrl: './action-result-item.component.html',
  styleUrls: ['./action-result-item.component.scss'],
})
export class ActionResultItemComponent {

  @Input() action!: ActionResult;
  @Output() triggerAction = new EventEmitter<ActionResult>();

  onTrigger() {
    this.triggerAction.emit(this.action);
  }
}
