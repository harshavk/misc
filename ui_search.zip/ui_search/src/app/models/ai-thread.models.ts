export interface ThreadMessage {
    type: 'human' | 'ai';
    content: string;
    tool_call: any | null;
    // added for UI only – backend doesn’t have to send these
    timestamp?: string;
    localTimestamp?: string;
}

export interface AiThreadResponse {
    reply: string;
    thread_id: string;
    messages: ThreadMessage[];
    timestamp: string;
}

export interface AiThreadRequest {
    message: string;
    thread_id: string;
    metadata?: Record<string, unknown>;
}
