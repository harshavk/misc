import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { Employee } from '../models/employee';

// 1. Import the environment file
import { environment } from '../../../environments/environment';

@Injectable({
    providedIn: 'root'
})
export class DashboardService {
    private readonly http = inject(HttpClient);

    getEmployees(): Observable<Employee[]> {
        // 2. Use config from environment
        const config = environment.apiConfig;
        const url = config.useMock ? config.mockUrl : config.realApiUrl;

        return this.http.get<Employee[]>(url).pipe(
            catchError(err => {
                console.error('Error fetching employees:', err);
                return of([]);
            })
        );
    }

    updateEmployeeStatus(id: string, status: string): Observable<any> {
        const config = environment.apiConfig;

        if (config.useMock) {
            console.log(`[MOCK] Updating ${id} to ${status}`);
            return of({ success: true });
        }

        return this.http.patch(`${config.realApiUrl}/${id}`, { status });
    }
}