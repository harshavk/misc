import { Injectable, signal, computed } from '@angular/core';
import { User } from '../models/user.model';
import { Role } from '../models/role.enum';

const STORAGE_KEY = 'rbdui_current_user';

@Injectable({ providedIn: 'root' })
export class AuthService {
  private _currentUser = signal<User | null>(this.loadFromStorage());

  currentUser = computed(() => this._currentUser());
  isAuthenticatedSignal = computed(() => !!this._currentUser());

  login(name: string, roles: Role[]): void {
    const user: User = {
      id: Date.now(),
      name,
      roles,
    };
    this._currentUser.set(user);
    localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
  }

  logout(): void {
    this._currentUser.set(null);
    localStorage.removeItem(STORAGE_KEY);
  }

  hasRole(role: Role): boolean {
    const user = this._currentUser();
    return !!user?.roles.includes(role);
  }

  hasAnyRole(roles: Role[]): boolean {
    const user = this._currentUser();
    if (!user) return false;
    return roles.some(r => user.roles.includes(r));
  }

  isAuthenticated(): boolean {
    return this.isAuthenticatedSignal();
  }

  private loadFromStorage(): User | null {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    try {
      return JSON.parse(raw) as User;
    } catch {
      return null;
    }
  }
}
