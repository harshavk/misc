// core barrel - added in Stage 2
export * from './guards/auth.guard';
