export interface Employee {
    id: string;
    name: string;
    role: string;
    location: string;
    startDate: string;
    status: 'In Progress' | 'Not Started' | 'Completed';
    progress: number;
    avatarColor: string;
    initial: string;
    email: string;
    phone: string;

    // --- NEW FIELDS BASED ON DOCS ---
    lanId?: string;
    buddyName?: string;
    laptopStatus: 'Not Ordered' | 'Processing' | 'Shipped' | 'Delivered';

    // HR & Performance Specifics
    benefitsStatus: 'Pending' | 'Enrolled' | 'Overdue'; // 30-day window
    trainingProgress: number; // "Develop You" status
    goalsSet: boolean; // "Workday" goals status
    timesheetPending: boolean; // For "Time Check-in" review

    // Categorized Tasks (Updated Phases)
    tasks: {
        preStart: { label: string; done: boolean }[];
        firstThreeDays: { label: string; done: boolean }[]; // Renamed from dayOne
        weekOnePlus: { label: string; done: boolean }[];    // Renamed from weekOne
    };
}