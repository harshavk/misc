import { Component, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';

@Component({
  standalone: true,
  selector: 'app-employee',
  imports: [CommonModule, MatCardModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <mat-card class="wf-elevate wf-fade-in">
      <mat-card-title>Employee Area</mat-card-title>
      <mat-card-subtitle>
        Content visible to employees (and managers).
      </mat-card-subtitle>
      <p>
        Add employee specific widgets and information here.
      </p>
    </mat-card>
  `,
})
export class EmployeeComponent {}
