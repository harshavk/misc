import { ChangeDetectionStrategy, Component, inject, signal, computed, OnInit, OnDestroy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormControl, Validators } from '@angular/forms';
import { MatButtonToggleModule } from '@angular/material/button-toggle';
import { MatSnackBar } from '@angular/material/snack-bar';
import { MatIconModule } from '@angular/material/icon';

import { Router, ActivatedRoute } from '@angular/router';

// Components
import { ChatSidebarComponent } from './components/chat-sidebar/chat-sidebar';
import { ChatAreaComponent } from './components/chat-area/chat-area';
import { AuditPanelComponent } from './components/audit-panel/audit-panel';

// Models & Services
import { AiSearchService } from '../../core/services/ai-search.service';
import { AuthService } from '../../core/services/auth.service';
import { ThreadMessage } from '../../core/models/ai-thread.models';
import { ChatHistoryItem, AuditEntry, AiSearchResponse, ActionResult } from '../../core/models/ai-search.models';

@Component({
  selector: 'app-mybuddy',
  standalone: true,
  imports: [
    CommonModule, MatButtonToggleModule, MatIconModule,
    ChatSidebarComponent, ChatAreaComponent, AuditPanelComponent
  ],
  templateUrl: './mybuddy.html',
  styleUrls: ['./mybuddy.css'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class Mybuddy implements OnInit, OnDestroy {
  private readonly ai = inject(AiSearchService);
  private readonly snackBar = inject(MatSnackBar);
  private readonly auth = inject(AuthService);
  private readonly route = inject(ActivatedRoute);
  private readonly router = inject(Router);

  readonly currentUser = computed(() => this.auth.currentUser());

  private readonly HTML_TAG_REGEX = /<\/?[a-z][\s\S]*>/i;

  // Voice Variables
  private recognition?: any;
  private silenceTimer: any; // <--- Timer to track silence

  private typingTimer: any = null;
  private readonly threadMessagesStore = new Map<string, ThreadMessage[]>();
  private readonly threadResponseStore = new Map<string, AiSearchResponse>();

  // State
  readonly mobileView = signal<'history' | 'chat' | 'audit'>('chat');
  readonly queryControl = new FormControl<string>('', {
    nonNullable: true,
    validators: [Validators.required, Validators.minLength(3)],
  });

  readonly isLoading = signal(false);
  readonly error = signal<string | null>(null);
  readonly actorId = signal<'m001' | 'e001'>('m001');
  readonly isManager = signal(true);
  readonly isAiTyping = signal(false);
  readonly isListening = signal(false);

  // Hints
  private helperIntervalId: any = null;
  private readonly helperHints = [
    '“Before first day” – checklist for a new hire',
    '“Order laptop for new hire” – equipment guidance',
    '“What is left for first 3 days?”',
    '“Confirm Workday details for a new joiner”',
  ];
  readonly currentHelperIndex = signal(0);
  readonly currentHelperHint = computed(() => this.helperHints[this.currentHelperIndex()] ?? '');

  readonly inputStatus = computed(() => {
    if (this.isListening()) return 'Listening... (Speak now)';
    if (this.isLoading()) return 'Thinking about your last message…';
    const roleLabel = this.isManager() ? 'manager' : 'employee';
    return `Assistant ready for ${roleLabel} questions`;
  });

  readonly chatMessages = signal<ThreadMessage[]>([]);
  readonly currentThreadId = signal<string>('onboarding-session-1');
  readonly lastResponse = signal<AiSearchResponse | null>(null);
  readonly chatHistory = signal<ChatHistoryItem[]>([]);
  readonly auditLog = signal<AuditEntry[]>([]);
  readonly isMockMode = this.ai.isMockMode();

  readonly suggestedActions = computed<ActionResult[]>(() => this.lastResponse()?.actions ?? []);

  // --- LOGIC ---

  setMobileView(view: 'history' | 'chat' | 'audit'): void {
    this.mobileView.set(view);
  }

  // --- UPDATED VOICE LOGIC ---

  toggleMic(): void {
    this.initVoice();
    if (!this.recognition) {
      this.snackBar.open('Voice recognition is not supported in this browser', 'Dismiss', { duration: 3000 });
      return;
    }

    if (this.isListening()) {
      this.stopVoice(); // Manual stop
    } else {
      this.queryControl.setValue(''); // Clear input for new speech
      this.isListening.set(true);
      this.recognition.start();
    }
  }

  private stopVoice() {
    if (this.recognition) {
      this.recognition.stop();
    }
    this.isListening.set(false);
    clearTimeout(this.silenceTimer); // Clean up timer
  }

  private initVoice(): void {
    if (this.recognition) return;

    const Speech = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!Speech) { this.recognition = undefined; return; }

    this.recognition = new Speech();
    this.recognition.lang = 'en-US';
    this.recognition.interimResults = true;
    this.recognition.continuous = true; // Keep true so we control the stop manually

    this.recognition.onresult = (e: any) => {
      // 1. Reset Silence Timer on every word detected
      clearTimeout(this.silenceTimer);
      this.silenceTimer = setTimeout(() => {
        this.stopVoice(); // Stop after 1 second of silence
        // Optional: Auto-submit if you want
        if (this.queryControl.value.trim().length > 3) this.submitQuery();
      }, 1000); // 1000ms = 1 second

      // 2. Capture Text
      let transcript = '';
      for (let i = e.resultIndex; i < e.results.length; i++) {
        transcript += e.results[i][0].transcript;
      }

      // Append to existing value if continuous, or just set it
      // For this logic, replacing is usually cleaner for short commands
      this.queryControl.setValue(transcript.trim());
    };

    this.recognition.onerror = () => this.stopVoice();
    this.recognition.onend = () => this.stopVoice();
  }

  // --- EXISTING METHODS (No Changes needed below) ---

  submitQuery(): void {
    this.error.set(null);
    if (this.queryControl.invalid) {
      this.queryControl.markAsTouched();
      this.error.set('Please enter at least 3 characters.');
      return;
    }
    const query = this.queryControl.value.trim();
    if (!query) {
      this.error.set('Query cannot be empty.');
      return;
    }

    const userMsg: ThreadMessage = this.withLocalTimestamp({ type: 'human', content: query, tool_call: null });
    this.chatMessages.update((list) => [...list, userMsg]);
    this.isLoading.set(true);
    this.isAiTyping.set(true);

    this.ai.search(query, this.currentThreadId(), { workflow: 'onboarding' }, this.actorId())
      .subscribe({
        next: (res) => this.handleSearchSuccess(query, res),
        error: (err) => this.handleSearchError(err),
      });

    this.queryControl.setValue('');
  }

  startNewChat(): void {
    const newId = `thread-${Date.now()}`;
    this.currentThreadId.set(newId);
    this.chatMessages.set([]);
    this.lastResponse.set(null);
    this.error.set(null);
    this.isAiTyping.set(false);
    this.queryControl.setValue('');
    if (window.innerWidth <= 1000) this.mobileView.set('chat');
  }

  clearHistory(): void {
    this.chatHistory.set([]);
    this.chatMessages.set([]);
    this.lastResponse.set(null);
    this.auditLog.set([]);
    this.error.set(null);
    this.isAiTyping.set(false);
    this.threadMessagesStore.clear();
    this.threadResponseStore.clear();
    this.currentThreadId.set(`thread-${Date.now()}`);
  }

  reuseHistoryItem(item: ChatHistoryItem): void {
    this.currentThreadId.set(item.id);
    this.error.set(null);
    this.isAiTyping.set(false);
    this.isLoading.set(false);
    const msgs = this.threadMessagesStore.get(item.id);
    if (msgs) {
      this.chatMessages.set(msgs);
    } else {
      this.chatMessages.set([]);
    }
    const resp = this.threadResponseStore.get(item.id);
    this.lastResponse.set(resp ?? null);
    this.queryControl.setValue(item.query);
    if (window.innerWidth <= 1000) this.mobileView.set('chat');
  }

  removeThread(threadId: string): void {
    this.chatHistory.update((items) => items.filter((i) => i.id !== threadId));
    this.threadMessagesStore.delete(threadId);
    this.threadResponseStore.delete(threadId);
    if (this.currentThreadId() === threadId) this.startNewChat();
    this.snackBar.open('Conversation removed', 'OK', { duration: 1800 });
  }

  onContentLinkClick(msg: ThreadMessage, event: MouseEvent): void {
    const target = event.target as HTMLElement | null;
    if (!target) return;
    const anchor = target.closest('a') as HTMLAnchorElement | null;
    if (!anchor) return;
    const href = anchor.href;
    const label = (anchor.textContent || '').trim() || href;
    const stamp = new Date().toLocaleTimeString();
    const entry: AuditEntry = { text: `✓ Opened: "${label}" — ${stamp}`, href };
    this.auditLog.update((list) => [entry, ...list]);
  }

  onToolPayloadClick(msg: ThreadMessage, tool: any, event: MouseEvent): void {
    const target = event.target as HTMLElement | null;
    if (!target) return;
    const anchor = target.closest('a') as HTMLAnchorElement | null;
    if (!anchor) return;
    const href = anchor.href;
    const label = (tool?.name as string | undefined)?.replaceAll('_', ' ') || (anchor.textContent || '').trim() || href;
    const stamp = new Date().toLocaleTimeString();
    const entry: AuditEntry = { text: `✓ Action: ${label} — ${stamp}`, href };
    this.auditLog.update((list) => [entry, ...list]);
  }

  exportConversation() {
    this.snackBar.open('Export triggered', 'OK');
  }

  private handleSearchSuccess(query: string, res: AiSearchResponse): void {
    this.isLoading.set(false);
    const threadId = res.threadId;
    const fromApi = (res.historyMessages || [])
      .filter((m) => (m.type === 'human' || m.type === 'ai') && m.content !== '')
      .map((m) => this.withLocalTimestamp(m));

    setTimeout(() => {
      this.lastResponse.set(res);
      this.currentThreadId.set(threadId);
      const lastAiIndex = [...fromApi].map((m, i) => ({ m, i })).reverse().find((x) => x.m.type === 'ai')?.i;

      if (lastAiIndex == null) {
        this.chatMessages.set(fromApi);
        this.isAiTyping.set(false);
      } else {
        const base = fromApi.slice(0, lastAiIndex);
        const lastAi = fromApi[lastAiIndex];
        this.isAiTyping.set(false);
        this.startTypingEffect(lastAi, base);
      }
      this.threadMessagesStore.set(threadId, fromApi);
      this.threadResponseStore.set(threadId, res);

      const msgCount = fromApi.length;
      const lastMsgPreview = res.answers?.[0]?.content ?? '';
      const preview = lastMsgPreview.length > 80 ? lastMsgPreview.slice(0, 80) + '…' : lastMsgPreview;
      const nowIso = new Date().toISOString();

      this.chatHistory.update((items) => {
        const others = items.filter((i) => i.id !== threadId);
        return [{ id: threadId, query: res.query, createdAt: nowIso, messagesCount: msgCount, lastPreview: preview, activityHint: 'Active' }, ...others];
      });
    }, 100);
  }

  private handleSearchError(err: any): void {
    this.isLoading.set(false);
    this.isAiTyping.set(false);
    this.error.set(err?.message || 'Error calling AI');
    this.snackBar.open(this.error()!, 'Dismiss', { duration: 4000 });
  }

  private startTypingEffect(aiMessage: ThreadMessage, baseMessages: ThreadMessage[]): void {
    const fullText = aiMessage.content || '';
    if (this.HTML_TAG_REGEX.test(fullText) || aiMessage.tool_call) {
      this.chatMessages.set([...baseMessages, aiMessage]);
      return;
    }
    let index = 0;
    const workingMsg = { ...aiMessage, content: '' };
    this.chatMessages.set([...baseMessages, workingMsg]);
    if (this.typingTimer) clearInterval(this.typingTimer);

    this.typingTimer = setInterval(() => {
      index++;
      const updated = { ...workingMsg, content: fullText.slice(0, index) };
      this.chatMessages.update((list) => {
        const next = [...list];
        next[next.length - 1] = updated;
        return next;
      });
      if (index >= fullText.length) {
        clearInterval(this.typingTimer);
        this.typingTimer = null;
        this.isAiTyping.set(false);
      }
    }, 20);
  }

  private withLocalTimestamp(msg: ThreadMessage): ThreadMessage {
    return { ...msg, localTimestamp: new Date().toISOString() };
  }

  private startHelperRotation() {
    if (this.helperIntervalId) clearInterval(this.helperIntervalId);
    this.helperIntervalId = setInterval(() => {
      if ((this.queryControl.value ?? '').trim().length > 0) return;
      this.currentHelperIndex.update(i => (i + 1) % this.helperHints.length);
    }, 5000);
  }

  ngOnInit(): void {
    this.startHelperRotation();

    this.route.queryParams.subscribe(params => {
      const incomingQuery = params['q'];

      if (incomingQuery) {
        this.queryControl.setValue(incomingQuery);
        this.submitQuery();
        this.router.navigate([], {
          queryParams: { q: null },
          queryParamsHandling: 'merge',
          replaceUrl: true
        });
      }
    });
  }

  ngOnDestroy(): void {
    if (this.typingTimer) clearInterval(this.typingTimer);
    if (this.helperIntervalId) clearInterval(this.helperIntervalId);
    if (this.recognition) {
      try { this.recognition.stop(); } catch { }
    }
    clearTimeout(this.silenceTimer);
  }
}