import { Component, Input, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { AuditEntry } from '../../../../core/models/ai-search.models';

@Component({
  selector: 'app-audit-panel',
  standalone: true,
  imports: [CommonModule, MatIconModule],
  templateUrl: './audit-panel.html',
  styleUrls: ['./audit-panel.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AuditPanelComponent {
  @Input() logs: AuditEntry[] = [];
}