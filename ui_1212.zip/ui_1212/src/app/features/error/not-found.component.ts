import { Component, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { MatCardModule } from '@angular/material/card';

@Component({
  standalone: true,
  selector: 'app-not-found',
  imports: [CommonModule, RouterLink, MatCardModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <mat-card class="wf-elevate wf-fade-in">
      <mat-card-title>404 – Page Not Found</mat-card-title>
      <mat-card-subtitle>
        The page you are looking for does not exist.
      </mat-card-subtitle>
      <a routerLink="/dashboard">Go back to Dashboard</a>
    </mat-card>
  `,
})
export class NotFoundComponent {}
