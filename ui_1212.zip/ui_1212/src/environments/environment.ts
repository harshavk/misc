export const environment = {
  production: true,
  apiConfig: {
    useMock: true,
    realApiUrl: 'https://localhost:7152/api/',
    mockUrl: 'assets/data/employees.json'
  },
  aiApi: {
    baseUrl: 'https://localhost:7152',
    useMock: true,
    timeoutMs: 20000,
  },
};
