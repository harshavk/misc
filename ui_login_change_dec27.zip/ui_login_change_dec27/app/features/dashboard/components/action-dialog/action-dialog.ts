import { Component, Inject, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { provideNativeDateAdapter } from '@angular/material/core';

// ✅ Import Reference Service
import { ReferenceService } from '@core/services/reference.service';

export interface ActionDialogData {
  actionType: 'buddy' | 'access' | 'equipment' | 'meeting' | 'cloud';
  employeeName: string;
}

@Component({
  selector: 'app-action-dialog',
  standalone: true,
  imports: [
    CommonModule, FormsModule, MatDialogModule, MatButtonModule,
    MatSelectModule, MatCheckboxModule, MatInputModule, MatFormFieldModule,
    MatIconModule, MatDatepickerModule
  ],
  providers: [provideNativeDateAdapter()],
  templateUrl: './action-dialog.html',
  styleUrls: ['./action-dialog.css']
})
export class ActionDialogComponent implements OnInit {

  // ✅ Inject Reference Service
  private refService = inject(ReferenceService);

  // State
  selectedBuddy = '';
  selectedEquipment = new Set<string>();
  selectedAccess: string[] = [];

  selectedDate: Date | null = new Date();
  selectedTime: string = '10:00';
  meetingTopic = 'Onboarding Check-in';

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: ActionDialogData,
    private dialogRef: MatDialogRef<ActionDialogComponent>
  ) { }

  ngOnInit() {
    // Trigger load (cached if already loaded)
    this.refService.loadReferences();
  }

  // ✅ Getters for Template to access Signals
  get buddies() { return this.refService.data()?.buddies || []; }
  get equipmentList() { return this.refService.data()?.equipment || []; }
  get accessRoles() { return this.refService.data()?.accessRoles || []; }

  toggleEquipment(item: string) {
    if (this.selectedEquipment.has(item)) this.selectedEquipment.delete(item);
    else this.selectedEquipment.add(item);
  }

  getIcon(): string {
    const icons: Record<string, string> = {
      buddy: 'person_add', equipment: 'laptop_mac', access: 'cloud_queue',
      cloud: 'cloud_queue', meeting: 'event'
    };
    return icons[this.data.actionType] || 'bolt';
  }

  getIconColor(): string {
    const map: Record<string, string> = {
      buddy: 'icon-purple', equipment: 'icon-blue', access: 'icon-amber',
      cloud: 'icon-amber', meeting: 'icon-green'
    };
    return map[this.data.actionType] || '';
  }

  getTitle(): string {
    const titles: Record<string, string> = {
      buddy: 'Assign Buddy', equipment: 'Order Equipment',
      access: 'Request Access', cloud: 'Request Access', meeting: 'Schedule 1:1'
    };
    return titles[this.data.actionType] || 'Quick Action';
  }

  generatePrompt(): string {
    const name = this.data.employeeName;

    switch (this.data.actionType) {
      case 'buddy':
        return `Assign ${this.selectedBuddy || '[Buddy]'} as a buddy for ${name} and draft an intro email.`;

      case 'equipment':
        return `Order equipment for ${name}: ${Array.from(this.selectedEquipment).join(', ') || 'Standard Kit'}.`;

      case 'access':
      case 'cloud':
        return `Request access to ${this.selectedAccess.join(', ') || 'Systems'} for ${name}.`;

      case 'meeting':
        const dateStr = this.selectedDate ? this.selectedDate.toLocaleDateString() : 'soon';
        return `Schedule a 1:1 with ${name} on ${dateStr} at ${this.selectedTime} regarding "${this.meetingTopic}".`;

      default: return `Help me with ${this.data.actionType} for ${name}`;
    }
  }
}