import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatRippleModule } from '@angular/material/core';

// Models
import { User } from '@core/models/index';
import { PriorityAction } from '@core/services/index';

@Component({
  selector: 'app-command-center',
  standalone: true,
  imports: [CommonModule, MatButtonModule, MatIconModule, MatRippleModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './command-center.html',
  styleUrls: ['./command-center.css']
})
export class CommandCenterComponent {
  @Input() currentUser: User | null | undefined;

  // Metrics
  @Input() totalJoiners = 0;
  @Input() startingSoon = 0;
  @Input() pendingApprovals = 0; // ✅ New Input for Option A

  @Input() criticalCount = 0; // Used for the header subtitle
  @Input() actions: PriorityAction[] = [];

  @Output() actionTrigger = new EventEmitter<string>();

  onAction(actionId: string): void {
    this.actionTrigger.emit(actionId);
  }
}