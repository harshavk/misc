import { ComponentFixture, TestBed } from '@angular/core/testing';

import { BuddyAccessDialog } from './buddy-access-dialog';

describe('BuddyAccessDialog', () => {
  let component: BuddyAccessDialog;
  let fixture: ComponentFixture<BuddyAccessDialog>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [BuddyAccessDialog]
    })
    .compileComponents();

    fixture = TestBed.createComponent(BuddyAccessDialog);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
