import { Component, ChangeDetectionStrategy, signal, computed, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';

// Services & Models (Using Aliases)
import { AuthService } from '@core/services/auth.service';
import { DashboardService, PriorityAction, NotificationItem } from '@core/services/dashboard.service';
import { Role } from '@core/models/role.enum';
import { Employee } from '@core/models/employee'; // Ensure correct file name

// Child Components (Standalone)
import { EmployeeListComponent } from './components/employee-list/employee-list';
import { QuickActionsComponent } from './components/quick-actions/quick-actions';
import { CommandCenterComponent } from './components/command-center/command-center';
import { EmployeeDetailComponent } from './components/employee-detail/employee-detail';

// Material Imports
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatDialog } from '@angular/material/dialog';
import { ActionDialogComponent } from './components/action-dialog/action-dialog';

@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    MatProgressBarModule,
    EmployeeListComponent,
    QuickActionsComponent,
    CommandCenterComponent,
    EmployeeDetailComponent
  ],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DashboardComponent implements OnInit {
  private readonly auth = inject(AuthService);
  private readonly dashboardService = inject(DashboardService);
  private readonly router = inject(Router);
  private readonly dialog = inject(MatDialog);

  // --- STATE SIGNALS ---
  readonly userRole = signal<Role>(Role.Employee);
  readonly employees = signal<Employee[]>([]);

  // Widget Signals
  readonly priorityActions = signal<PriorityAction[]>([]);
  readonly notifications = signal<NotificationItem[]>([]);
  pendingApprovalsCount = signal(0);

  // Selection & UI State
  readonly selectedEmployeeId = signal<string | null>(null);
  readonly selectedEmployee = signal<Employee | null>(null);
  readonly isLoadingList = signal(true);
  readonly isLoadingDetail = signal(false);
  readonly error = signal<string | null>(null);

  // Filter & Bulk Actions
  readonly searchQuery = signal('');
  readonly activeFilter = signal('All');
  readonly isBulkMode = signal(false);
  readonly selectedIds = signal<Set<string>>(new Set());

  // --- COMPUTED PROPERTIES ---
  readonly isManager = computed(() => this.userRole() === Role.Manager);
  readonly currentUser = computed(() => this.auth.currentUser());

  readonly filteredEmployees = computed(() => {
    let data = this.employees();
    const query = this.searchQuery().toLowerCase();
    const filter = this.activeFilter();

    if (query) {
      data = data.filter(e =>
        e.name.toLowerCase().includes(query) ||
        e.id.toLowerCase().includes(query)
      );
    }

    if (filter === 'Starting Soon') {
      data = data.filter(e => e.status === 'Not Started');
    } else if (filter === 'In Progress') {
      data = data.filter(e => e.status === 'In Progress');
    }

    return data;
  });

  readonly totalJoiners = computed(() => this.employees().length);
  readonly startingSoonCount = computed(() => this.employees().filter(e => e.status === 'Not Started').length);

  readonly avgProgress = computed(() => {
    const list = this.employees();
    if (!list.length) return 0;
    const total = list.reduce((acc, curr) => acc + (curr.progress || 0), 0);
    return Math.round(total / list.length);
  });

  readonly criticalTaskCount = computed(() => this.priorityActions().length);

  ngOnInit(): void {
    this.loadDashboardData();
  }

  private loadDashboardData(): void {
    this.isLoadingList.set(true);
    this.error.set(null);

    const user = this.auth.currentUser();
    const isMgr = user?.role.includes(Role.Manager) ?? false;
    this.userRole.set(isMgr ? Role.Manager : Role.Employee);

    if (isMgr) {
      this.loadManagerData();
    } else {
      this.loadEmployeeData(user?.id);
    }
  }

  private loadManagerData(): void {
    // 1. Fetch List
    this.dashboardService.getEmployees().subscribe({
      next: (data) => {
        this.employees.set(data);
        this.isLoadingList.set(false);
      },
      error: (err) => {
        this.error.set(err.message || 'Failed to load employees');
        this.isLoadingList.set(false);
      }
    });

    // 2. Fetch Widgets
    this.dashboardService.getPriorityActions().subscribe(d => this.priorityActions.set(d));
    this.dashboardService.getNotifications().subscribe(d => this.notifications.set(d));

    // ✅ 3. Fetch Metrics (Approvals)
    this.dashboardService.getMetrics().subscribe(m => {
      this.pendingApprovalsCount.set(m.pendingApprovals);
    });
  }

  private loadEmployeeData(userId?: string): void {
    const id = userId || 'e001'; // Fallback

    this.dashboardService.getEmployeeById(id).subscribe({
      next: (employee) => {
        this.isLoadingList.set(false);
        if (employee) {
          this.employees.set([]);
          this.selectedEmployee.set(employee);
          this.selectedEmployeeId.set(employee.id);
        } else {
          this.error.set('Employee record not found.');
        }
      },
      error: (err) => {
        this.error.set(err.message || 'Failed to load profile');
        this.isLoadingList.set(false);
      }
    });
  }

  // --- ACTIONS ---

  onEmployeeClick(id: string): void {
    this.selectedEmployeeId.set(id);
    this.isLoadingDetail.set(true);

    this.dashboardService.getEmployeeById(id).subscribe({
      next: (d) => {
        if (d) this.selectedEmployee.set(d);
        this.isLoadingDetail.set(false);
      },
      error: () => this.isLoadingDetail.set(false)
    });
  }

  toggleSelection(id: string): void {
    const current = new Set(this.selectedIds());
    if (current.has(id)) current.delete(id);
    else current.add(id);
    this.selectedIds.set(current);
  }

  toggleBulkMode(): void {
    this.isBulkMode.update(v => !v);
    this.selectedIds().clear();
  }

  setFilter(filter: string): void {
    this.activeFilter.set(filter);
  }

  triggerAction(action: string): void {
    this.router.navigate(['/ally'], { queryParams: { q: `I need help with ${action}` } });
  }

  handleNotificationClick(name: string): void {
    this.router.navigate(['/ally'], { queryParams: { q: `Check status for ${name}` } });
  }

  performQuickAction(actionType: string): void {
    let employeeName = 'the new hire';

    // Case 1: Single Employee Selected via List Click
    if (this.selectedEmployee()) {
      employeeName = this.selectedEmployee()!.name;
    }

    // Case 2: Bulk Selection
    else if (this.isBulkMode() && this.selectedIds().size > 0) {
      const selectedSet = this.selectedIds();

      // Get all selected names
      const names = this.employees()
        .filter(emp => selectedSet.has(emp.id))
        .map(emp => emp.name);

      // ✅ TRUNCATION LOGIC
      if (names.length > 5) {
        const firstFive = names.slice(0, 5).join(', ');
        const remaining = names.length - 5;
        employeeName = `${firstFive}, and ${remaining} others`;
      } else {
        employeeName = names.join(', ');
      }
    }

    // Open the Wizard Dialog
    const dialogRef = this.dialog.open(ActionDialogComponent, {
      width: '95vw',
      maxWidth: '450px',
      data: { actionType, employeeName }
    });

    // Handle Result
    dialogRef.afterClosed().subscribe(prompt => {
      if (prompt) {
        this.router.navigate(['/ally'], {
          queryParams: { q: prompt }
        });
      }
    });
  }

}