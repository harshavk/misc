import { Component, inject, OnInit, signal, ViewChild, ElementRef, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatTreeModule, MatTreeNestedDataSource } from '@angular/material/tree';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner'; // ✅ Import Spinner
import { MatTooltipModule } from '@angular/material/tooltip';
import { NestedTreeControl } from '@angular/cdk/tree';
import { EmployeeProfileComponent } from '../mybuddy/components/employee-profile/employee-profile';

import { OrgChartService, EmployeeNode } from '../../core/services/org-chart.service';
import { DashboardService } from '../../core/services/dashboard.service';

import { Employee } from '../../core/models/employee';

@Component({
  selector: 'app-org-chart',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatTreeModule,
    MatIconModule,
    MatButtonModule,
    MatInputModule,
    MatFormFieldModule,
    MatProgressBarModule,
    MatProgressSpinnerModule, // ✅ Add Spinner Module
    MatTooltipModule,
    EmployeeProfileComponent
  ],
  templateUrl: './org-chart.html',
  styleUrls: ['./org-chart.css']
})
export class OrgChart implements OnInit, AfterViewInit {
  private service = inject(OrgChartService);
  private dashboardService = inject(DashboardService);


  @ViewChild('scrollContainer') scrollContainer!: ElementRef;

  treeControl = new NestedTreeControl<EmployeeNode>(node => node.reports);
  dataSource = new MatTreeNestedDataSource<EmployeeNode>();

  isLoading = signal(true);
  isLoadingProfile = signal(false);
  scale = signal(1);
  searchQuery = '';
  selectedNodeId: string | null = null;
  selectedEmployee = signal<Employee | null>(null);
  //selectedEmployee: Employee | null = null;
  // ✅ New State for Dragging
  isDragging = false;
  startX = 0;
  startY = 0;
  scrollLeft = 0;
  scrollTop = 0;

  ngOnInit() {
    this.loadInitialTree();
  }

  ngAfterViewInit() {
    // Optional: Center view initially if needed, logic is already in ngOnInit
  }

  onMouseDown(e: MouseEvent) {
    // Only drag if clicking the background (not a card)
    const target = e.target as HTMLElement;
    if (target.closest('.node-card') || target.closest('button')) return;

    this.isDragging = true;
    this.startX = e.pageX - this.scrollContainer.nativeElement.offsetLeft;
    this.startY = e.pageY - this.scrollContainer.nativeElement.offsetTop;
    this.scrollLeft = this.scrollContainer.nativeElement.scrollLeft;
    this.scrollTop = this.scrollContainer.nativeElement.scrollTop;

    // Change cursor style
    this.scrollContainer.nativeElement.style.cursor = 'grabbing';
  }

  onMouseLeave() {
    this.isDragging = false;
    if (this.scrollContainer) this.scrollContainer.nativeElement.style.cursor = 'grab';
  }

  onMouseUp() {
    this.isDragging = false;
    if (this.scrollContainer) this.scrollContainer.nativeElement.style.cursor = 'grab';
  }

  onMouseMove(e: MouseEvent) {
    if (!this.isDragging) return;

    e.preventDefault();
    const x = e.pageX - this.scrollContainer.nativeElement.offsetLeft;
    const y = e.pageY - this.scrollContainer.nativeElement.offsetTop;

    const walkX = (x - this.startX) * 1; // Scroll speed multiplier
    const walkY = (y - this.startY) * 1;

    this.scrollContainer.nativeElement.scrollLeft = this.scrollLeft - walkX;
    this.scrollContainer.nativeElement.scrollTop = this.scrollTop - walkY;
  }

  // ✅ 1. SINGLE VIEW INIT: Load pruned tree (Ancestors -> You -> Directs)
  loadInitialTree() {
    this.isLoading.set(true);

    this.service.getInitialTree().subscribe({
      next: (nodes) => {
        this.dataSource.data = nodes;

        // Auto-expand the path marked as 'expanded: true' by the service
        this.expandPredefinedPath(nodes);

        this.isLoading.set(false);

        // Center view on the current user
        setTimeout(() => this.centerOnUser(), 500);
      },
      error: (err) => {
        console.error('Failed to load tree', err);
        this.isLoading.set(false);
      }
    });
  }

  // Helper to expand nodes that are marked as expanded in the data
  private expandPredefinedPath(nodes: EmployeeNode[]) {
    for (const node of nodes) {
      if (node.expanded) {
        this.treeControl.expand(node);
        if (node.reports) {
          this.expandPredefinedPath(node.reports);
        }
      }
    }
  }

  // ✅ 2. LAZY LOADING TOGGLE
  toggleNode(node: EmployeeNode) {
    if (this.treeControl.isExpanded(node)) {
      this.treeControl.collapse(node);
    } else {
      // Lazy Load Condition: Has potential children (flag) BUT data is empty
      if (node.hasChildren && (!node.reports || node.reports.length === 0)) {

        node.isLoading = true; // Show spinner

        // Pass 'node.id' to service (assuming service uses ID)
        this.service.getChildren(node.id).subscribe({
          next: (children) => {
            node.reports = children;
            node.isLoading = false;

            // Trigger MatTree update
            const currentData = this.dataSource.data;
            this.dataSource.data = [];
            this.dataSource.data = currentData;

            this.treeControl.expand(node);
          },
          error: () => node.isLoading = false
        });

      } else {
        // Data already exists, just open it
        this.treeControl.expand(node);
      }
    }
  }

  // ✅ Use 'hasChildren' flag from service
  hasChild = (_: number, node: EmployeeNode) => node.hasChildren;

  // --- SEARCH LOGIC (Updated to work with single view) ---
  performSearch() {
    if (!this.searchQuery.trim()) return;

    const query = this.searchQuery.toLowerCase();
    const foundNode = this.findNodeRecursive(this.dataSource.data, query);

    if (foundNode) {
      this.selectedNodeId = foundNode.name; // Ideally use ID

      this.expandPathToNode(this.dataSource.data, foundNode);
      setTimeout(() => this.scrollToNode(foundNode.name), 200);
    } else {
      console.log('Employee not found in the active view.');
    }
  }

  // ... (Keep existing findNodeRecursive, expandPathToNode, scrollToNode) ...
  private findNodeRecursive(nodes: EmployeeNode[], query: string): EmployeeNode | null {
    for (const node of nodes) {
      if (node.name.toLowerCase().includes(query)) return node;
      if (node.reports) {
        const found = this.findNodeRecursive(node.reports, query);
        if (found) return found;
      }
    }
    return null;
  }

  private expandPathToNode(nodes: EmployeeNode[], target: EmployeeNode): boolean {
    for (const node of nodes) {
      if (node === target) return true;
      if (node.reports) {
        const foundInChild = this.expandPathToNode(node.reports, target);
        if (foundInChild) {
          this.treeControl.expand(node);
          return true;
        }
      }
    }
    return false;
  }

  private scrollToNode(nodeName: string) {
    const cards = document.querySelectorAll('.node-card');
    let targetEl: HTMLElement | null = null;
    cards.forEach((el: any) => {
      if (el.innerText.includes(nodeName)) targetEl = el;
    });
    if (targetEl && this.scrollContainer) {
      (targetEl as HTMLElement).scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
    }
  }

  onNodeClick(node: EmployeeNode) {
    this.selectedNodeId = node.name;

    // Check signal value instead of raw property
    if (this.selectedEmployee()?.id === node.id) return;

    this.isLoadingProfile.set(true);
    this.selectedEmployee.set(null); // Clear previous

    this.dashboardService.getEmployeeById(node.id).subscribe({
      next: (fullEmployee) => {
        if (fullEmployee) {
          this.selectedEmployee.set(fullEmployee);
        } else {
          console.warn(`User ID ${node.id} not found. Using fallback.`);
          this.setFallbackEmployee(node);
        }
        this.isLoadingProfile.set(false);
      },
      error: (err) => {
        console.error('API Error', err);
        this.setFallbackEmployee(node);
        this.isLoadingProfile.set(false);
      }
    });
  }

  private setFallbackEmployee(node: EmployeeNode) {
    this.selectedEmployee.set({
      id: node.id,
      name: node.name,
      role: node.role,
      avatar: node.img,
      location: 'Unknown',
      startDate: new Date().toISOString(),
      status: 'Unknown',
      progress: 0,
      avatarColor: '#e0e7ff',
      initial: this.getInitials(node.name),
      email: 'N/A',
      laptopStatus: 'Unknown',
      benefitsStatus: 'Unknown',
      trainingProgress: 0,
      goalsSet: false,
      tasks: { preStart: [], firstThreeDays: [], weekOnePlus: [] }
    } as Employee);
  }

  closeProfile() {
    this.selectedEmployee.set(null); // ✅ Update Signal
    this.selectedNodeId = null;
  }

  getRoleColor(role: string): string {
    // You can update this to use node.type if you prefer
    const r = role.toLowerCase();
    if (r.includes('director') || r.includes('vp')) return 'red';
    if (r.includes('manager') || r.includes('lead')) return 'amber';
    return 'blue';
  }

  getInitials(name: string): string {
    return name ? name.split(' ').map(n => n[0]).slice(0, 2).join('').toUpperCase() : '';
  }

  // Zoom & Center Logic
  zoomIn() { this.scale.update(s => Math.min(s + 0.1, 1.5)); }
  zoomOut() { this.scale.update(s => Math.max(s - 0.1, 0.5)); }
  resetZoom() { this.scale.set(1); this.centerOnUser(); }

  centerOnUser() {
    setTimeout(() => {
      const userCard = document.querySelector('.node-card.current-user');
      if (userCard) userCard.scrollIntoView({ behavior: 'smooth', block: 'center', inline: 'center' });
    }, 100);
  }
}