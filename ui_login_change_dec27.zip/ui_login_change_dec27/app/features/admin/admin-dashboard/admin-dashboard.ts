import { Component, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatRippleModule } from '@angular/material/core';

import { AdminService } from '../../../core/services/admin.service';

@Component({
  selector: 'app-admin-dashboard',
  standalone: true,
  imports: [CommonModule, MatIconModule, MatRippleModule, MatButtonModule],
  templateUrl: './admin-dashboard.html',
  styleUrls: ['./admin-dashboard.css']
})
export class AdminDashboardComponent implements OnInit {
  private readonly router = inject(Router);
  private readonly adminService = inject(AdminService);

  get adminActions() {
    return this.adminService.dashboardActions();
  }

  ngOnInit() {
    this.adminService.loadDashboardConfig();
  }

  navigateTo(route: string): void {
    this.router.navigate([route]);
  }

  goBackToApp(): void {
    this.router.navigate(['/dashboard']);
  }
}