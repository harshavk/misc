import { Component, EventEmitter, inject, Input, Output, signal, TemplateRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

// Material Imports
import { MatExpansionModule } from '@angular/material/expansion';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatRippleModule } from '@angular/material/core';

// Shared
import { PromptService } from '../../../core/services/prompt.service'; // Update path to @core
import { AutoFocusDirective } from '../../../shared/directives/auto-focus.directive';

@Component({
  selector: 'app-prompt-library',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    AutoFocusDirective,
    MatExpansionModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatDialogModule,
    MatTooltipModule,
    MatRippleModule
  ],
  templateUrl: './prompt-library.html',
  styleUrls: ['./prompt-library.css']
})
export class PromptLibraryComponent {
  // Services
  readonly promptService = inject(PromptService);
  private readonly dialog = inject(MatDialog);

  // Inputs / Outputs
  @Input() mode: 'admin' | 'select' = 'admin';
  @Output() select = new EventEmitter<string>();
  @Output() close = new EventEmitter<void>();

  // State Signals
  readonly newCategoryName = signal('');
  readonly isAddingCategory = signal(false);

  // --- Category Logic ---
  toggleAddCategory(): void {
    this.isAddingCategory.update(v => !v);
    this.newCategoryName.set('');
  }

  saveCategory(): void {
    const name = this.newCategoryName().trim();
    if (name) {
      this.promptService.addCategory(name);
      this.toggleAddCategory();
    }
  }

  // --- Prompt Logic ---
  openAddPromptDialog(catIndex: number, catName: string, template: TemplateRef<any>, event: MouseEvent): void {
    event.stopPropagation(); // Prevent accordion toggle
    this.dialog.open(template, {
      width: '500px',
      data: { catIndex, catName }
    });
  }

  savePrompt(title: string, content: string, catIndex: number): void {
    if (title && content) {
      this.promptService.addPrompt(catIndex, { title, content });
      this.dialog.closeAll();
    }
  }

  deletePrompt(catIndex: number, promptIndex: number, event: MouseEvent): void {
    event.stopPropagation();
    if (confirm('Are you sure you want to delete this prompt?')) {
      this.promptService.deletePrompt(catIndex, promptIndex);
    }
  }

  onCardClick(content: string): void {
    if (this.mode === 'select') {
      this.select.emit(content);
    }
  }
}