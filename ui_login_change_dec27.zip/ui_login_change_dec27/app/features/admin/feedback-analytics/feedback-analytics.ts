import { Component, inject, OnInit, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { delay, finalize } from 'rxjs/operators';
import { AiSearchService, FeedbackEntry } from '../../../core/services/ai-search.service';

// Shared Pipes (Ensure this path exists or remove if not using)
import { StripHtmlPipe } from '../../../shared/pipes/strip-html.pipe';

// Material Imports
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';

@Component({
  selector: 'app-feedback-analytics',
  standalone: true,
  imports: [
    CommonModule,
    StripHtmlPipe, // Uncomment if you have this pipe
    MatCardModule,
    MatIconModule,
    MatButtonModule,
    MatTableModule,
    MatTooltipModule,
    MatProgressSpinnerModule
  ],
  templateUrl: './feedback-analytics.html',
  styleUrls: ['./feedback-analytics.css']
})
export class FeedbackAnalyticsComponent implements OnInit {
  private readonly aiService = inject(AiSearchService);

  // Signals
  readonly feedbackData = signal<FeedbackEntry[]>([]);
  readonly viewingEntry = signal<FeedbackEntry | null>(null);
  readonly isLoading = signal<boolean>(true);

  readonly displayedColumns: string[] = ['rating', 'query', 'user', 'time', 'actions'];

  // Computed Stats for the Dashboard Cards
  readonly stats = computed(() => {
    const data = this.feedbackData();
    return data.reduce((acc, curr) => {
      acc.total++;
      if (curr.rating === 'like') acc.likes++;
      if (curr.rating === 'dislike') acc.dislikes++;
      return acc;
    }, { total: 0, likes: 0, dislikes: 0 });
  });

  ngOnInit(): void {
    this.loadData();
  }

  loadData(): void {
    this.isLoading.set(true);

    this.aiService.getFeedbackAnalytics()
      .pipe(
        finalize(() => this.isLoading.set(false))
      )
      .subscribe({
        next: (data) => this.feedbackData.set(data),
        error: (err) => console.error('Failed to load analytics', err)
      });
  }

  openDetail(entry: FeedbackEntry): void {
    this.viewingEntry.set(entry);
  }

  closeDetail(): void {
    this.viewingEntry.set(null);
  }
}