import { Component, inject, signal, computed, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

// Material
import { MatDialogModule, MatDialogRef } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatRippleModule } from '@angular/material/core';
import { MatDividerModule } from '@angular/material/divider';

// Services & Models
import { PromptService, PromptCategory, PromptItem } from '@core/services/prompt.service';

@Component({
  selector: 'app-prompt-library-dialog',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatDialogModule,
    MatButtonModule,
    MatIconModule,
    MatInputModule,
    MatFormFieldModule,
    MatRippleModule,
    MatDividerModule
  ],
  templateUrl: './prompt-library-dialog.html',
  styleUrls: ['./prompt-library-dialog.css']
})
export class PromptLibraryDialogComponent {
  private dialogRef = inject(MatDialogRef<PromptLibraryDialogComponent>);
  private promptService = inject(PromptService);

  // --- SIGNALS ---
  searchQuery = signal('');
  selectedCategoryId = signal<string | null>(null);

  // Access the library signal directly from your service
  library = this.promptService.library;

  constructor() {
    // Effect: Default to the first category when data loads
    effect(() => {
      const cats = this.library();
      if (cats.length > 0 && !this.selectedCategoryId() && !this.searchQuery()) {
        // Use ID if available, otherwise fallback to category name (mock mode compatibility)
        this.selectedCategoryId.set(cats[0].id || cats[0].category);
      }
    }, { allowSignalWrites: true });
  }

  // --- COMPUTED LOGIC ---

  // 1. Filtered Categories (for the Sidebar)
  // If searching, we don't hide categories, but we might highlight them later.
  sidebarCategories = computed(() => this.library());

  // 2. Active Prompts (for the Main Grid)
  displayedPrompts = computed(() => {
    const query = this.searchQuery().toLowerCase().trim();
    const allCats = this.library();

    // A. SEARCH MODE: Flatten all prompts and filter by text
    if (query) {
      return allCats.flatMap(cat => cat.prompts.filter(p =>
        p.title.toLowerCase().includes(query) ||
        p.content.toLowerCase().includes(query)
      )).map(p => ({ ...p, _categoryName: this.findCategoryName(allCats, p) }));
      // ^ Helper to show badge in search mode
    }

    // B. CATEGORY MODE: Show prompts for selected category
    const activeId = this.selectedCategoryId();
    if (!activeId) return [];

    const category = allCats.find(c => (c.id || c.category) === activeId);
    return category ? category.prompts : [];
  });

  // --- ACTIONS ---

  selectCategory(idOrName: string | undefined) {
    if (!idOrName) return;
    this.searchQuery.set(''); // Clear search when picking a category
    this.selectedCategoryId.set(idOrName);
  }

  selectPrompt(prompt: PromptItem) {
    this.dialogRef.close(prompt.content);
  }

  clearSearch() {
    this.searchQuery.set('');
    // Re-select first category if nothing selected
    if (!this.selectedCategoryId() && this.library().length > 0) {
      const first = this.library()[0];
      this.selectedCategoryId.set(first.id || first.category);
    }
  }

  // Helper for search mode UI
  private findCategoryName(cats: PromptCategory[], prompt: PromptItem): string {
    const found = cats.find(c => c.prompts.includes(prompt));
    return found ? found.category : 'General';
  }
}