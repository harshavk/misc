import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';

export const appRoutes: Routes = [
  {
    path: 'login',
    loadComponent: () =>
      import('./features/auth/login.component').then(m => m.LoginComponent),
  },
  {
    path: '',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./layout/shell.component').then(m => m.ShellComponent),
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'dashboard', data: { animation: 'Dashboard' } },
      {
        path: 'ally',
        loadComponent: () =>
          import('./features/mybuddy/mybuddy').then(
            m => m.MyBuddy
          ),
        data: { animation: 'Ally' },
      },
      {
        path: 'dashboard',
        loadComponent: () =>
          import('./features/dashboard/dashboard.component').then(
            m => m.DashboardComponent
          ),
        data: { animation: 'Dashboard' },
      },
      {
        path: 'admin/analytics',
        loadComponent: () =>
          import('./features/admin/feedback-analytics/feedback-analytics').then(
            m => m.FeedbackAnalyticsComponent
          ),
        data: { animation: 'Analytics' },
      },
      {
        path: 'admin',
        loadComponent: () =>
          import('./features/admin/admin-dashboard/admin-dashboard').then(
            m => m.AdminDashboardComponent
          ),
        data: { animation: 'Admin' },
      },
      {
        path: 'admin/prompts',
        loadComponent: () => import('./features/admin/prompt-library/prompt-library').then(m => m.PromptLibraryComponent),
        data: { animation: 'Prompts' }
      },
      {
        path: 'admin/settings',
        loadComponent: () => import('./features/admin/system-settings/system-settings').then(m => m.SystemSettingsComponent),
        data: { animation: 'Settings' }
      },
      {
        path: 'credits',
        loadComponent: () =>
          import('./features/credits/credits.component').then(
            m => m.CreditsComponent
          ),
        data: { animation: 'Credits' },
      },
      {
        path: 'org-chart',
        loadComponent: () =>
          import('./features/org-chart/org-chart').then(
            m => m.OrgChart
          ),
        data: { animation: 'OrgChart' },
      },
      {
        path: 'forbidden',
        loadComponent: () =>
          import('./features/error/forbidden.component').then(
            m => m.ForbiddenComponent
          ),
      },
      {
        path: '**',
        loadComponent: () =>
          import('./features/error/not-found.component').then(
            m => m.NotFoundComponent
          ),
      },
    ],
  },
  { path: '**', redirectTo: '' },
];