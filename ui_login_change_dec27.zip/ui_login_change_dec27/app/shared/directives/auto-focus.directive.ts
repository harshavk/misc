import { Directive, ElementRef, AfterViewInit, inject } from '@angular/core';

@Directive({
    selector: '[appAutoFocus]',
    standalone: true
})
export class AutoFocusDirective implements AfterViewInit {
    private el = inject(ElementRef);

    ngAfterViewInit() {
        // Small timeout ensures the element is fully rendered before focusing
        setTimeout(() => {
            this.el.nativeElement.focus();
        }, 100);
    }
}