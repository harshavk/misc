import {
  Directive,
  Input,
  TemplateRef,
  ViewContainerRef,
  inject,
} from '@angular/core';
import { AuthService } from '../../core/services/auth.service';
import { Role } from '../../core/models/role.enum';

@Directive({
  selector: '[appHasRole]',
  standalone: true,
})
export class HasRoleDirective {
  private auth = inject(AuthService);
  private roles: Role[] = [];

  constructor(
    private templateRef: TemplateRef<unknown>,
    private vcr: ViewContainerRef
  ) {}

  @Input('appHasRole')
  set setRoles(value: Role | Role[]) {
    this.roles = Array.isArray(value) ? value : [value];
    this.updateView();
  }

  private updateView(): void {
    this.vcr.clear();

    if (!this.roles.length) {
      this.vcr.createEmbeddedView(this.templateRef);
      return;
    }

    if (this.auth.hasAnyRole(this.roles)) {
      this.vcr.createEmbeddedView(this.templateRef);
    }
  }
}
