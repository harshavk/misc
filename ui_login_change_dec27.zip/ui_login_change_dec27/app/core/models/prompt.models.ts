export interface PromptItem {
  title: string;
  content: string;
}

export interface PromptCategoryGroup {
  category: string;
  prompts: PromptItem[];
}