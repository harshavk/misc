export interface EmployeeTask {
    label: string;
    done: boolean;
}

export interface AccessRequest {
    tool: string;
    status: 'Pending' | 'Granted';
}

export interface EmployeeTaskGroup {
    preStart: EmployeeTask[];
    firstThreeDays: EmployeeTask[];
    weekOnePlus: EmployeeTask[];
}

export interface Employee {
    id: string;
    name: string;
    role: string;
    location: string;
    startDate: string;
    status: 'In Progress' | 'Not Started' | 'Completed' | 'Unknown';
    progress: number;

    // Avatar Logic from JSON
    avatarColor?: string;
    initial?: string;
    avatar?: string; // Optional image URL (if added later)

    // Contact & details
    email: string;
    phone?: string;
    lanId?: string;
    project?: string;
    accessRequests?: AccessRequest[];
    // Statuses
    laptopStatus: string;
    benefitsStatus: string;
    buddyName?: string;

    // Metrics
    trainingProgress: number;
    goalsSet: boolean;

    // Tasks
    tasks: EmployeeTaskGroup;
}