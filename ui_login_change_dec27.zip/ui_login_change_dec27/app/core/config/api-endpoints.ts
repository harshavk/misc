import { DASH } from "@angular/cdk/keycodes";

export const ApiEndpoints = {
    AUTH: {
        LOGIN: '/login'
    },
    EMPLOYEES: {
        GET_MANAGED: (id: string) => `/employees/manager/${id}`,
        GET_ALL: '/employees',
        GET_BY_ID: (id: string) => `/employees/${id}`
    },
    CHAT: {
        SEND_MESSAGE: '/chat',
        GET_PROMPTS: '/prompts'
    },
    DASHBOARD: {
        ACTIONS: (id: string) => `/dashboard/actions/${id}`,
        METRICS: (id: string) => `/dashboard/metrics/${id}`,
        NOTIFICATIONS: (id: string) => `/dashboard/notifications/${id}`
    },
    ORG_CHART: {
        GET_INITIAL: '/org-chart/initial',
        GET_CHILDREN: (id: string) => `/org-chart/${id}/direct-reports`
    },
    PROMPTS: {
        BASE: '/prompts',
        CATEGORIES: '/prompts/categories'
    },
    REFERENCES: {
        ALL: '/references'
    },
    ADMIN: {
        DASHBOARD_CONFIG: '/admin/dashboard-config',
        FEEDBACK: '/admin/feedback',
        SETTINGS: '/admin/settings'
    }
};