import { Injectable, signal, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { catchError, delay, tap } from 'rxjs/operators';
import { of, Observable } from 'rxjs';

import { environment } from '../../../environments/environment';
import { ApiEndpoints } from '../config/api-endpoints';

export interface PromptItem {
    id?: string;
    title: string;
    content: string;
}

export interface PromptCategory {
    id?: string;
    category: string;
    prompts: PromptItem[];
}

@Injectable({
    providedIn: 'root'
})
export class PromptService {
    private http = inject(HttpClient);

    // State Signals
    library = signal<PromptCategory[]>([]);
    isLoading = signal<boolean>(false);

    // Constants
    private readonly MOCK_URL = 'assets/data/mock-prompts.json';

    constructor() {
        this.loadLibrary();
    }

    // ---------------------------------------------------------------------------
    // 1. LOAD (READ)
    // ---------------------------------------------------------------------------
    loadLibrary() {
        this.isLoading.set(true);

        let request$: Observable<PromptCategory[]>;

        // A. MOCK MODE
        if (environment.mockConfig.enablePromptLibrary) {
            console.log('⚠️ Using Mock Prompts');
            request$ = this.http.get<PromptCategory[]>(this.MOCK_URL).pipe(delay(500));
        }
        // B. REAL API MODE
        else {
            const url = `${environment.apiBaseUrl}${ApiEndpoints.PROMPTS.BASE}`;
            console.log('🌐 Using Real API:', url);
            request$ = this.http.get<PromptCategory[]>(url);
        }

        request$.pipe(
            tap(data => {
                this.library.set(data);
                this.isLoading.set(false);
            }),
            catchError(err => {
                console.error('❌ Failed to load prompts', err);
                this.isLoading.set(false);
                return of([]);
            })
        ).subscribe();
    }

    // ---------------------------------------------------------------------------
    // 2. ADD CATEGORY
    // ---------------------------------------------------------------------------
    addCategory(name: string) {
        // A. MOCK MODE (Optimistic Local Update)
        if (environment.mockConfig.enablePromptLibrary) {
            const newCat: PromptCategory = { id: `cat-${Date.now()}`, category: name, prompts: [] };
            this.library.update(list => [...list, newCat]);
        }
        // B. REAL API MODE
        else {
            const url = `${environment.apiBaseUrl}${ApiEndpoints.PROMPTS.CATEGORIES}`;
            this.http.post<PromptCategory>(url, { category: name }).subscribe({
                next: (newCat) => {
                    this.library.update(list => [...list, newCat]);
                },
                error: (err) => console.error('Failed to add category', err)
            });
        }
    }

    // ---------------------------------------------------------------------------
    // 3. ADD PROMPT
    // ---------------------------------------------------------------------------
    addPrompt(catIndex: number, prompt: PromptItem) {
        const currentList = this.library();
        const category = currentList[catIndex];

        // A. MOCK MODE
        if (environment.mockConfig.enablePromptLibrary) {
            const newPrompt = { ...prompt, id: `p-${Date.now()}` };

            // Create Deep Copy to trigger signal update correctly
            const updatedList = JSON.parse(JSON.stringify(currentList));
            updatedList[catIndex].prompts.push(newPrompt);
            this.library.set(updatedList);
        }
        // B. REAL API MODE
        else {
            if (!category.id) {
                console.error('Cannot add prompt: Category ID missing');
                return;
            }

            const url = `${environment.apiBaseUrl}${ApiEndpoints.PROMPTS.BASE}`;
            const payload = { categoryId: category.id, ...prompt };

            this.http.post<PromptItem>(url, payload).subscribe({
                next: (savedPrompt) => {
                    const updatedList = JSON.parse(JSON.stringify(currentList));
                    updatedList[catIndex].prompts.push(savedPrompt);
                    this.library.set(updatedList);
                },
                error: (err) => console.error('Failed to add prompt', err)
            });
        }
    }

    // ---------------------------------------------------------------------------
    // 4. DELETE PROMPT
    // ---------------------------------------------------------------------------
    deletePrompt(catIndex: number, promptIndex: number) {
        const currentList = this.library();
        const category = currentList[catIndex];
        const prompt = category.prompts[promptIndex];

        // A. MOCK MODE
        if (environment.mockConfig.enablePromptLibrary) {
            const updatedList = JSON.parse(JSON.stringify(currentList));
            updatedList[catIndex].prompts.splice(promptIndex, 1);
            this.library.set(updatedList);
        }
        // B. REAL API MODE
        else {
            if (!prompt.id) {
                console.error('Cannot delete prompt: Prompt ID missing');
                return;
            }

            const url = `${environment.apiBaseUrl}${ApiEndpoints.PROMPTS.BASE}/${prompt.id}`;
            this.http.delete(url).subscribe({
                next: () => {
                    const updatedList = JSON.parse(JSON.stringify(currentList));
                    updatedList[catIndex].prompts.splice(promptIndex, 1);
                    this.library.set(updatedList);
                },
                error: (err) => console.error('Failed to delete prompt', err)
            });
        }
    }
}