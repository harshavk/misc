import { inject, Injectable, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { delay, tap } from 'rxjs/operators';

import { environment } from '../../../environments/environment';
import { ApiEndpoints } from '../config/api-endpoints';
import { LoginResponse } from '../models/login-response';
import { User } from '@core/models';

@Injectable({ providedIn: 'root' })
export class AuthApiService {
    private readonly http = inject(HttpClient);

    // Storage Keys
    private readonly ACCESS_TOKEN_KEY = 'access_token';
    private readonly REFRESH_TOKEN_KEY = 'refresh_token';
    private readonly USER_KEY = 'user_profile';

    // ✅ 1. STATE: Reactive Signal for the current user
    currentUser = signal<User | null>(this.getUserFromStorage());

    /**
     * Authenticates a user.
     * Handles Mock vs Real API logic AND manages Session Storage.
     */
    login(credentials: { userId: string; password: string }): Observable<LoginResponse> {
        let login$: Observable<LoginResponse>;

        // -------------------------------------------------------------------------
        // A. DETERMINE SOURCE (Mock vs Real)
        // -------------------------------------------------------------------------
        if (environment.mockConfig.enableAuth) {
            login$ = this.getMockLogin(credentials);
        } else {
            const url = `${environment.apiBaseUrl}${ApiEndpoints.AUTH.LOGIN}`;
            login$ = this.http.post<LoginResponse>(url, credentials);
        }

        // -------------------------------------------------------------------------
        // B. HANDLE SIDE EFFECTS (Store Tokens & Update State)
        // -------------------------------------------------------------------------
        return login$.pipe(
            tap(response => this.handleAuthSuccess(response))
        );
    }

    /**
     * Clears tokens and state
     */
    logout() {
        localStorage.removeItem(this.ACCESS_TOKEN_KEY);
        localStorage.removeItem(this.REFRESH_TOKEN_KEY);
        localStorage.removeItem(this.USER_KEY);
        this.currentUser.set(null);
    }

    /**
     * Used by Interceptor to attach token
     */
    getToken(): string | null {
        return localStorage.getItem(this.ACCESS_TOKEN_KEY);
    }

    // ========================================================================
    // PRIVATE HELPERS
    // ========================================================================

    private handleAuthSuccess(response: LoginResponse) {
        // 1. Store Tokens
        localStorage.setItem(this.ACCESS_TOKEN_KEY, response.access_token);
        localStorage.setItem(this.REFRESH_TOKEN_KEY, response.refresh_token);

        // 2. Store User & Update Signal
        localStorage.setItem(this.USER_KEY, JSON.stringify(response.user));
        this.currentUser.set(response.user);

        console.log(`🔐 [Auth Service] Session created for ${response.user.name}`);
    }

    private getUserFromStorage(): User | null {
        const userJson = localStorage.getItem(this.USER_KEY);
        return userJson ? JSON.parse(userJson) : null;
    }

    private getMockLogin(credentials: { userId: string; password: string }): Observable<LoginResponse> {
        let mockFile = '';

        // Hardcoded Mock Credentials
        if (credentials.userId === 'm001' && credentials.password === 'manager') {
            mockFile = 'assets/data/login-manager.json';
        }
        else if (credentials.userId === 'a001' && credentials.password === 'admin') {
            mockFile = 'assets/data/login-admin.json';
        }
        else if (credentials.userId === 'e001' && credentials.password === 'employee') {
            mockFile = 'assets/data/login-employee.json';
        }
        else {
            return throwError(() => new Error('Invalid User ID or Password'));
        }

        return this.http.get<LoginResponse>(mockFile).pipe(
            delay(800),
            tap(res => console.log(`✅ [Mock Login] Loading file: ${mockFile}`))
        );
    }
}