import { Injectable, signal, effect } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class AppConfigService {

    // 1. Define the Signal (Default value: 'Onboard Assistant')
    appName = signal<string>('Onboard Assistant');

    constructor() {
        // 2. Try to load saved name from LocalStorage on startup
        const savedName = localStorage.getItem('wf_app_name');
        if (savedName) {
            this.appName.set(savedName);
        }

        // 3. Automatically save to LocalStorage whenever the signal changes
        effect(() => {
            localStorage.setItem('wf_app_name', this.appName());
        });
    }

    // 4. Method to update the name
    updateAppName(newName: string) {
        this.appName.set(newName);
    }
}