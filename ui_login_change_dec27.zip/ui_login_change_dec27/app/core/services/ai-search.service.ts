import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { delay, map, switchMap, shareReplay, catchError } from 'rxjs/operators';

import { environment } from '../../../environments/environment';
import {
    AiThreadRequest,
    AiThreadResponse,
    ThreadMessage
} from '../models/ai-thread.models';
import {
    ActionResult,
    AnswerResult,
    AiSearchResponse,
} from '../models/ai-search.models';
import { MockScenario } from '../models/mock-ai.models';
import { AuthService } from './auth.service';
import { ApiEndpoints } from '@core/config/api-endpoints';

const MOCK_DATA_URL = 'assets/data/mock-ai-responses.json';

// Define Feedback Interface locally or import if shared
export interface FeedbackEntry {
    id: string;
    query: string;
    aiResponse: string;
    user: string;
    rating: 'like' | 'dislike' | null;
    timestamp: string;
    category: 'HR' | 'IT' | 'General';
}

@Injectable({ providedIn: 'root' })
export class AiSearchService {
    private readonly http = inject(HttpClient);
    private readonly auth = inject(AuthService);

    private mockScenarios$: Observable<MockScenario[]> | null = null;

    // ---------------------------------------------------------------------------
    // 1. PUBLIC API (SEARCH)
    // ---------------------------------------------------------------------------

    search(
        query: string,
        threadId: string,
        metadata: Record<string, unknown> = { workflow: 'onboarding' },
        actor_id?: string
    ): Observable<AiSearchResponse> {

        const realActorId = actor_id || this.auth.currentUser()?.id || 'anonymous';

        const payload: AiThreadRequest = {
            message: query,
            thread_id: threadId,
            metadata,
            actor_id: realActorId,
        };

        const minDelayMs = environment.mockConfig.enableChat ? 1200 : 0;
        const started = Date.now();

        const response$ = environment.mockConfig.enableChat
            ? this.getMockResponse(query, payload)
            : this.http.post<AiThreadResponse>(`${environment.apiBaseUrl}/chat`, payload);

        return response$.pipe(
            // ✅ FIX: 'mock-json' and 'python-api' are now valid strings
            map((raw) =>
                this.mapToUi(query, raw, environment.mockConfig.enableChat ? 'mock-json' : 'python-api')
            ),
            switchMap((uiResponse) => {
                const elapsed = Date.now() - started;
                const remainingDelay = Math.max(0, minDelayMs - elapsed);
                return remainingDelay > 0 ? of(uiResponse).pipe(delay(remainingDelay)) : of(uiResponse);
            }),
            catchError(err => {
                console.error('Search failed', err);
                return of(this.getErrorResponse(query, threadId));
            })
        );
    }

    // ---------------------------------------------------------------------------
    // 2. HELPERS (Missing Methods Fixed)
    // ---------------------------------------------------------------------------
    isMockMode(): boolean {
        return environment.mockConfig.enableFeedback;
    }

    getFeedbackAnalytics(): Observable<FeedbackEntry[]> {
        // A. MOCK MODE
        if (this.isMockMode()) {
            return this.http.get<FeedbackEntry[]>('assets/data/mock-feedback.json').pipe(
                delay(600),
                catchError(err => {
                    console.error('Failed to load mock feedback', err);
                    return of([]);
                })
            );
        }

        // B. REAL API MODE
        const url = `${environment.apiBaseUrl}${ApiEndpoints.ADMIN.FEEDBACK}`;
        return this.http.get<FeedbackEntry[]>(url).pipe(
            catchError(err => {
                console.error('Failed to load feedback analytics', err);
                return of([]);
            })
        );
    }

    loadHistory(threadId: string): Observable<ThreadMessage[]> {
        const userId = this.auth.currentUser()?.id || 'anon';
        const key = `wf_chat_${userId}_${threadId}`;
        const raw = localStorage.getItem(key);
        return of(raw ? JSON.parse(raw) : []).pipe(delay(200));
    }

    saveHistory(threadId: string, messages: ThreadMessage[]): Observable<void> {
        const userId = this.auth.currentUser()?.id || 'anon';
        const key = `wf_chat_${userId}_${threadId}`;
        localStorage.setItem(key, JSON.stringify(messages));
        return of(void 0);
    }

    clearHistory(threadId: string): Observable<void> {
        const userId = this.auth.currentUser()?.id || 'anon';
        const key = `wf_chat_${userId}_${threadId}`;
        localStorage.removeItem(key);
        return of(void 0);
    }

    // ---------------------------------------------------------------------------
    // 3. MOCK LOGIC
    // ---------------------------------------------------------------------------

    private getMockResponse(query: string, payload: AiThreadRequest): Observable<AiThreadResponse> {
        return this.loadMockScenarios().pipe(
            map((scenarios) => {
                const scenario = this.pickScenario(query, scenarios);
                return this.buildThreadFromScenario(payload, scenario);
            })
        );
    }

    private loadMockScenarios(): Observable<MockScenario[]> {
        if (!this.mockScenarios$) {
            this.mockScenarios$ = this.http.get<MockScenario[]>(MOCK_DATA_URL).pipe(
                shareReplay(1),
                catchError(err => {
                    console.error('Failed to load mock JSON', err);
                    return of([]);
                })
            );
        }
        return this.mockScenarios$;
    }

    private pickScenario(query: string, scenarios: MockScenario[]): MockScenario {
        const q = query.toLowerCase();
        const match = scenarios.find((s) =>
            (s.keywords || []).some((k) => q.includes(k.toLowerCase()))
        );
        if (match) return match;
        return scenarios.find((s) => s.id === 'generic-fallback') ||
            scenarios[0] ||
            this.createEmergencyFallback();
    }

    private buildThreadFromScenario(req: AiThreadRequest, scenario: MockScenario): AiThreadResponse {
        const now = new Date().toISOString();
        const base = scenario.thread;

        const messages: ThreadMessage[] = [
            { type: 'human', content: req.message, tool_call: null },
            ...base.messages.filter((m) => m.type !== 'human'),
        ];

        return {
            reply: base.reply,
            thread_id: req.thread_id || base.thread_id || 'mock-thread',
            timestamp: now,
            messages: messages,
        };
    }

    private createEmergencyFallback(): MockScenario {
        return {
            id: 'emergency',
            title: 'System Unavailable',
            keywords: [],
            thread: {
                thread_id: 'emergency-thread',
                timestamp: new Date().toISOString(),
                reply: "I am unable to connect to my knowledge base right now.",
                messages: [{ type: 'ai', content: "I am unable to connect to my knowledge base right now.", tool_call: null }]
            }
        };
    }

    // ---------------------------------------------------------------------------
    // 4. UI MAPPING
    // ---------------------------------------------------------------------------

    private mapToUi(
        query: string,
        raw: AiThreadResponse,
        // ✅ FIX: Parameter type relaxed to allow specific strings
        source: string
    ): AiSearchResponse {
        const createdAt = raw.timestamp || new Date().toISOString();

        return {
            id: `${raw.thread_id}:${createdAt}`,
            query,
            createdAt,
            answers: this.extractAnswers(raw),
            actions: this.extractActions(raw, query),
            meta: {
                latencyMs: 150,
                model: 'mock-v1',
                source: source as any, // Cast to match model if needed, or rely on relaxed model
            },
            threadId: raw.thread_id,
            historyMessages: raw.messages,
        };
    }

    private extractAnswers(raw: AiThreadResponse): AnswerResult[] {
        const answers: AnswerResult[] = [];
        if (raw.reply) {
            answers.push({
                id: 'ans-main',
                title: 'Ally',
                content: raw.reply,
                type: 'summary',
                confidence: 1.0,
                isHtml: false,
                tags: [],
                references: []
            });
        }
        return answers;
    }

    private extractActions(raw: AiThreadResponse, originalQuery: string): ActionResult[] {
        return raw.messages
            .filter((m) => !!m.tool_call)
            .map((m, idx) => {
                const tc = m.tool_call!;
                return {
                    id: `act-${idx}`,
                    query: originalQuery,
                    label: tc.name || 'Action',
                    description: tc.description || '',
                    icon: 'bolt',
                    category: (tc.type as any) || 'workflow',
                    primary: idx === 0,
                    confidence: 1.0,
                    payload: tc,
                    requiresConfirmation: false,
                    confirmLabel: 'Go',
                    url: tc.url,
                    actionType: tc.url ? 'link' : 'workflow'
                };
            });
    }

    private getErrorResponse(query: string, threadId: string): AiSearchResponse {
        return {
            id: 'error',
            query,
            createdAt: new Date().toISOString(),
            answers: [{
                id: 'err', title: 'Error', content: 'Sorry, something went wrong processing your request.',
                type: 'summary', confidence: 0, isHtml: false, tags: [], references: []
            }],
            actions: [],
            // ✅ FIX: 'error' source is now valid due to Model update
            meta: { latencyMs: 0, model: 'error', source: 'error' },
            threadId,
            historyMessages: []
        };
    }
}