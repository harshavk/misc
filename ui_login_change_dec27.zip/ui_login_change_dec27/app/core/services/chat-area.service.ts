import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { catchError, delay, shareReplay } from 'rxjs/operators';

import { environment } from '../../../environments/environment';
import { ApiEndpoints } from '../config/api-endpoints';

// --- Interfaces ---
export interface Prompt {
    title: string;
    content: string;
}

export interface PromptCategory {
    category: string;
    prompts: Prompt[];
}

@Injectable({
    providedIn: 'root'
})
export class ChatAreaService {
    private readonly http = inject(HttpClient);

    // Cache
    private promptLibrary$: Observable<PromptCategory[]> | null = null;

    // Constants
    private readonly MOCK_PROMPTS_URL = 'assets/data/mock-prompts.json';

    getPromptLibrary(): Observable<PromptCategory[]> {
        // Return cached if available
        if (this.promptLibrary$) {
            return this.promptLibrary$;
        }

        let request$: Observable<PromptCategory[]>;

        // 1. Mock Mode
        if (environment.mockConfig.enablePromptLibrary) {
            request$ = this.http.get<PromptCategory[]>(this.MOCK_PROMPTS_URL).pipe(
                delay(400) // Simulate latency
            );
        }

        // 2. Real API Mode
        else {
            // ✅ Use the Constant here
            const url = `${environment.apiBaseUrl}${ApiEndpoints.CHAT.GET_PROMPTS}`;
            request$ = this.http.get<PromptCategory[]>(url);
        }

        // 3. Pipe & Cache
        this.promptLibrary$ = request$.pipe(
            catchError(err => {
                console.error('Error loading prompt library', err);
                return of([]); // Prevent app crash
            }),
            shareReplay(1)
        );

        return this.promptLibrary$;
    }
}