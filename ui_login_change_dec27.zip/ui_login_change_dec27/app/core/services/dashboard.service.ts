import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { catchError, map, delay, shareReplay } from 'rxjs/operators';

import { Employee } from '../models/employee';
import { environment } from '../../../environments/environment';
import { ApiEndpoints } from '../config/api-endpoints';
import { AuthService } from './auth.service';

// ============================================================================
// WIDGET DATA MODELS
// ============================================================================

export interface PriorityAction {
    id: string;
    type: 'high' | 'medium' | 'low';
    title: string;
    time: string;
    description: string;
    descriptionBold?: string;
    icon: string;
    actionLabel: string;
    actionId: string;
}

export interface NotificationItem {
    id: string;
    user: string;
    message: string;
    isUrgent?: boolean;
}

// Helper to match the JSON structure
interface MockDashboardData {
    priorityActions: PriorityAction[];
    notifications: NotificationItem[];
    // ✅ ADDED METRICS SUPPORT
    metrics?: {
        pendingApprovals: number;
        totalJoiners: number;
        startingSoon: number;
    };
}

// ============================================================================
// SERVICE
// ============================================================================

@Injectable({
    providedIn: 'root'
})
export class DashboardService {
    private readonly http = inject(HttpClient);
    private readonly auth = inject(AuthService);

    // Cache for widget data to avoid reloading the same JSON multiple times
    private mockWidgets$: Observable<MockDashboardData> | null = null;

    // Constant path for the mock file
    private readonly MOCK_WIDGET_URL = 'assets/data/mock-dashboard.json';

    // --- 1. EMPLOYEE DATA APIS ---

    getEmployees(): Observable<Employee[]> {
        if (environment.mockConfig.enableDashboard) {
            return this.http.get<Employee[]>('assets/data/employees.json').pipe(
                delay(600),
                catchError(this.handleError),
                shareReplay(1)
            );
        } else {
            const userId = this.getCurrentUserId();
            const url = `${environment.apiBaseUrl}${ApiEndpoints.EMPLOYEES.GET_MANAGED(userId)}`;
            return this.http.get<Employee[]>(url).pipe(catchError(this.handleError));
        }
    }

    getEmployeeById(id: string): Observable<Employee | undefined> {
        if (environment.mockConfig.enableDashboard) {
            return this.http.get<Employee[]>('assets/data/employees.json').pipe(
                delay(400),
                map(employees => employees.find(e => e.id === id)),
                catchError(this.handleError)
            );
        } else {
            const url = `${environment.apiBaseUrl}${ApiEndpoints.EMPLOYEES.GET_BY_ID(id)}`;
            return this.http.get<Employee>(url).pipe(catchError(this.handleError));
        }
    }

    // --- 2. DASHBOARD WIDGET APIS ---
    getBuddyGapAnalysis(employeeId: string): Observable<any> {
        if (environment.mockConfig.enableDashboard) {
            return this.getEmployees().pipe(
                map(allEmployees => {
                    const currentUser = allEmployees.find(e => e.id === employeeId);

                    if (!currentUser) {
                        throw new Error(`Employee ID ${employeeId} not found`);
                    }

                    // CHECK 1: Does the user have a buddy assigned?
                    if (!currentUser.buddyName) {
                        throw new Error('No Buddy Assigned');
                    }

                    // CHECK 2: Does that Buddy exist in our database?
                    const buddy = allEmployees.find(e => e.name === currentUser.buddyName);
                    if (!buddy) {
                        throw new Error(`Buddy "${currentUser.buddyName}" not found in employee directory.`);
                    }

                    // Logic: Access Gap Analysis
                    const buddyTools = buddy.accessRequests || [];
                    const myTools = currentUser.accessRequests || [];

                    const missingTools = buddyTools
                        .filter(bReq => bReq.status === 'Granted')
                        .filter(bReq => {
                            const myMatch = myTools.find(m => m.tool === bReq.tool);
                            return !myMatch || myMatch.status === 'Pending';
                        });

                    return {
                        user: currentUser,
                        buddy: buddy,
                        missingTools: missingTools
                    };
                }),
                catchError(err => this.handleError(err)) // Ensure we catch the errors thrown above
            );
        } else {
            // REAL API LOGIC
            // Assuming backend has a specific endpoint for this complex logic
            // e.g., GET /api/v1/employees/{id}/access-gap
            const url = `${environment.apiBaseUrl}/employees/${employeeId}/access-gap`;
            return this.http.get<any>(url).pipe(catchError(this.handleError));
        }
    }
    getPriorityActions(): Observable<PriorityAction[]> {
        if (environment.mockConfig.enableDashboard) {
            return this.getMockWidgets().pipe(map(data => data.priorityActions));
        } else {
            const userId = this.getCurrentUserId();
            const url = `${environment.apiBaseUrl}${ApiEndpoints.DASHBOARD.ACTIONS(userId)}`;
            return this.http.get<PriorityAction[]>(url).pipe(catchError(this.handleError));
        }
    }

    getNotifications(): Observable<NotificationItem[]> {
        if (environment.mockConfig.enableDashboard) {
            return this.getMockWidgets().pipe(map(data => data.notifications));
        } else {
            const userId = this.getCurrentUserId();
            const url = `${environment.apiBaseUrl}${ApiEndpoints.DASHBOARD.NOTIFICATIONS(userId)}`;
            return this.http.get<NotificationItem[]>(url).pipe(catchError(this.handleError));
        }
    }

    getMetrics(): Observable<{ pendingApprovals: number }> {
        if (environment.mockConfig.enableDashboard) {
            return this.getMockWidgets().pipe(
                // ✅ Now safe because interface matches
                map(data => data.metrics || { pendingApprovals: 0, totalJoiners: 0, startingSoon: 0 })
            );
        } else {
            const userId = this.getCurrentUserId();
            // Assuming metrics endpoint returns partial object
            return this.http.get<{ pendingApprovals: number }>(
                `${environment.apiBaseUrl}${ApiEndpoints.DASHBOARD.METRICS(userId)}`
            ).pipe(catchError(this.handleError));
        }
    }

    // --- 3. INTERNAL HELPERS ---

    private getCurrentUserId(): string {
        return this.auth.currentUser()?.id || 'm001';
    }

    private getMockWidgets(): Observable<MockDashboardData> {
        if (!this.mockWidgets$) {
            this.mockWidgets$ = this.http.get<MockDashboardData>(this.MOCK_WIDGET_URL).pipe(
                delay(500),
                catchError((err) => {
                    console.error('Failed to load mock dashboard widgets', err);
                    return of({ priorityActions: [], notifications: [], metrics: { pendingApprovals: 0, totalJoiners: 0, startingSoon: 0 } });
                }),
                shareReplay(1)
            );
        }
        return this.mockWidgets$;
    }

    private handleError(error: HttpErrorResponse) {
        console.error('API Error:', error);
        const message = error.message || 'Something went wrong. Please try again.';
        return throwError(() => new Error(message));
    }
}