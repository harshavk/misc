// shared barrel
export * from './directives/has-role.directive';
