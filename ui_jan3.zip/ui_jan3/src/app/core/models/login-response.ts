// export interface LoginResponse {
//     token: string;
//     expiration: string;
//     userId: string;
//     name: string;
//     email: string;
//     role: string;
//     ImageUrl: string;
// }

import { User } from "./user.model";

export interface LoginResponse {
    access_token: string;
    refresh_token: string;
    user: User;
}