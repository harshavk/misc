import { trigger, transition, style, query, animate } from '@angular/animations';

export const fadeAnimation = trigger('fadeAnimation', [
    transition('* => *', [
        // Ensure the new page starts hidden and slightly lower
        query(':enter', [
            style({ opacity: 0, transform: 'translateY(15px)' })
        ], { optional: true }),

        // Animate it in smoothly
        query(':enter', [
            animate('0.3s ease-out', style({ opacity: 1, transform: 'translateY(0)' }))
        ], { optional: true })
    ])
]);