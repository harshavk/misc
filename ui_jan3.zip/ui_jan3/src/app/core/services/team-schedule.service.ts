import { Injectable, signal } from '@angular/core';


export interface CalendarEvent {
    id: string;
    employeeId: string;
    title: string;
    employeeName: string;
    date: string; // ISO String for storage
    startTime?: string;
    endTime?: string;
    type: 'onboarding' | '1:1' | 'training' | 'buddy' | 'team';
    color: string;
}

@Injectable({ providedIn: 'root' })
export class TeamScheduleService {
    private readonly STORAGE_KEY = 'wf_team_events';

    // Reactive signal for components to consume
    readonly events = signal<CalendarEvent[]>([]);

    constructor() {
        this.loadEvents();
    }

    private loadEvents() {
        const raw = localStorage.getItem(this.STORAGE_KEY);
        if (raw) {
            this.events.set(JSON.parse(raw));
        }
    }

    addEvent(event: Partial<CalendarEvent>) {
        const newEvent: CalendarEvent = {
            id: crypto.randomUUID(),
            employeeId: event.employeeId || 'unknown',
            title: event.title || 'New Event',
            employeeName: event.employeeName || 'Unknown',
            date: event.date || new Date().toISOString(),
            type: event.type || '1:1',
            color: this.getColorForType(event.type || '1:1'),
            startTime: event.startTime,
            endTime: event.endTime
        };

        this.events.update(current => [...current, newEvent]);
        this.saveToStorage();
    }

    getMyEvents(): CalendarEvent[] {
        const rawData = localStorage.getItem(this.STORAGE_KEY);
        if (!rawData) return [];

        try {
            const events: CalendarEvent[] = JSON.parse(rawData);

            // Optional: Filter out past events
            const now = new Date();
            return events
                .filter(e => new Date(e.date) >= now)
                .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());

        } catch (error) {
            console.error('Error parsing events from storage', error);
            return [];
        }
    }

    private saveToStorage() {
        localStorage.setItem(this.STORAGE_KEY, JSON.stringify(this.events()));
    }

    private getColorForType(type: string): string {
        switch (type) {
            case 'onboarding': return 'var(--color-primary-blue, #3b82f6)';
            case 'team': return 'var(--color-primary-blue, #3b82f6)'; // ✅ Team Events = Blue
            case '1:1': return 'var(--color-warning, #f59e0b)';      // 1:1 = Amber
            case 'buddy': return 'var(--color-purple, #8b5cf6)';
            case 'training': return '#ec4899';
            default: return '#64748b';
        }
    }
}