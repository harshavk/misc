import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, shareReplay, catchError } from 'rxjs/operators';
import { of } from 'rxjs';
import { Role } from '../models/role.enum';

export interface NavItem {
    label: string;
    icon: string;
    route: string;
    roles?: Role[];
}

interface ShellConfig {
    appTitle: string;
    main: NavItem[];
    admin: NavItem[];
}

@Injectable({
    providedIn: 'root'
})
export class ShellService {
    private http = inject(HttpClient);
    private readonly CONFIG_URL = 'assets/data/navigation.json';

    // State Signals
    readonly mainNavItems = signal<NavItem[]>([]);
    readonly adminNavItems = signal<NavItem[]>([]);
    readonly appTitle = signal<string>('WF App');

    constructor() {
        this.loadConfig();
    }

    private loadConfig() {
        this.http.get<ShellConfig>(this.CONFIG_URL).pipe(
            shareReplay(1),
            catchError(err => {
                console.error('Failed to load navigation config', err);
                return of({ appTitle: 'WF App', main: [], admin: [] });
            })
        ).subscribe(config => {
            this.appTitle.set(config.appTitle);
            this.mainNavItems.set(config.main);
            this.adminNavItems.set(config.admin);
        });
    }
}