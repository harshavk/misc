import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { of } from 'rxjs';
import { tap, catchError, shareReplay } from 'rxjs/operators';
import { environment } from '../../../environments/environment';
import { ApiEndpoints } from '../config/api-endpoints';

export interface ReferenceData {
    buddies: { id: string; name: string; role: string }[];
    equipment: string[];
    accessRoles: string[];
}

@Injectable({ providedIn: 'root' })
export class ReferenceService {
    private http = inject(HttpClient);

    // Cache
    readonly data = signal<ReferenceData | null>(null);

    loadReferences() {
        if (this.data()) return; // Already loaded

        let request$;

        if (environment.mockConfig.enableDashboard) {
            request$ = this.http.get<ReferenceData>('assets/data/mock-references.json');
        } else {
            request$ = this.http.get<ReferenceData>(`${environment.apiBaseUrl}${ApiEndpoints.REFERENCES.ALL}`);
        }

        request$.pipe(
            tap(res => this.data.set(res)),
            catchError(err => {
                console.error('Failed to load references', err);
                return of(null);
            }),
            shareReplay(1)
        ).subscribe();
    }
}