import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { delay, map } from 'rxjs/operators';

import { environment } from '../../../environments/environment';
import { ApiEndpoints } from '../config/api-endpoints';

export interface EmployeeNode {
    id: string;
    name: string;
    role: string;
    img?: string;
    type: 'manager' | 'lead' | 'employee';
    isCurrentUser?: boolean;

    // Lazy Loading props
    hasChildren?: boolean;
    reports?: EmployeeNode[];
    expanded?: boolean;
    isLoading?: boolean;
}

@Injectable({ providedIn: 'root' })
export class OrgChartService {
    private readonly http = inject(HttpClient);

    // Constant for mock file
    private readonly MOCK_ORG_URL = 'assets/data/mock-org-chart.json';

    // Cache the full raw data to simulate a DB in mock mode
    private rawDataCache: EmployeeNode[] = [];

    // -------------------------------------------------------------------------
    // 1. INITIAL LOAD: Get Path to User
    // -------------------------------------------------------------------------
    getInitialTree(viewMode: 'FULL_ORG' | 'MY_TEAM' = 'MY_TEAM'): Observable<EmployeeNode[]> {

        // A. MOCK MODE
        if (environment.mockConfig.enableOrgChart) {

            // 🔥 GENERATE 1,000+ NODES
            const largeData = this.generateLargeData(4, 5);

            // The ID we marked as "isMe" in the generator
            const currentUserId = 'e50';

            console.log(`Generated Large Dataset. View Mode: ${viewMode}`);

            return of(largeData).pipe(
                delay(1000),
                map(data => {
                    // 1. Map raw data to EmployeeNode format
                    this.rawDataCache = this.mapWorkdayResponse(data, currentUserId);

                    // 2. APPLY VIEW LOGIC
                    if (viewMode === 'MY_TEAM') {
                        // ✅ Show Manager + Peers + You
                        return this.filterForTeamView(this.rawDataCache, currentUserId);
                    } else {
                        // ⏹️ Show Full Hierarchy (CEO -> You)
                        return this.pruneTreeForUser(this.rawDataCache);
                    }
                })
            );
        }

        // B. REAL API MODE
        else {
            const url = `${environment.apiBaseUrl}${ApiEndpoints.ORG_CHART.GET_INITIAL}`;

            // Assuming Real API returns raw nodes, we apply the same logic:
            return this.http.get<EmployeeNode[]>(url).pipe(
                map(nodes => {
                    // You need a way to know real user ID here (e.g., from AuthService)
                    const realUserId = 'e001'; // Replace with actual auth logic

                    this.rawDataCache = nodes; // Assuming nodes are already mapped or map them here

                    if (viewMode === 'MY_TEAM') {
                        return this.filterForTeamView(this.rawDataCache, realUserId);
                    }
                    return this.pruneTreeForUser(this.rawDataCache);
                })
            );
        }
    }

    // -------------------------------------------------------------------------
    // 2. LAZY LOAD: Get Children for specific ID
    // -------------------------------------------------------------------------
    getChildren(parentId: string): Observable<EmployeeNode[]> {

        // A. MOCK MODE
        if (environment.mockConfig.enableOrgChart) {
            const children = this.findChildrenInCache(this.rawDataCache, parentId);
            return of(children).pipe(delay(600));
        }

        // B. REAL API MODE
        else {
            // ✅ Use Constant
            const url = `${environment.apiBaseUrl}${ApiEndpoints.ORG_CHART.GET_CHILDREN(parentId)}`;
            return this.http.get<EmployeeNode[]>(url);
        }
    }

    // -------------------------------------------------------------------------
    // --- HELPERS (Mock Logic simulation) ---
    // -------------------------------------------------------------------------

    private mapWorkdayResponse(entries: any[], currentUserId: string): EmployeeNode[] {
        return entries.map(entry => ({
            id: entry.Employee_ID,
            name: entry.Legal_Name,
            role: entry.Business_Title,
            img: entry.Photo_URL,

            // Checks if this specific node matches the passed ID
            isCurrentUser: entry.Employee_ID === currentUserId,

            type: this.getUiType(entry.Management_Level),
            hasChildren: entry.workers && entry.workers.length > 0,

            // Pass the ID down recursively to children
            reports: entry.workers ? this.mapWorkdayResponse(entry.workers, currentUserId) : []
        }));
    }

    private pruneTreeForUser(nodes: EmployeeNode[]): EmployeeNode[] {
        return nodes.map(node => {
            const isUserInBranch = this.checkBranchForUser(node);

            if (isUserInBranch) {
                return {
                    ...node,
                    expanded: true, // Auto-expand path
                    reports: this.pruneTreeForUser(node.reports || [])
                };
            } else {
                return {
                    ...node,
                    expanded: false,
                    reports: [], // Clear reports to save memory
                    hasChildren: node.reports && node.reports.length > 0
                };
            }
        });
    }

    private filterForTeamView(nodes: EmployeeNode[], userId: string): EmployeeNode[] {

        // Step 1: Find the manager (the parent of the current user)
        const manager = this.findParentOfUser(nodes, userId);

        if (manager) {
            // Step 2: Clone the manager so we don't mutate the cache
            const managerClone = { ...manager };

            // Step 3: Clean up the manager's reports (Your Peers)
            managerClone.reports = (manager.reports || []).map(peer => {

                // Is this peer YOU?
                if (peer.id === userId) {
                    // Return YOU with your children (if you have any)
                    return { ...peer, expanded: true };
                }

                // Is this a PEER?
                else {
                    // Return peer, but hide THEIR children to reduce noise
                    return {
                        ...peer,
                        reports: [],
                        hasChildren: peer.reports && peer.reports.length > 0,
                        expanded: false
                    };
                }
            });

            // Step 4: Auto-expand the manager so you see the team immediately
            managerClone.expanded = true;

            // Return Manager as the single root node
            return [managerClone];
        }

        // Fallback: If no manager found (e.g., you are the CEO), return you as root
        const me = nodes.find(n => n.id === userId);
        return me ? [me] : [];
    }

    // Helper to find the node that contains the user in its 'reports' list
    private findParentOfUser(nodes: EmployeeNode[], userId: string): EmployeeNode | null {
        for (const node of nodes) {
            // Check if any child of this node is the user
            if (node.reports?.some(child => child.id === userId)) {
                return node; // Found the manager!
            }

            // Recurse down
            if (node.reports) {
                const found = this.findParentOfUser(node.reports, userId);
                if (found) return found;
            }
        }
        return null; // Not found in this branch
    }

    private checkBranchForUser(node: EmployeeNode): boolean {
        if (node.isCurrentUser) return true;
        return node.reports?.some(child => this.checkBranchForUser(child)) ?? false;
    }

    private findChildrenInCache(nodes: EmployeeNode[], parentId: string): EmployeeNode[] {
        for (const node of nodes) {
            if (node.id === parentId) {
                return (node.reports || []).map(child => ({
                    ...child,
                    reports: [],
                    expanded: false,
                    hasChildren: child.reports && child.reports.length > 0
                }));
            }
            if (node.reports) {
                const found = this.findChildrenInCache(node.reports, parentId);
                if (found.length) return found;
            }
        }
        return [];
    }

    private getUiType(level: string): 'manager' | 'lead' | 'employee' {
        const lower = level.toLowerCase();
        if (lower.includes('executive') || lower.includes('vp')) return 'manager';
        if (lower.includes('manager')) return 'lead';
        return 'employee';
    }

    generateLargeData(totalDepth: number = 4, childrenPerNode: number = 4): any[] {
        let idCounter = 1;

        const createNode = (depth: number, rolePrefix: string): any => {
            const id = `e${idCounter++}`;
            // Randomly decide if this node is "You" (just for testing visuals)
            const isMe = id === 'e50'; // Make the 50th employee "You"

            const node: any = {
                Employee_ID: id,
                Legal_Name: `Employee ${id} (${rolePrefix})`,
                Business_Title: `${rolePrefix} ${id}`,
                Management_Level: this.getLevelName(depth),
                Photo_URL: '', // Keep empty or add placeholder
                is_Logged_In_User: isMe,
                workers: []
            };

            // Stop recursion if we hit max depth
            if (depth < totalDepth) {
                for (let i = 0; i < childrenPerNode; i++) {
                    const nextRole = this.getNextRole(depth);
                    node.workers.push(createNode(depth + 1, nextRole));
                }
            }

            return node;
        };

        // Start with 1 CEO
        return [createNode(0, 'CEO')];
    }

    private getLevelName(depth: number): string {
        if (depth === 0) return 'Executive';
        if (depth === 1) return 'Director';
        if (depth === 2) return 'Manager';
        return 'Individual Contributor';
    }

    private getNextRole(depth: number): string {
        if (depth === 0) return 'VP';
        if (depth === 1) return 'Director';
        if (depth === 2) return 'Manager';
        return 'Engineer';
    }
}