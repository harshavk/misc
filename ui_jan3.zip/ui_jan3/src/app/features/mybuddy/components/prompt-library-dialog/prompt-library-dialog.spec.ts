import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PromptLibraryDialog } from './prompt-library-dialog';

describe('PromptLibraryDialog', () => {
  let component: PromptLibraryDialog;
  let fixture: ComponentFixture<PromptLibraryDialog>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [PromptLibraryDialog]
    })
    .compileComponents();

    fixture = TestBed.createComponent(PromptLibraryDialog);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
