import { Component, Input, Output, EventEmitter, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatTabsModule } from '@angular/material/tabs';
import { MatChipsModule } from '@angular/material/chips';

import { Employee } from '../../../../core/models/employee';

@Component({
  selector: 'app-employee-profile',
  standalone: true,
  imports: [CommonModule, MatButtonModule, MatIconModule, MatTabsModule, MatChipsModule],
  templateUrl: './employee-profile.html',
  styleUrls: ['./employee-profile.css']
})
export class EmployeeProfileComponent implements OnChanges {
  // ✅ Input is strictly Employee
  @Input() employee: Employee | null = null;
  @Output() close = new EventEmitter<void>();

  // Extended details for UI display
  extendedData: any = {};

  ngOnChanges(changes: SimpleChanges) {
    if (changes['employee'] && this.employee) {
      this.enrichEmployeeData(this.employee);
    }
  }

  getInitials(name: string): string {
    return name ? name.split(' ').map(n => n[0]).slice(0, 2).join('').toUpperCase() : '';
  }

  getRoleColor(role: string): string {
    const r = (role || '').toLowerCase();
    if (r.includes('director') || r.includes('vp')) return 'red';
    if (r.includes('manager') || r.includes('lead')) return 'amber';
    return 'blue';
  }

  // ✅ Renamed & Updated Type: Uses real data from Employee model
  private enrichEmployeeData(emp: Employee) {
    const isDev = emp.role.toLowerCase().includes('dev') || emp.role.toLowerCase().includes('engineer');

    this.extendedData = {
      // 1. Use REAL Data if available
      email: emp.email || 'N/A',
      location: emp.location || 'Remote',
      joined: emp.startDate ? `Joined ${new Date(emp.startDate).toLocaleDateString()}` : 'Joined recently',

      // 2. Mock specific UI fields (since they aren't in the DB model yet)
      timezone: 'GMT-5 (EST)',
      localTime: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' }),
      skills: isDev ? ['Angular', 'TypeScript', '.NET Core', 'Azure'] : ['Product Strategy', 'Jira', 'Roadmapping', 'Agile'],
      interests: ['Hiking', 'Coffee', 'Sci-Fi Novels'],
      availability: 'Available'
    };
  }

  onClose() {
    this.close.emit();
  }
}