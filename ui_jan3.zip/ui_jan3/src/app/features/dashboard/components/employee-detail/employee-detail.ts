import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy, signal, inject, OnInit, computed } from '@angular/core';
import { CommonModule } from '@angular/common';

// Models & Services
import { Employee } from '@core/models/employee';
import { AuthService } from '@core/services/auth.service'; // ✅ Import Auth
import { TeamScheduleService } from '@core/services/team-schedule.service'; // ✅ Import Schedule Service

// Material Imports
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { BuddyAccessDialog } from '../buddy-access-dialog/buddy-access-dialog';

type TabType = 'pre' | 'first3' | 'week1';

@Component({
  selector: 'app-employee-detail',
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatSnackBarModule,
    MatButtonModule,
    MatIconModule,
    MatDividerModule,
    MatProgressBarModule,
    MatTooltipModule
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './employee-detail.html',
  styleUrls: ['./employee-detail.css']
})
export class EmployeeDetailComponent implements OnInit {
  // Inputs / Outputs
  @Input({ required: true }) employee!: Employee;
  @Input() isManager = false;

  private dialog = inject(MatDialog);
  private snackBar = inject(MatSnackBar);
  private auth = inject(AuthService); // ✅ Inject Auth
  private scheduleService = inject(TeamScheduleService); // ✅ Inject Schedule Service

  @Output() close = new EventEmitter<void>();
  @Output() action = new EventEmitter<string>();

  // State
  readonly activeTab = signal<TabType>('pre');
  readonly upcomingEvents = signal<any[]>([]); // Store events here

  // ✅ Computed: Check if the viewed profile is the logged-in user
  readonly isOwnProfile = computed(() => {
    const currentUser = this.auth.currentUser();
    return currentUser?.id === this.employee?.id;
  });

  ngOnInit() {
    // If looking at myself, load my events
    if (this.isOwnProfile()) {
      this.loadMyEvents();
    }
  }

  loadMyEvents() {
    const events = this.scheduleService.getMyEvents();
    this.upcomingEvents.set(events);
  }

  projectAccessList = [
    { id: 1, tool: 'GitLab - Project X Repo', status: 'Pending' },
    { id: 2, tool: 'Jira - Board X', status: 'Pending' },
    { id: 3, tool: 'AWS - Dev Environment', status: 'Granted' }
  ];

  get pendingAccessCount() {
    return this.projectAccessList.filter(a => a.status === 'Pending').length;
  }

  openAccessDialog() {
    const dialogRef = this.dialog.open(BuddyAccessDialog, {
      width: '550px',
      data: { employeeId: this.employee.id }
    });

    dialogRef.afterClosed().subscribe(result => {
      if (result) {
        this.showNotification('Ally prompt copied to clipboard!');
      }
    });
  }

  private showNotification(message: string) {
    this.snackBar.open(message, 'Close', { duration: 4000 });
  }

  onClose(): void { this.close.emit(); }
  onAction(type: string): void { this.action.emit(type); }
  setTab(tab: TabType): void { this.activeTab.set(tab); }
}