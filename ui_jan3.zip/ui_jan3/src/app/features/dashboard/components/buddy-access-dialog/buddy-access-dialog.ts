import { Component, Inject, OnInit, ChangeDetectorRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { FormsModule } from '@angular/forms';
import { ClipboardModule } from '@angular/cdk/clipboard';

import { DashboardService } from '../../../../core/services/dashboard.service';
import { AccessRequest } from '../../../../core/models/employee';

@Component({
  selector: 'app-buddy-access-dialog',
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatButtonModule,
    MatCheckboxModule,
    MatIconModule,
    MatProgressSpinnerModule,
    FormsModule,
    ClipboardModule
  ],
  templateUrl: './buddy-access-dialog.html',
  styleUrls: ['./buddy-access-dialog.css']
})
export class BuddyAccessDialog implements OnInit {
  loading = true;
  errorMsg = '';

  buddyName = '';
  projectName = '';
  missingTools: { req: AccessRequest, selected: boolean }[] = [];
  allyString = '';

  constructor(
    public dialogRef: MatDialogRef<BuddyAccessDialog>,
    @Inject(MAT_DIALOG_DATA) public data: { employeeId: string },
    private dashboardService: DashboardService,
    private cdr: ChangeDetectorRef
  ) { }

  ngOnInit() {
    this.dashboardService.getBuddyGapAnalysis(this.data.employeeId).subscribe({
      next: (res) => {
        this.buddyName = res.buddy.name;
        this.projectName = res.user.project || 'Unknown Project';

        // Map data to UI model
        this.missingTools = res.missingTools.map((t: AccessRequest) => ({
          req: t,
          selected: true
        }));

        this.updatePrompt();
        this.loading = false;
        this.cdr.detectChanges(); // Fix NG0100 error
      },
      error: (err) => {
        console.error(err);
        this.errorMsg = err.message || "Could not find buddy information.";
        this.loading = false;
        this.cdr.detectChanges();
      }
    });
  }

  updatePrompt() {
    const selected = this.missingTools
      .filter(x => x.selected)
      .map(x => x.req.tool);

    if (selected.length === 0) {
      this.allyString = "";
      return;
    }

    this.allyString = `Hi Ally,
I am working on Project "${this.projectName}".
Please grant me the same access rights as my buddy, ${this.buddyName}.

Required Tools:
${selected.map(s => `• ${s}`).join('\n')}

Ref: Onboarding Mirroring`;
  }

  closeWithSuccess() {
    this.dialogRef.close(this.allyString);
  }
}