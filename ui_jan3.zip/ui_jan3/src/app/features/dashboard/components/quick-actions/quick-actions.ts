import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';

// Models
import { NotificationItem } from '@core/services/index';

// Material Imports
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';

@Component({
  selector: 'app-quick-actions',
  standalone: true,
  imports: [
    CommonModule,
    MatButtonModule,
    MatIconModule,
    MatDividerModule
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './quick-actions.html',
  styleUrls: ['./quick-actions.css']
})
export class QuickActionsComponent {
  @Input() notifications: NotificationItem[] = [];
  @Input() isManager = false;

  @Output() actionTrigger = new EventEmitter<string>();
  @Output() clickNotification = new EventEmitter<string>();

  onAction(actionType: string): void {
    this.actionTrigger.emit(actionType);
  }

  onNotificationClick(user: string): void {
    this.clickNotification.emit(user);
  }
}