import { Component, Inject, OnInit, inject, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef, MatDialogModule } from '@angular/material/dialog';
import { MatButtonModule } from '@angular/material/button';
import { MatSelectModule } from '@angular/material/select';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatDatepickerModule } from '@angular/material/datepicker';
import { provideNativeDateAdapter } from '@angular/material/core';

import { ReferenceService } from '@core/services/reference.service';
import { TeamScheduleService, CalendarEvent } from '@core/services/team-schedule.service';
import { AuthApiService } from '@core/services/auth-api.service';

// ✅ Match your JSON structure
interface Buddy {
  id: string;
  name: string;
  role: string;
}

export interface ActionDialogData {
  actionType: 'buddy' | 'access' | 'equipment' | 'meeting' | 'cloud' | 'team-intro';
  employeeName: string;
  employeeId: string;
  buddyName?: string;
}

@Component({
  selector: 'app-action-dialog',
  standalone: true,
  imports: [
    CommonModule, FormsModule, MatDialogModule, MatButtonModule,
    MatSelectModule, MatCheckboxModule, MatInputModule, MatFormFieldModule,
    MatIconModule, MatDatepickerModule
  ],
  providers: [provideNativeDateAdapter()],
  templateUrl: './action-dialog.html',
  styleUrls: ['./action-dialog.css']
})
export class ActionDialogComponent implements OnInit {
  private refService = inject(ReferenceService);
  private scheduleService = inject(TeamScheduleService);
  private authService = inject(AuthApiService);

  // State
  selectedBuddy = ''; // We will store the Buddy's NAME here for the prompt
  selectedEquipment = new Set<string>();
  selectedAccess: string[] = [];

  // Invite State
  inviteType: 'meeting' | 'team-intro' | 'buddy' = 'meeting';
  selectedDate: Date | null = new Date();
  startTime: string = '10:00';
  endTime: string = '10:30';
  emailSubject = '';
  emailBody = '';

  constructor(
    @Inject(MAT_DIALOG_DATA) public data: ActionDialogData,
    private dialogRef: MatDialogRef<ActionDialogComponent>
  ) { }

  ngOnInit() {
    this.refService.loadReferences();

    if (this.data.buddyName) {
      this.selectedBuddy = this.data.buddyName;
    }

    if (this.data.actionType === 'team-intro') this.inviteType = 'team-intro';
    else this.inviteType = 'meeting';

    this.applyTemplate();
  }

  get isCalendarAction(): boolean {
    return this.data.actionType === 'meeting' || this.data.actionType === 'team-intro';
  }

  // ✅ Typed Getter for Buddies
  get buddies(): Buddy[] {
    return (this.refService.data()?.buddies as unknown as Buddy[]) || [];
  }

  get equipmentList() { return this.refService.data()?.equipment || []; }
  get accessRoles() { return this.refService.data()?.accessRoles || []; }

  applyTemplate() {
    if (!this.isCalendarAction) return;

    const user = this.authService.currentUser();
    const managerName = user ? user.name : 'Manager';
    const firstName = this.data.employeeName.split(' ')[0];
    const signature = `Best,\n${managerName}`;

    switch (this.inviteType) {
      case 'team-intro':
        this.emailSubject = 'Welcome Lunch: Meet the Team!';
        this.emailBody = `Hi ${firstName},\n\nThe whole team is excited to welcome you! We'd like to take you out for a welcome lunch to get to know everyone.\n\nLooking forward to it,\n${managerName}`;
        this.startTime = '12:00';
        this.endTime = '13:00';
        break;

      // ✅ NEW CASE: Buddy Intro Email (Manual Send)
      case 'buddy':
        const buddy = this.selectedBuddy || '[Buddy Name]';
        this.emailSubject = `Intro: ${firstName} <> ${buddy}`;
        this.emailBody = `Hi ${firstName},\n\nI'd like to introduce you to your onboarding buddy, ${buddy} (cc'd here).\n\nThey will be your go-to person for any questions, navigating the office, or just grabbing coffee during your first few weeks.\n\nLet's use this time for a quick intro.\n\n${signature}`;
        this.startTime = '10:00';
        this.endTime = '10:30';
        break;

      case 'meeting':
      default:
        this.emailSubject = 'Weekly 1:1 Check-in';
        this.emailBody = `Hi ${firstName},\n\nI'd like to schedule this time for our regular 1:1 check-in to discuss your progress and any blockers.\n\n${signature}`;
        this.startTime = '10:00';
        this.endTime = '10:30';
        break;
    }
  }

  generatePrompt(): string {
    if (this.isCalendarAction) return '';
    const name = this.data.employeeName;

    // ✅ Uses selectedBuddy string (Name)
    if (this.data.actionType === 'buddy') {
      return `Assign ${this.selectedBuddy || '[Buddy]'} as a buddy for ${name} and draft an intro email.`;
    }
    if (this.data.actionType === 'equipment') return `Order equipment for ${name}: ${Array.from(this.selectedEquipment).join(', ')}.`;
    if (this.data.actionType === 'access') return `Request access to ${this.selectedAccess.join(', ')} for ${name}.`;

    return `Help with ${this.data.actionType} for ${name}`;
  }

  submit() {
    if (this.isCalendarAction) {
      let type: '1:1' | 'team' | 'buddy' = '1:1';
      if (this.inviteType === 'team-intro') type = 'team';
      if (this.inviteType === 'buddy') type = 'buddy';

      const eventData: Partial<CalendarEvent> = {
        title: this.emailSubject,
        employeeName: this.data.employeeName,
        employeeId: this.data.employeeId,
        date: this.selectedDate?.toISOString(),
        startTime: this.startTime,
        endTime: this.endTime,
        type: type
      };
      this.dialogRef.close({ eventData });
    } else {
      this.dialogRef.close({ prompt: this.generatePrompt() });
    }
  }

  // Icons & Titles (Unchanged)
  getIcon(): string {
    if (this.data.actionType === 'team-intro') return 'groups';
    if (this.data.actionType === 'buddy') return 'person_add';
    const icons: Record<string, string> = {
      equipment: 'laptop_mac', access: 'cloud_queue', cloud: 'cloud_queue', meeting: 'event'
    };
    return icons[this.data.actionType] || 'bolt';
  }

  getTitle(): string {
    const titles: Record<string, string> = {
      buddy: 'Assign Buddy', equipment: 'Order Equipment', access: 'Request Access',
      meeting: 'Schedule Invite', 'team-intro': 'Schedule Invite'
    };
    return titles[this.data.actionType] || 'Quick Action';
  }

  getIconColor(): string { return ''; }
  toggleEquipment(item: string) {
    if (this.selectedEquipment.has(item)) this.selectedEquipment.delete(item);
    else this.selectedEquipment.add(item);
  }
  readonly recentHistory = computed(() => []);
}