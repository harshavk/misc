import { Component, inject, OnInit, signal, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { MatTreeModule, MatTreeNestedDataSource } from '@angular/material/tree';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { NestedTreeControl } from '@angular/cdk/tree';
import { EmployeeProfileComponent } from '../mybuddy/components/employee-profile/employee-profile';
import { MatButtonToggleModule } from '@angular/material/button-toggle';

// ✅ Import Service and Model
import { OrgChartService, EmployeeNode } from '../../core/services/org-chart.service';
import { DashboardService } from '../../core/services/dashboard.service';
import { Employee } from '../../core/models/employee';

@Component({
  selector: 'app-org-chart',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatTreeModule,
    MatIconModule,
    MatButtonModule,
    MatProgressSpinnerModule,
    EmployeeProfileComponent,
    MatButtonToggleModule
  ],
  templateUrl: './org-chart.html',
  styleUrls: ['./org-chart.css']
})
export class OrgChart implements OnInit {
  private service = inject(OrgChartService);
  private dashboardService = inject(DashboardService);

  searchQuery = '';
  activePathIds = new Set<string>();

  @ViewChild('scrollContainer') scrollContainer!: ElementRef;

  treeControl = new NestedTreeControl<EmployeeNode>(node => node.reports);
  dataSource = new MatTreeNestedDataSource<EmployeeNode>();

  isLoading = signal(true);
  scale = signal(1);
  selectedNodeId: string | null = null;
  selectedEmployee = signal<Employee | null>(null);
  viewMode = signal<'FULL_ORG' | 'MY_TEAM'>('MY_TEAM'); // Default to Team View

  // Dragging State
  isDragging = false;
  startX = 0; scrollLeft = 0; scrollTop = 0; startY = 0;

  ngOnInit() {
    this.loadInitialTree();
  }

  // ✅ 1. INITIAL LOAD: Fetch from Service (Mock or Real)
  loadInitialTree() {
    this.isLoading.set(true);

    this.service.getInitialTree(this.viewMode()).subscribe({
      next: (nodes) => {
        this.dataSource.data = nodes;
        this.treeControl.dataNodes = nodes;

        // Auto-expand the path to the user (handled by service 'expanded' flag)
        if (this.viewMode() === 'MY_TEAM') {
          this.treeControl.expandAll();
        } else {
          this.expandPredefinedPath(nodes);
        }


        this.isLoading.set(false);

        // Center view on the current user after render
        setTimeout(() => this.centerOnUser(), 500);
      },
      error: (err) => {
        console.error('Failed to load tree', err);
        this.isLoading.set(false);
      }
    });
  }

  toggleViewMode() {
    const newMode = this.viewMode() === 'FULL_ORG' ? 'MY_TEAM' : 'FULL_ORG';
    this.viewMode.set(newMode);
    this.loadInitialTree(); // Reload data with new filter
  }

  onViewChange(mode: 'MY_TEAM' | 'FULL_ORG') {
    if (this.viewMode() !== mode) {
      this.viewMode.set(mode);
      this.loadInitialTree(); // Reload tree with new mode
    }
  }

  // Helper to expand nodes marked as 'expanded: true' by the service
  private expandPredefinedPath(nodes: EmployeeNode[]) {
    for (const node of nodes) {
      if (node.expanded) {
        this.treeControl.expand(node);
        if (node.reports) {
          this.expandPredefinedPath(node.reports);
        }
      }
    }
  }

  // ✅ 2. LAZY LOADING & TOGGLE
  toggleNode(node: EmployeeNode) {
    if (this.treeControl.isExpanded(node)) {
      this.treeControl.collapse(node);
    } else {
      // Lazy Load Condition: Node has children flag TRUE, but reports array is EMPTY
      if (node.hasChildren && (!node.reports || node.reports.length === 0)) {

        node.isLoading = true; // Shows spinner in UI

        this.service.getChildren(node.id).subscribe({
          next: (children) => {
            node.reports = children;
            node.isLoading = false;

            // ⚠️ Force MatTree update by refreshing data reference
            const currentData = this.dataSource.data;
            this.dataSource.data = [];
            this.dataSource.data = currentData;

            this.treeControl.expand(node);
          },
          error: (err) => {
            console.error('Error loading children', err);
            node.isLoading = false;
          }
        });

      } else {
        // Data already exists, just open it
        this.treeControl.expand(node);
      }
    }
  }

  hasChild = (_: number, node: EmployeeNode) => node.hasChildren ?? false;

  // --- Interaction Logic ---
  onNodeClick(node: EmployeeNode) {
    this.selectedNodeId = node.name; // Ideally use ID, but name is used for class logic
    this.activePathIds.clear();
    this.findPathToNode(this.dataSource.data, node.id, []);

    // Fetch full profile details (Simulated or Real)
    this.dashboardService.getEmployeeById(node.id).subscribe({
      next: (fullEmployee) => {
        if (fullEmployee) {
          this.selectedEmployee.set(fullEmployee);
        } else {
          this.setFallbackEmployee(node);
        }
      },
      error: () => this.setFallbackEmployee(node)
    });
  }

  findPathToNode(nodes: EmployeeNode[], targetId: string, currentPath: string[]): boolean {
    for (const node of nodes) {
      // Push current node to path
      currentPath.push(node.id);

      if (node.id === targetId) {
        // FOUND IT! Save all IDs in the path to the Set
        currentPath.forEach(id => this.activePathIds.add(id));
        return true;
      }

      if (node.reports) {
        if (this.findPathToNode(node.reports, targetId, currentPath)) return true;
      }

      // Backtrack
      currentPath.pop();
    }
    return false;
  }

  private setFallbackEmployee(node: EmployeeNode) {
    this.selectedEmployee.set({
      id: node.id,
      name: node.name,
      role: node.role,
      avatar: node.img,
      initial: this.getInitials(node.name),
      email: `${node.name.replace(' ', '.').toLowerCase()}@company.com`,
      location: 'Unknown',

      // ✅ FIX: Use a valid status from your Interface (e.g., 'Unknown')
      status: 'Unknown',

      startDate: new Date().toISOString(),
      avatarColor: '#e0e7ff',
      progress: 0,
      laptopStatus: 'Unknown',
      benefitsStatus: 'Unknown',
      trainingProgress: 0,
      goalsSet: false,
      tasks: { preStart: [], firstThreeDays: [], weekOnePlus: [] }
    } as Employee);
  }

  closeProfile() {
    this.selectedEmployee.set(null);
    this.selectedNodeId = null;
    this.activePathIds.clear();
  }

  // --- Helpers ---
  getInitials(name: string): string {
    return name ? name.split(' ').map(n => n[0]).slice(0, 2).join('').toUpperCase() : '';
  }

  zoomIn() { this.scale.update(s => Math.min(s + 0.1, 1.5)); }
  zoomOut() { this.scale.update(s => Math.max(s - 0.1, 0.5)); }

  centerOnUser() {
    setTimeout(() => {
      const el = document.querySelector('.node-card.current-user');
      if (el) {
        el.scrollIntoView({
          behavior: 'smooth',
          block: 'center',
          inline: 'center'
        });
      }
    }, 100);
  }

  // --- Dragging Logic ---
  onMouseDown(e: MouseEvent) {
    if ((e.target as HTMLElement).closest('.node-card')) return;
    this.isDragging = true;
    this.startX = e.pageX - this.scrollContainer.nativeElement.offsetLeft;
    this.startY = e.pageY - this.scrollContainer.nativeElement.offsetTop;
    this.scrollLeft = this.scrollContainer.nativeElement.scrollLeft;
    this.scrollTop = this.scrollContainer.nativeElement.scrollTop;
    this.scrollContainer.nativeElement.style.cursor = 'grabbing';
  }

  onMouseUp() { this.isDragging = false; this.scrollContainer.nativeElement.style.cursor = 'grab'; }
  onMouseLeave() { this.isDragging = false; }

  onMouseMove(e: MouseEvent) {
    if (!this.isDragging) return;
    e.preventDefault();
    const x = e.pageX - this.scrollContainer.nativeElement.offsetLeft;
    const y = e.pageY - this.scrollContainer.nativeElement.offsetTop;
    this.scrollContainer.nativeElement.scrollLeft = this.scrollLeft - (x - this.startX);
    this.scrollContainer.nativeElement.scrollTop = this.scrollTop - (y - this.startY);
  }

  performSearch() {
    if (!this.searchQuery.trim()) return;

    const query = this.searchQuery.toLowerCase();
    // Search the full data source
    const foundNode = this.findNodeRecursive(this.dataSource.data, query);

    if (foundNode) {
      this.selectedNodeId = foundNode.name; // Highlight it

      // Expand the tree down to this node
      this.expandPathToNode(this.dataSource.data, foundNode);

      // Scroll to it
      setTimeout(() => this.scrollToNode(foundNode.name), 300);
    } else {
      console.log('Employee not found in visible tree.');
    }
  }

  private findNodeRecursive(nodes: EmployeeNode[], query: string): EmployeeNode | null {
    for (const node of nodes) {
      if (node.name.toLowerCase().includes(query)) {
        return node;
      }
      if (node.reports) {
        const found = this.findNodeRecursive(node.reports, query);
        if (found) return found;
      }
    }
    return null;
  }

  private expandPathToNode(nodes: EmployeeNode[], target: EmployeeNode): boolean {
    for (const node of nodes) {
      if (node === target) return true;

      if (node.reports) {
        const foundInChild = this.expandPathToNode(node.reports, target);
        if (foundInChild) {
          this.treeControl.expand(node); // Expand parent
          return true;
        }
      }
    }
    return false;
  }

  private scrollToNode(nodeName: string) {
    // Find all card elements
    const cards = document.querySelectorAll('.node-card');
    let targetEl: HTMLElement | null = null;

    // Look for the one with the matching name
    cards.forEach((el: any) => {
      if (el.innerText.includes(nodeName)) targetEl = el;
    });

    if (targetEl) {
      (targetEl as HTMLElement).scrollIntoView({
        behavior: 'smooth',
        block: 'center',
        inline: 'center'
      });
    }
  }
}