import { Component, inject, OnInit, signal } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

// Material Imports
import { MatCardModule } from '@angular/material/card';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { MatSliderModule } from '@angular/material/slider';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressSpinnerModule } from "@angular/material/progress-spinner";

// Core Services
import { SettingsService, SystemSettings } from '../../../core/services/settings.service';

@Component({
  selector: 'app-system-settings',
  standalone: true,
  imports: [
    CommonModule, FormsModule,
    MatCardModule, MatSlideToggleModule, MatSliderModule,
    MatFormFieldModule, MatInputModule, MatSelectModule,
    MatButtonModule, MatIconModule, MatSnackBarModule,
    MatProgressSpinnerModule
  ],
  templateUrl: './system-settings.html',
  styleUrls: ['./system-settings.css']
})
export class SystemSettingsComponent implements OnInit {
  private settingsService = inject(SettingsService);
  private snackBar = inject(MatSnackBar);

  // State
  settings = signal<SystemSettings | null>(null);
  isLoading = signal(true);
  isSaving = signal(false);

  ngOnInit() {
    this.loadSettings();
  }

  loadSettings() {
    this.isLoading.set(true);
    this.settingsService.getSettings().subscribe({
      next: (data) => {
        this.settings.set(data);
        this.isLoading.set(false);
      },
      error: () => this.isLoading.set(false)
    });
  }

  // ✅ Helper to update nested properties immutably (Required by your HTML)
  updateSetting(section: keyof SystemSettings, key: string, value: any) {
    this.settings.update(current => {
      if (!current) return null;
      return {
        ...current,
        [section]: {
          ...current[section],
          [key]: value
        }
      };
    });
  }

  saveSettings() {
    const currentSettings = this.settings();
    if (!currentSettings) return;

    this.isSaving.set(true);

    this.settingsService.saveSettings(currentSettings).subscribe({
      next: () => {
        this.isSaving.set(false);
        this.showNotification('System settings updated successfully');
      },
      error: () => {
        this.isSaving.set(false);
        this.showNotification('Failed to save settings', 'error');
      }
    });
  }

  formatTempLabel(value: number): string {
    return `${value}`;
  }

  private showNotification(message: string, type: 'success' | 'error' = 'success') {
    this.snackBar.open(message, 'Close', {
      duration: 3000,
      horizontalPosition: 'center',
      verticalPosition: 'bottom',
      panelClass: type === 'success' ? ['success-snackbar'] : ['error-snackbar']
    });
  }
}