import { Component, OnInit, signal, computed, inject } from '@angular/core';
import { CommonModule, DatePipe } from '@angular/common';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';
import { MatChipsModule } from '@angular/material/chips';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatButtonToggleModule } from '@angular/material/button-toggle';

import { TeamScheduleService, CalendarEvent } from '@core/services/team-schedule.service';
import { AuthApiService } from '@core/services/auth-api.service';
import { Role } from '@core/models';

interface CalendarDay {
  date: Date;
  isToday: boolean;
  isCurrentMonth: boolean;
  events: CalendarEvent[];
}

@Component({
  selector: 'app-team-schedule',
  standalone: true,
  imports: [
    CommonModule, MatButtonModule, MatIconModule,
    MatCardModule, MatChipsModule, MatTooltipModule,
    MatButtonToggleModule
  ],
  providers: [DatePipe],
  templateUrl: './team-schedule-component.html',
  styleUrls: ['./team-schedule-component.css']
})
export class TeamScheduleComponent implements OnInit {
  private scheduleService = inject(TeamScheduleService);
  private authService = inject(AuthApiService);

  // Raw Store Data
  private allEvents = this.scheduleService.events;

  // ✅ 1. Filter Logic (The Core Change)
  // If Manager -> Return All. If Employee -> Return only theirs.
  readonly visibleEvents = computed(() => {
    const user = this.authService.currentUser();
    const all = this.allEvents();

    if (!user) return [];

    // Check if Manager (using Role enum or ID convention)
    const isManager = user.role === Role.Manager || user.id.startsWith('m');

    if (isManager) {
      return all; // Manager sees everything
    } else {
      // Employee sees only their own events
      return all.filter(e => e.employeeId === user.id);
    }
  });

  // State
  viewDate = signal(new Date());
  selectedDay = signal<CalendarDay | null>(null);
  viewMode = signal<'month' | 'week'>('month');

  // Header Label
  readonly periodLabel = computed(() => {
    const d = this.viewDate();
    const mode = this.viewMode();
    const pipe = new DatePipe('en-US');

    if (mode === 'month') {
      return pipe.transform(d, 'MMMM yyyy');
    } else {
      const start = new Date(d);
      start.setDate(d.getDate() - d.getDay());
      const end = new Date(start);
      end.setDate(start.getDate() + 6);
      return `${pipe.transform(start, 'MMM d')} - ${pipe.transform(end, 'MMM d, yyyy')}`;
    }
  });

  // Grid Computation
  readonly calendarGrid = computed(() => {
    const d = this.viewDate();
    const today = new Date();
    const days: CalendarDay[] = [];

    // ✅ Use the filtered list
    const sourceEvents = this.visibleEvents();

    // --- WEEK VIEW ---
    if (this.viewMode() === 'week') {
      const startOfWeek = new Date(d);
      startOfWeek.setDate(d.getDate() - d.getDay());

      for (let i = 0; i < 7; i++) {
        const current = new Date(startOfWeek);
        current.setDate(startOfWeek.getDate() + i);

        const dayEvents = sourceEvents.filter(e => this.isSameDate(e.date, current));

        days.push({
          date: current,
          isToday: this.isSameDate(today.toISOString(), current),
          isCurrentMonth: true,
          events: dayEvents
        });
      }
      return days;
    }

    // --- MONTH VIEW ---
    const year = d.getFullYear();
    const month = d.getMonth();
    const firstDay = new Date(year, month, 1);
    const lastDay = new Date(year, month + 1, 0);
    const daysInMonth = lastDay.getDate();
    const startDayOfWeek = firstDay.getDay();

    // Padding (Prev)
    for (let i = 0; i < startDayOfWeek; i++) {
      days.push({ date: new Date(year, month, -startDayOfWeek + i + 1), isToday: false, isCurrentMonth: false, events: [] });
    }

    // Days
    for (let i = 1; i <= daysInMonth; i++) {
      const current = new Date(year, month, i);
      days.push({
        date: current,
        isToday: this.isSameDate(today.toISOString(), current),
        isCurrentMonth: true,
        events: sourceEvents.filter(e => this.isSameDate(e.date, current))
      });
    }

    // Padding (Next)
    const remaining = 42 - days.length;
    for (let i = 1; i <= remaining; i++) {
      days.push({ date: new Date(year, month + 1, i), isToday: false, isCurrentMonth: false, events: [] });
    }

    return days;
  });

  ngOnInit() { }

  changePeriod(direction: number) {
    const d = new Date(this.viewDate());
    if (this.viewMode() === 'month') {
      d.setMonth(d.getMonth() + direction);
      d.setDate(1);
    } else {
      d.setDate(d.getDate() + (direction * 7));
    }
    this.viewDate.set(d);
    this.selectedDay.set(null);
  }

  resetToToday() {
    this.viewDate.set(new Date());
    this.selectedDay.set(null);
  }

  selectDay(day: CalendarDay) {
    this.selectedDay.set(day);
  }

  isSameDate(dateInput: string | Date, dateObj: Date): boolean {
    const d1 = typeof dateInput === 'string' ? new Date(dateInput) : dateInput;
    return d1.getDate() === dateObj.getDate() &&
      d1.getMonth() === dateObj.getMonth() &&
      d1.getFullYear() === dateObj.getFullYear();
  }

  getEventTypeColor(type: string): string {
    switch (type) {
      case 'onboarding': return 'var(--color-primary-blue, #3b82f6)';
      case 'team': return 'var(--color-primary-blue, #3b82f6)';
      case '1:1': return 'var(--color-warning, #f59e0b)';
      case 'buddy': return 'var(--color-purple, #8b5cf6)';
      case 'training': return '#ec4899';
      default: return '#64748b';
    }
  }
}