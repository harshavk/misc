using Common.DataAccess;
using Common.EntityFramework.Models;
using HRSCWinService.BusinessEntities;
using HRSCWinService.ServiceInterfaces;
using Microsoft.Extensions.Logging;

namespace HRSCWinService.Services;

public class FileImportIngestionService : IFileImportIngestionService
{
    private readonly IFileImportJobRepository _fileImportJobRepository;
    private readonly IDocumentImportsRepository _documentImportsRepository;
    private readonly IFileImportCsvReaderService _csvReaderService;
    private readonly ILogger<FileImportIngestionService> _logger;
    private const int BatchSize = 1000;

    public FileImportIngestionService(
          IFileImportJobRepository fileImportJobRepository
        , IDocumentImportsRepository documentImportsRepository
        , IFileImportCsvReaderService csvReaderService
        , ILogger<FileImportIngestionService> logger)
    {
        _fileImportJobRepository  = fileImportJobRepository;
        _documentImportsRepository = documentImportsRepository;
        _csvReaderService         = csvReaderService;
        _logger                   = logger;
    }

    public async Task<int> IngestValidRowsAsync(
        FileImportJob job,
        CancellationToken cancellationToken)
    {
        HashSet<int> errorRowNumbers =
            await _fileImportJobRepository.GetErrorRowNumbersByJobIdAsync(job.Id);

        _logger.LogInformation(
            "FileImportIngestionService job {JobId} — "
          + "{ErrorCount} error rows will be skipped.",
            job.Id, errorRowNumbers.Count);

        int insertedCount = await ProcessRowsAsync(
            job, errorRowNumbers, cancellationToken);

        return insertedCount;
    }

    // ── private ───────────────────────────────────────────────────────────

    private async Task<int> ProcessRowsAsync(
        FileImportJob job,
        HashSet<int> errorRowNumbers,
        CancellationToken cancellationToken)
    {
        List<DocumentImports> batch = [];
        int insertedCount = 0;

        await foreach (FileImportCsvRow row
                       in _csvReaderService
                           .ReadRowsAsync(job.SavedFilePath, job.CsvFormat)
                           .WithCancellation(cancellationToken))
        {
            if (errorRowNumbers.Contains(row.RowNumber))
            {
                continue;
            }

            batch.Add(BuildDocumentImport(row));

            if (batch.Count >= BatchSize)
            {
                await FlushBatchAsync(batch);
                insertedCount += BatchSize;
            }
        }

        if (batch.Count > 0)
        {
            await FlushBatchAsync(batch);
            insertedCount += batch.Count;
        }

        return insertedCount;
    }

    private static DocumentImports BuildDocumentImport(FileImportCsvRow row)
    {
        return new DocumentImports
        {
            EmpId          = row.EmpId,
            NationalId     = row.NationalId,
            NationalIdType = row.NationalIdType,
            FileName       = row.FileName,
            EffectiveDate  = ParseEffectiveDate(row.EffectiveDate),
            Barcode        = row.Barcode,
            Department     = row.Dept,
            Country        = row.Country,
            CisiveCaseId   = row.CaseId,
            Processed      = "N",
            CreateDate     = DateTime.UtcNow,
            StatusMessage  = null,
            Payload        = null,
            RequestId      = null,
            RequestDate    = null
        };
    }

    private static DateTime? ParseEffectiveDate(string? effectiveDate)
    {
        if (string.IsNullOrWhiteSpace(effectiveDate))
        {
            return null;
        }

        if (DateTime.TryParse(effectiveDate, out DateTime parsed))
        {
            return parsed;
        }

        return null;
    }

    private async Task FlushBatchAsync(List<DocumentImports> batch)
    {
        await _documentImportsRepository.BulkInsertAsync(batch);
        batch.Clear();
    }
}
