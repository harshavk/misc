using Common.EntityFramework.Models;

namespace HRSCWinService.ServiceInterfaces;

public interface IFileImportIngestionService
{
    Task<int> IngestValidRowsAsync(
        FileImportJob job,
        CancellationToken cancellationToken);
}
