using Common.DataAccess;
using Common.EntityFramework.Models;
using Common.Enums;
using HRSCWinService.ServiceInterfaces;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;

namespace HRSCWinService.BusinessLogic;

public class FileImportIngestionJob : BackgroundService
{
    private readonly ILogger<FileImportIngestionJob> _logger;
    private readonly IServiceProvider _serviceProvider;
    private readonly TimeSpan _interval = TimeSpan.FromMinutes(1);

    public FileImportIngestionJob(
          ILogger<FileImportIngestionJob> logger
        , IServiceProvider serviceProvider)
    {
        _logger          = logger;
        _serviceProvider = serviceProvider;
    }

    protected override async Task ExecuteAsync(CancellationToken stoppingToken)
    {
        _logger.LogInformation("FileImportIngestionJob started.");

        using PeriodicTimer timer = new(_interval);

        while (await timer.WaitForNextTickAsync(stoppingToken))
        {
            await RunCycleAsync(stoppingToken);
        }

        _logger.LogInformation("FileImportIngestionJob stopped.");
    }

    // ── cycle ─────────────────────────────────────────────────────────────

    private async Task RunCycleAsync(CancellationToken stoppingToken)
    {
        try
        {
            using IServiceScope scope = _serviceProvider.CreateScope();
            await ProcessPendingJobAsync(scope, stoppingToken);
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "FileImportIngestionJob cycle failed.");
        }
    }

    private async Task ProcessPendingJobAsync(
        IServiceScope scope,
        CancellationToken stoppingToken)
    {
        IFileImportJobRepository repo = scope.ServiceProvider
            .GetRequiredService<IFileImportJobRepository>();

        FileImportJob? job = await repo.GetPendingIngestionJobAsync();

        if (job is null)
        {
            return;
        }

        _logger.LogInformation(
            "FileImportIngestionJob processing job {JobId} — {FileName}.",
            job.Id, job.FileName);

        await ProcessSingleJobAsync(scope, repo, job, stoppingToken);
    }

    private async Task ProcessSingleJobAsync(
        IServiceScope scope,
        IFileImportJobRepository repo,
        FileImportJob job,
        CancellationToken stoppingToken)
    {
        try
        {
            await IngestJobAsync(scope, repo, job, stoppingToken);
        }
        catch (Exception ex)
        {
            await HandleJobFailureAsync(repo, job, ex);
        }
    }

    private async Task IngestJobAsync(
        IServiceScope scope,
        IFileImportJobRepository repo,
        FileImportJob job,
        CancellationToken stoppingToken)
    {
        IFileImportIngestionService ingestionService = scope.ServiceProvider
            .GetRequiredService<IFileImportIngestionService>();

        int insertedCount = await ingestionService.IngestValidRowsAsync(
            job, stoppingToken);

        await FinalizeJobAsync(repo, job, insertedCount);
    }

    private async Task FinalizeJobAsync(
        IFileImportJobRepository repo,
        FileImportJob job,
        int insertedCount)
    {
        await repo.UpdateIngestionAsync(job.Id, job.ProcessedBy ?? string.Empty);

        _logger.LogInformation(
            "FileImportIngestionJob job {JobId} complete. "
          + "{InsertedCount} records inserted into DocumentImports.",
            job.Id, insertedCount);
    }

    private async Task HandleJobFailureAsync(
        IFileImportJobRepository repo,
        FileImportJob job,
        Exception ex)
    {
        _logger.LogError(
            ex,
            "FileImportIngestionJob job {JobId} failed during ingestion.",
            job.Id);

        await repo.UpdateJobFailedAsync(
            job.Id,
            $"Ingestion failed: {ex.Message}");
    }
}
