// ─────────────────────────────────────────────────────────────────────────────
// ADD this method to your EXISTING IDocumentImportsRepository interface
// in Common/DataAccess/IDocumentImportsRepository.cs
// ─────────────────────────────────────────────────────────────────────────────

/// <summary>
/// Bulk inserts a batch of DocumentImport records.
/// Called by FileImportIngestionService in batches of 1000 rows.
/// </summary>
Task BulkInsertAsync(IEnumerable<DocumentImports> records);

// ─────────────────────────────────────────────────────────────────────────────
// ADD this implementation to your EXISTING DocumentUploadsRepository.cs
// in Common/DataAccess/DocumentUploadsRepository.cs
// ─────────────────────────────────────────────────────────────────────────────

public async Task BulkInsertAsync(IEnumerable<DocumentImports> records)
{
    await _dbContext.DocumentImports.AddRangeAsync(records);
    await _dbContext.SaveChangesAsync();
}
