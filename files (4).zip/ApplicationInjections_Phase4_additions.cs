// ─────────────────────────────────────────────────────────────────────────────
// ADD to HRSCWinService/Injections/ApplicationInjections.cs
// alongside the Phase 3 registrations already added
// ─────────────────────────────────────────────────────────────────────────────

// Ingestion service
services.AddScoped<IFileImportIngestionService, FileImportIngestionService>();

// Ingestion background job
services.AddHostedService<FileImportIngestionJob>();

// ─────────────────────────────────────────────────────────────────────────────
// COMPLETE Phase 3 + Phase 4 registrations in one block for reference:
// ─────────────────────────────────────────────────────────────────────────────

// Config
services.AddOptions<FileImportFormatConfig>()
    .Bind(configuration.GetSection(nameof(FileImportFormatConfig)));

// Repositories
services.AddScoped<IFileImportJobRepository, FileImportJobRepository>();

// Services
services.AddScoped<IFileImportCsvReaderService, FileImportCsvReaderService>();
services.AddScoped<IFileImportValidator, FileImportValidator>();
services.AddScoped<IFileImportIngestionService, FileImportIngestionService>();

// Background jobs
services.AddHostedService<FileImportValidationJob>();
services.AddHostedService<FileImportIngestionJob>();
