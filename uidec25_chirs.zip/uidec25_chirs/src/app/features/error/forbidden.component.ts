import { Component, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';

// ✅ DIRECT MATERIAL IMPORTS
import { MatCardModule } from '@angular/material/card';
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';

@Component({
  standalone: true,
  selector: 'app-forbidden',
  imports: [
    CommonModule,
    RouterLink,
    MatCardModule,
    MatButtonModule,
    MatIconModule
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <div class="error-container">
      <mat-card class="error-card">
        <mat-card-content class="content">
          <mat-icon class="error-icon" color="warn">error_outline</mat-icon>
          <h1>403</h1>
          <h2>Access Denied</h2>
          <p>You don't have permission to access this page.</p>
          
          <button mat-flat-button color="primary" routerLink="/dashboard">
            <mat-icon>home</mat-icon> Go to Dashboard
          </button>
        </mat-card-content>
      </mat-card>
    </div>
  `,
  styles: [`
    .error-container {
      height: 100%;
      display: flex;
      align-items: center;
      justify-content: center;
      background-color: var(--app-bg);
      padding: 20px;
      box-sizing: border-box;
    }
    .error-card {
      max-width: 400px;
      width: 100%;
      text-align: center;
      padding: 32px 16px;
      border-radius: 16px;
      box-shadow: 0 4px 20px rgba(0,0,0,0.1);
      background-color: var(--panel-bg);
      color: var(--text-main);
    }
    .content {
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 16px;
    }
    .error-icon {
      font-size: 64px;
      height: 64px;
      width: 64px;
      margin-bottom: 8px;
    }
    h1 {
      margin: 0;
      font-size: 3rem;
      font-weight: 800;
      color: var(--text-main);
      line-height: 1;
    }
    h2 {
      margin: 0;
      font-size: 1.5rem;
      color: var(--text-muted);
    }
    p {
      color: var(--text-muted);
      margin-bottom: 16px;
    }
  `]
})
export class ForbiddenComponent { }