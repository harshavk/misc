import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';

// Models
import { Employee } from '@core/models/index'; // Updated Alias

// Material Imports
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatDialog, MatDialogModule } from '@angular/material/dialog';
import { BuddyAccessDialog } from '../buddy-access-dialog/buddy-access-dialog';

type TabType = 'pre' | 'first3' | 'week1';

@Component({
  selector: 'app-employee-detail',
  standalone: true,
  imports: [
    CommonModule,
    MatDialogModule,
    MatSnackBarModule,
    MatButtonModule,
    MatIconModule,
    MatDividerModule,
    MatProgressBarModule,
    MatTooltipModule
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './employee-detail.html',
  styleUrls: ['./employee-detail.css']
})
export class EmployeeDetailComponent {
  // Inputs / Outputs
  @Input({ required: true }) employee!: Employee; // Required input (Angular 16+)
  @Input() isManager = false;

  private dialog = inject(MatDialog);
  private snackBar = inject(MatSnackBar);

  @Output() close = new EventEmitter<void>();
  @Output() action = new EventEmitter<string>();

  // State
  readonly activeTab = signal<TabType>('pre');

  projectAccessList = [
    { id: 1, tool: 'GitLab - Project X Repo', status: 'Pending' },
    { id: 2, tool: 'Jira - Board X', status: 'Pending' },
    { id: 3, tool: 'AWS - Dev Environment', status: 'Granted' }
  ];

  get pendingAccessCount() {
    return this.projectAccessList.filter(a => a.status === 'Pending').length;
  }
  // ✅ The Implementation
  openAccessDialog() {
    console.log(`Opening Access Dialog for ${this.employee.name} (${this.employee.id})...`);

    const dialogRef = this.dialog.open(BuddyAccessDialog, {
      width: '550px',
      disableClose: false,
      autoFocus: false, // Prevents auto-focusing the first button
      data: { employeeId: this.employee.id }
    });

    dialogRef.afterClosed().subscribe(result => {
      // 'result' contains the Ally string if they clicked "Copy"
      if (result) {
        this.showNotification('Ally prompt copied to clipboard! Paste it in the chat.');
      }
    });
  }

  private showNotification(message: string) {
    this.snackBar.open(message, 'Close', {
      duration: 4000,
      horizontalPosition: 'center',
      verticalPosition: 'bottom',
      panelClass: ['success-snackbar'] // Optional custom styling
    });
  }

  // Actions
  onClose(): void {
    this.close.emit();
  }

  onAction(type: string): void {
    this.action.emit(type);
  }

  setTab(tab: TabType): void {
    this.activeTab.set(tab);
  }
}