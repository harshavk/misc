import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

// Models
import { Employee } from '@core/models/index';

// Material Imports
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatCheckboxModule } from '@angular/material/checkbox';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatRippleModule } from '@angular/material/core';

@Component({
  selector: 'app-employee-list',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    MatButtonModule,
    MatIconModule,
    MatProgressBarModule,
    MatCheckboxModule,
    MatTooltipModule,
    MatRippleModule
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './employee-list.html',
  styleUrls: ['./employee-list.css']
})
export class EmployeeListComponent {
  // Inputs
  @Input() employees: Employee[] = [];
  @Input() selectedId: string | null = null;
  @Input() isManager = false;
  @Input() isBulkMode = false;
  @Input() selectedIds: Set<string> = new Set();
  @Input() error: string | null = null;

  // Outputs
  @Output() selectEmployee = new EventEmitter<string>();
  @Output() toggleBulk = new EventEmitter<void>();
  @Output() toggleSelection = new EventEmitter<string>();
  @Output() search = new EventEmitter<string>();
  @Output() filter = new EventEmitter<string>();

  searchQuery = '';
  activeFilter = 'All';

  onSearch(query: string): void {
    this.searchQuery = query;
    this.search.emit(query);
  }

  onFilter(filterType: string): void {
    this.activeFilter = filterType;
    this.filter.emit(filterType);
  }

  handleCardClick(emp: Employee, event: Event): void {
    if (this.isBulkMode) {
      this.toggleSelection.emit(emp.id);
      event.preventDefault(); // Prevent text selection
      event.stopPropagation();
    } else {
      this.selectEmployee.emit(emp.id);
    }
  }

  // Helper to check if a specific ID is in the set
  isSelected(id: string): boolean {
    return this.selectedIds.has(id);
  }
}