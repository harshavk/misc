import {
  Component, ElementRef, ChangeDetectionStrategy,
  AfterViewInit, OnDestroy, inject, signal, computed,
  input, output, effect, untracked, ViewChild, NgZone, HostListener
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormControl } from '@angular/forms';
import { CdkTextareaAutosize, TextFieldModule } from '@angular/cdk/text-field';

import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatChipsModule } from '@angular/material/chips';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar } from '@angular/material/snack-bar';

import { ThreadMessage } from '@core/models/ai-thread.models';
import { ActionResult } from '@core/models/ai-search.models';
import { PromptCategory } from '@core/services/prompt.service';

@Component({
  selector: 'app-chat-area',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatIconModule,
    MatButtonModule,
    MatInputModule,
    MatFormFieldModule,
    MatTooltipModule,
    MatChipsModule,
    MatProgressSpinnerModule,
    TextFieldModule
  ],
  templateUrl: './chat-area.html',
  styleUrls: ['./chat-area.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChatAreaComponent implements AfterViewInit, OnDestroy {
  private readonly snackBar = inject(MatSnackBar);
  private readonly _ngZone = inject(NgZone);

  // --- State ---
  readonly selectedCategory = signal<string | null>(null);
  private isNearBottom = true;
  private scrollListener: (() => void) | undefined;

  // --- Inputs ---
  readonly messages = input<ThreadMessage[]>([]);
  readonly prompts = input<PromptCategory[]>([]);
  readonly isTyping = input(false);
  readonly isLoading = input(false);
  readonly isListening = input(false);
  readonly error = input<string | null>(null);
  readonly helperHint = input('');
  readonly queryControl = input.required<FormControl<string>>();
  readonly userName = input('Employee');
  readonly suggestedActions = input<ActionResult[]>([]);
  readonly isManager = input(false);
  readonly inputStatus = input('');

  // --- Outputs ---
  readonly submitQuery = output<void>();
  readonly toggleMic = output<void>();
  readonly exportChat = output<void>();
  readonly contentLinkClick = output<{ msg: ThreadMessage, event: MouseEvent }>();
  readonly toolPayloadClick = output<{ msg: ThreadMessage, tool: any, event: MouseEvent }>();
  readonly actionClick = output<string>();
  readonly openLibrary = output<void>();
  readonly promptClick = output<string>();
  readonly messageFeedback = output<{ index: number, type: 'like' | 'dislike' | null }>();

  // --- View Children ---
  @ViewChild('autosize') autosize!: CdkTextareaAutosize;
  @ViewChild('scrollContainer') private scrollContainer!: ElementRef;
  @ViewChild('chatInput') private chatInput!: ElementRef<HTMLTextAreaElement>;

  constructor() {
    // Effect: Scroll to bottom on new messages
    effect(() => {
      const msgs = this.messages();
      untracked(() => {
        const lastMsg = msgs[msgs.length - 1];
        if ((lastMsg?.type === 'human') || this.isNearBottom) {
          this.scrollToBottom();
        }

        if (msgs.length === 0) {
          this.queryControl().reset(); // Clear the text
          this.triggerResize();        // Shrink textarea back to 1 row
        }
      });
    });

    // Effect: Set default category
    effect(() => {
      const currentPrompts = this.prompts();
      untracked(() => {
        if (currentPrompts.length > 0 && !this.selectedCategory()) {
          this.selectedCategory.set(currentPrompts[0].category);
        }
      });
    }, { allowSignalWrites: true });
  }

  readonly displayPrompts = computed(() => {
    const allCats = this.prompts();
    const selected = this.selectedCategory();
    if (!allCats.length) return [];
    const targetCat = selected ? allCats.find(c => c.category === selected) : allCats[0];
    return targetCat ? targetCat.prompts.slice(0, 4) : [];
  });

  ngAfterViewInit() {
    const el = this.scrollContainer?.nativeElement;
    if (el) {
      this.scrollListener = () => this.checkScrollPosition();
      el.addEventListener('scroll', this.scrollListener);
      this.scrollToBottom();
    }
    this.triggerResize();
  }

  ngOnDestroy() {
    const el = this.scrollContainer?.nativeElement;
    if (el && this.scrollListener) {
      el.removeEventListener('scroll', this.scrollListener);
    }
  }

  @HostListener('window:resize')
  onWindowResize() {
    this.triggerResize();
  }

  triggerResize() {
    this._ngZone.onStable.pipe().subscribe(() => {
      if (this.autosize) this.autosize.resizeToFitContent(true);
    });
  }

  private checkScrollPosition() {
    const el = this.scrollContainer.nativeElement;
    this.isNearBottom = (el.scrollTop + el.clientHeight) >= (el.scrollHeight - 100);
  }

  private scrollToBottom(): void {
    requestAnimationFrame(() => {
      try {
        const el = this.scrollContainer.nativeElement;
        el.scrollTop = el.scrollHeight;
        this.isNearBottom = true;
      } catch (err) { }
    });
  }

  formatToolName(name?: string): string {
    return name ? name.replace(/_/g, ' ') : '';
  }

  onKeydownEnter(event: KeyboardEvent): void {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.submitQuery.emit();
      setTimeout(() => this.triggerResize(), 50);
    }
  }

  trackMessage(index: number, msg: ThreadMessage): string {
    return msg.id || `${index}-${msg.type}`;
  }

  selectCategory(catName: string): void {
    this.selectedCategory.set(catName);
  }

  onPromptSelect(promptText: string): void {
    this.promptClick.emit(promptText);
    setTimeout(() => {
      this.chatInput.nativeElement.focus();
      this.triggerResize();
    }, 100);
  }

  copyToClipboard(content: string): void {
    navigator.clipboard.writeText(content).then(() => {
      this.snackBar.open('Copied to clipboard', '', { duration: 1500, verticalPosition: 'top' });
    });
  }

  onFeedback(index: number, type: 'like' | 'dislike'): void {
    const msg = this.messages()[index];
    const newFeedback = msg.feedback === type ? null : type;
    this.messageFeedback.emit({ index, type: newFeedback });
  }
}