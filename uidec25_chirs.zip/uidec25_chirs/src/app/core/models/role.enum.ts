export enum Role {
  Employee = 'Employee',
  Manager = 'Manager',
  Admin = 'Admin'
}
