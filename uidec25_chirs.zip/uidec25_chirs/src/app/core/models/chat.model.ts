export type Author = 'user' | 'agent';

export type ChatMessageType = 'text' | 'hint' | 'file' | 'link' | 'media';

export interface ChatFile {
    name: string;
    url: string;
    mime?: string;
    size?: number;
}

export interface OnboardingTask {
    id: string;
    title: string;
    owner: string;
    dueDate?: string;
    status?: 'open' | 'done';
}

export interface OnboardingPlan {
    id: string;
    employee: { name?: string; email?: string; role?: string; startDate?: string };
    tasks: OnboardingTask[];
    createdAt: string;
}

export interface RoleAccessItem {
    system: string;
    group: string;
    justification?: string;
    approver?: string;
    required?: boolean;
}

export interface CloudPcRequest {
    requestId: string;
    status: 'draft' | 'submitted' | 'completed';
    payload: any;
}

export interface Ticket {
    ticketId: string;
    status: 'open' | 'in_progress' | 'resolved';
    summary: string;
    assignee?: string;
    link?: string;
}

export interface ChatMessage {
    id: string;
    author: Author;
    authorDisplay?: string;
    type: ChatMessageType;
    text?: string;
    time: number;
    file?: ChatFile;
    meta?: any;
}
