import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { tap, catchError, shareReplay } from 'rxjs/operators';
import { of } from 'rxjs';

import { environment } from '../../../environments/environment';
import { ApiEndpoints } from '../config/api-endpoints';

export interface AdminAction {
    title: string;
    description: string;
    icon: string;
    colorClass: string;
    route: string;
}

@Injectable({
    providedIn: 'root'
})
export class AdminService {
    private http = inject(HttpClient);

    // State
    readonly dashboardActions = signal<AdminAction[]>([]);

    constructor() {
        this.loadDashboardConfig();
    }

    loadDashboardConfig() {
        let request$;

        // 1. Mock Mode
        if (environment.mockConfig.enableDashboard) { // Reusing dashboard flag or add new one
            request$ = this.http.get<AdminAction[]>('assets/data/admin-config.json');
        }
        // 2. Real API Mode
        else {
            const url = `${environment.apiBaseUrl}${ApiEndpoints.ADMIN.DASHBOARD_CONFIG}`;
            request$ = this.http.get<AdminAction[]>(url);
        }

        request$.pipe(
            tap(data => this.dashboardActions.set(data)),
            catchError(err => {
                console.error('Failed to load admin config', err);
                return of([]);
            }),
            shareReplay(1)
        ).subscribe();
    }
}