import { Injectable, inject, signal } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { tap, delay, catchError } from 'rxjs/operators';

import { environment } from '../../../environments/environment';
import { ApiEndpoints } from '../config/api-endpoints';
import { ShellService } from './shell.service';

export interface SystemSettings {
    general: {
        maintenanceMode: boolean;
        allowGuestAccess: boolean;
        appName: string;
    };
    ai: {
        temperature: number;
        model: string;
        maxTokens: number;
    };
    compliance: {
        retentionDays: number;
        logAudit: boolean;
    };
}

@Injectable({
    providedIn: 'root'
})
export class SettingsService {
    private http = inject(HttpClient);
    private shellService = inject(ShellService);

    // Default fallback state
    private readonly defaultSettings: SystemSettings = {
        general: { maintenanceMode: false, allowGuestAccess: true, appName: 'WF App' },
        ai: { temperature: 0.7, model: 'gpt-3.5-turbo', maxTokens: 1024 },
        compliance: { retentionDays: 30, logAudit: true }
    };

    // ---------------------------------------------------------------------------
    // LOAD SETTINGS
    // ---------------------------------------------------------------------------
    getSettings(): Observable<SystemSettings> {
        let request$;

        // 1. Mock Mode
        if (environment.mockConfig.enableDashboard) { // Reusing a flag, or add enableSettings
            request$ = this.http.get<SystemSettings>('assets/data/mock-settings.json');
        }
        // 2. Real API Mode
        else {
            const url = `${environment.apiBaseUrl}${ApiEndpoints.ADMIN.SETTINGS}`;
            request$ = this.http.get<SystemSettings>(url);
        }

        return request$.pipe(
            catchError(err => {
                console.error('Failed to load settings', err);
                return of(this.defaultSettings);
            })
        );
    }

    // ---------------------------------------------------------------------------
    // SAVE SETTINGS
    // ---------------------------------------------------------------------------
    saveSettings(settings: SystemSettings): Observable<any> {
        // Update App Title immediately for UI feedback
        if (settings.general.appName) {
            this.shellService.appTitle.set(settings.general.appName);
        }

        // 1. Mock Mode
        if (environment.mockConfig.enableDashboard) {
            return of({ success: true }).pipe(delay(1000));
        }
        // 2. Real API Mode
        else {
            const url = `${environment.apiBaseUrl}${ApiEndpoints.ADMIN.SETTINGS}`;
            return this.http.post(url, settings);
        }
    }
}