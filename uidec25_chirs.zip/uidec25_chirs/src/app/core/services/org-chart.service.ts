import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { delay, map } from 'rxjs/operators';

import { environment } from '../../../environments/environment';
import { ApiEndpoints } from '../config/api-endpoints';

export interface EmployeeNode {
    id: string;
    name: string;
    role: string;
    img?: string;
    type: 'manager' | 'lead' | 'employee';
    isCurrentUser?: boolean;

    // Lazy Loading props
    hasChildren?: boolean;
    reports?: EmployeeNode[];
    expanded?: boolean;
    isLoading?: boolean;
}

@Injectable({ providedIn: 'root' })
export class OrgChartService {
    private readonly http = inject(HttpClient);

    // Constant for mock file
    private readonly MOCK_ORG_URL = 'assets/data/mock-org-chart.json';

    // Cache the full raw data to simulate a DB in mock mode
    private rawDataCache: EmployeeNode[] = [];

    // -------------------------------------------------------------------------
    // 1. INITIAL LOAD: Get Path to User
    // -------------------------------------------------------------------------
    getInitialTree(): Observable<EmployeeNode[]> {

        // A. MOCK MODE
        if (environment.mockConfig.enableOrgChart) {
            return this.http.get<{ Report_Entry: any[] }>(this.MOCK_ORG_URL).pipe(
                map(response => {
                    this.rawDataCache = this.mapWorkdayResponse(response.Report_Entry);
                    return this.pruneTreeForUser(this.rawDataCache);
                })
            );
        }

        // B. REAL API MODE
        else {
            const url = `${environment.apiBaseUrl}${ApiEndpoints.ORG_CHART.GET_INITIAL}`;
            return this.http.get<EmployeeNode[]>(url);
        }
    }

    // -------------------------------------------------------------------------
    // 2. LAZY LOAD: Get Children for specific ID
    // -------------------------------------------------------------------------
    getChildren(parentId: string): Observable<EmployeeNode[]> {

        // A. MOCK MODE
        if (environment.mockConfig.enableOrgChart) {
            const children = this.findChildrenInCache(this.rawDataCache, parentId);
            return of(children).pipe(delay(600));
        }

        // B. REAL API MODE
        else {
            // ✅ Use Constant
            const url = `${environment.apiBaseUrl}${ApiEndpoints.ORG_CHART.GET_CHILDREN(parentId)}`;
            return this.http.get<EmployeeNode[]>(url);
        }
    }

    // -------------------------------------------------------------------------
    // --- HELPERS (Mock Logic simulation) ---
    // -------------------------------------------------------------------------

    private mapWorkdayResponse(entries: any[]): EmployeeNode[] {
        return entries.map(entry => ({
            id: entry.Employee_ID,
            name: entry.Legal_Name,
            role: entry.Business_Title,
            img: entry.Photo_URL,
            isCurrentUser: !!entry.is_Logged_In_User,
            type: this.getUiType(entry.Management_Level),
            hasChildren: entry.workers && entry.workers.length > 0,
            reports: entry.workers ? this.mapWorkdayResponse(entry.workers) : []
        }));
    }

    private pruneTreeForUser(nodes: EmployeeNode[]): EmployeeNode[] {
        return nodes.map(node => {
            const isUserInBranch = this.checkBranchForUser(node);

            if (isUserInBranch) {
                return {
                    ...node,
                    expanded: true, // Auto-expand path
                    reports: this.pruneTreeForUser(node.reports || [])
                };
            } else {
                return {
                    ...node,
                    expanded: false,
                    reports: [], // Clear reports to save memory
                    hasChildren: node.reports && node.reports.length > 0
                };
            }
        });
    }

    private checkBranchForUser(node: EmployeeNode): boolean {
        if (node.isCurrentUser) return true;
        return node.reports?.some(child => this.checkBranchForUser(child)) ?? false;
    }

    private findChildrenInCache(nodes: EmployeeNode[], parentId: string): EmployeeNode[] {
        for (const node of nodes) {
            if (node.id === parentId) {
                return (node.reports || []).map(child => ({
                    ...child,
                    reports: [],
                    expanded: false,
                    hasChildren: child.reports && child.reports.length > 0
                }));
            }
            if (node.reports) {
                const found = this.findChildrenInCache(node.reports, parentId);
                if (found.length) return found;
            }
        }
        return [];
    }

    private getUiType(level: string): 'manager' | 'lead' | 'employee' {
        const lower = level.toLowerCase();
        if (lower.includes('executive') || lower.includes('vp')) return 'manager';
        if (lower.includes('manager')) return 'lead';
        return 'employee';
    }
}