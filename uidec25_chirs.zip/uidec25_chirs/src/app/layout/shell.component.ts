import { Component, inject, OnInit, ViewChild, HostListener, ChangeDetectorRef, AfterViewInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet, Router, RouterModule } from '@angular/router';

// Material Imports
import { MatSidenavModule, MatSidenav } from '@angular/material/sidenav';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatRippleModule } from '@angular/material/core';
import { MatMenuModule } from '@angular/material/menu';
import { MatToolbarModule } from '@angular/material/toolbar';

import { fadeAnimation } from '../core/animations/route-animations';
import { AuthService } from '../core/services/auth.service';
import { ThemeService } from '../core/services/theme.service';
import { ShellService, NavItem } from '../core/services/shell.service';
import { Role } from '../core/models/role.enum';

@Component({
  selector: 'app-shell',
  standalone: true,
  imports: [
    CommonModule,
    RouterModule,
    MatSidenavModule,
    MatIconModule,
    MatButtonModule,
    MatRippleModule,
    MatMenuModule,
    MatToolbarModule
  ],
  animations: [fadeAnimation],
  templateUrl: './shell.component.html',
  styleUrls: ['./shell.component.scss']
})
export class ShellComponent implements OnInit, AfterViewInit {
  protected readonly auth = inject(AuthService);
  protected readonly shellService = inject(ShellService);
  readonly themeService = inject(ThemeService);

  private router = inject(Router);
  private cdr = inject(ChangeDetectorRef);

  @ViewChild('sidenav') sidenav!: MatSidenav;

  isMobile = false;

  get navItems(): NavItem[] {
    return this.shellService.mainNavItems();
  }

  get adminNavItems(): NavItem[] {
    return this.shellService.adminNavItems();
  }

  // ✅ 2. Helper to filter items based on visibility
  get visibleNavItems() {
    return this.navItems.filter(i => !i.roles || this.auth.hasAnyRole(i.roles));
  }

  get isAdmin(): boolean {
    const user = this.auth.currentUser();
    return user?.roles?.includes(Role.Admin) ?? false;
  }

  get currentUser() {
    return this.auth.currentUser();
  }

  get currentTitle() {
    // ✅ Uses App Title from JSON + Route label
    const appTitle = this.shellService.appTitle();
    const match = this.navItems.find(n => this.router.url.startsWith(n.route))
      || this.adminNavItems.find(n => this.router.url.startsWith(n.route));

    return match ? match.label : appTitle;
  }

  ngOnInit() {
    this.checkScreenSize();
  }

  ngAfterViewInit() {
    this.cdr.detectChanges();
  }

  @HostListener('window:resize', [])
  onResize() {
    this.checkScreenSize();
  }

  toggleSidebar() {
    this.sidenav.toggle();
  }

  toggleTheme() {
    this.themeService.toggle();
  }

  onNavItemClick() {
    if (this.isMobile) this.sidenav.close();
  }

  onLogout() {
    this.auth.logout();
    this.router.navigate(['/login']);
  }

  getRouteAnimationData(outlet: RouterOutlet) {
    if (!outlet || !outlet.isActivated) {
      return '';
    }
    return outlet.activatedRouteData['animation'] || 'Default';
  }

  private checkScreenSize() {
    this.isMobile = window.innerWidth <= 768;
    if (!this.isMobile && this.sidenav) {
      this.sidenav.open();
    }
  }
}