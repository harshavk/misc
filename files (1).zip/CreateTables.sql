-- ═══════════════════════════════════════════════════════════════════
-- FileImportJobs  (replaces Phase 1 script)
-- ═══════════════════════════════════════════════════════════════════

CREATE TABLE [dbo].[FileImportJobs]
(
    [Id]               INT             NOT NULL IDENTITY(1,1),
    [FileName]         NVARCHAR(255)   NOT NULL,
    [SavedFilePath]    NVARCHAR(500)   NOT NULL,
    [Department]       NVARCHAR(100)   NOT NULL,
    [UploadedBy]       NVARCHAR(100)   NOT NULL,
    [UploadedAt]       DATETIME2       NOT NULL,
    [Status]           NVARCHAR(20)    NOT NULL,
    [CsvFormat]        NVARCHAR(50)    NOT NULL DEFAULT 'BulkIngestion',
    [TotalRows]        INT             NULL,
    [ValidRows]        INT             NULL,
    [ErrorRows]        INT             NULL,
    [JobStartedAt]     DATETIME2       NULL,
    [JobCompletedAt]   DATETIME2       NULL,
    [ProcessedBy]      NVARCHAR(100)   NULL,
    [ProcessedAt]      DATETIME2       NULL,
    [FailureReason]    NVARCHAR(500)   NULL,

    CONSTRAINT [PK_FileImportJobs] PRIMARY KEY CLUSTERED ([Id] ASC)
);
GO

CREATE NONCLUSTERED INDEX [IX_FileImportJobs_Status]
    ON [dbo].[FileImportJobs] ([Status] ASC)
    INCLUDE ([UploadedAt]);
GO

-- ═══════════════════════════════════════════════════════════════════
-- FileImportJobErrors  (replaces Phase 1 script)
-- RawRowJson stores the full CSV row as JSON — format-agnostic
-- No typed columns — new formats need zero schema changes
-- ═══════════════════════════════════════════════════════════════════

CREATE TABLE [dbo].[FileImportJobErrors]
(
    [Id]                INT             NOT NULL IDENTITY(1,1),
    [FileImportJobId]   INT             NOT NULL,
    [RowNumber]         INT             NOT NULL,
    [RawRowJson]        NVARCHAR(MAX)   NOT NULL,
    [ErrorType]         NVARCHAR(100)   NOT NULL,
    [ErrorMessage]      NVARCHAR(500)   NOT NULL,
    [CreatedAt]         DATETIME2       NOT NULL,

    CONSTRAINT [PK_FileImportJobErrors]
        PRIMARY KEY CLUSTERED ([Id] ASC),

    CONSTRAINT [FK_FileImportJobErrors_FileImportJobs]
        FOREIGN KEY ([FileImportJobId])
        REFERENCES [dbo].[FileImportJobs] ([Id])
        ON DELETE CASCADE
);
GO

CREATE NONCLUSTERED INDEX [IX_FileImportJobErrors_FileImportJobId]
    ON [dbo].[FileImportJobErrors] ([FileImportJobId] ASC)
    INCLUDE ([RowNumber]);
GO

CREATE NONCLUSTERED INDEX [IX_FileImportJobErrors_JobId_RowNumber]
    ON [dbo].[FileImportJobErrors] ([FileImportJobId] ASC, [RowNumber] ASC);
GO
