/// <reference path="../jquery/jquery.min.js" />

let FileImportModule = (function () {

    // ── constants ────────────────────────────────────────────────
    let POLL_INTERVAL_MS = 5000;
    let MAX_FILE_SIZE_MB = 500;

    // ── state ────────────────────────────────────────────────────
    let _pollTimer = null;
    let _config = null;

    // ── init ─────────────────────────────────────────────────────
    function init() {
        _config = window.fileImportDetailConfig || null;

        bindListPageEvents();
        bindDetailPageEvents();

        if (_config !== null && _config.isActive) {
            startPolling();
        }
    }

    // ── list page ────────────────────────────────────────────────
    function bindListPageEvents() {
        let $table = $('#tblFileImports');

        if ($table.length === 0) {
            return;
        }

        initDataTable($table);
        bindKpiFilter();
        bindUploadZone();
        bindFileInput();
    }

    function initDataTable($table) {
        $table.DataTable({
            order:       [[3, 'desc']],
            pageLength:  25,
            responsive:  true,
            columnDefs:  [{ orderable: false, targets: -1 }],
            language: {
                search:        'Search uploads:',
                lengthMenu:    'Show _MENU_ uploads',
                info:          'Showing _START_ to _END_ of _TOTAL_ uploads',
                emptyTable:    'No uploads found'
            }
        });
    }

    function bindKpiFilter() {
        $('.fi-kpi').on('click', function () {
            let filter = $(this).data('filter');
            let table  = $('#tblFileImports').DataTable();

            $('.fi-kpi').removeClass('fi-kpi-active');
            $(this).addClass('fi-kpi-active');

            if (filter === 'all') {
                table.column(4).search('').draw();
            } else {
                table.column(4).search(filter).draw();
            }
        });
    }

    function bindUploadZone() {
        $('#btnNewUpload').on('click', function () {
            $('#uploadZone').slideDown(200);
            $('html, body').animate({ scrollTop: $('#uploadZone').offset().top - 20 }, 300);
        });

        $('#btnCancelUpload').on('click', function () {
            $('#uploadZone').slideUp(200);
            resetUploadForm();
        });
    }

    function bindFileInput() {
        $('#csvFile').on('change', function () {
            let file = this.files[0];

            if (!file) {
                return;
            }

            if (!validateFileExtension(file.name)) {
                Notify.Error('Only CSV files are allowed.');
                $(this).val('');
                return;
            }

            if (!validateFileSize(file.size)) {
                Notify.Error('File size exceeds the maximum allowed limit of ' + MAX_FILE_SIZE_MB + ' MB.');
                $(this).val('');
                return;
            }
        });

        $('#frmFileImport').on('submit', function (e) {
            e.preventDefault();
            submitUploadForm($(this));
        });
    }

    function validateFileExtension(fileName) {
        return fileName.toLowerCase().endsWith('.csv');
    }

    function validateFileSize(sizeBytes) {
        return sizeBytes <= MAX_FILE_SIZE_MB * 1024 * 1024;
    }

    function submitUploadForm($form) {
        let hasFile  = $('#csvFile').val().length > 0;
        let hasUrl   = $('#fileUrl').val().trim().length > 0;

        if (!hasFile && !hasUrl) {
            Notify.Error('Please select a CSV file or paste a file URL.');
            return;
        }

        $('#btnSubmitUpload').prop('disabled', true).html(
            '<i class="ti ti-loader"></i> Uploading…'
        );

        $form[0].submit();
    }

    function resetUploadForm() {
        $('#csvFile').val('');
        $('#fileUrl').val('');
        $('#btnSubmitUpload').prop('disabled', false).html(
            '<i class="ti ti-upload"></i> Upload & Validate'
        );
    }

    // ── detail page ──────────────────────────────────────────────
    function bindDetailPageEvents() {
        if ($('#tblErrors').length > 0) {
            initErrorDataTable();
        }

        $('#btnSendToIngestion').on('click', function () {
            confirmSendToIngestion();
        });
    }

    function initErrorDataTable() {
        $('#tblErrors').DataTable({
            order:      [[0, 'asc']],
            pageLength: 10,
            responsive: true,
            language: {
                search:     'Search errors:',
                emptyTable: 'No errors found'
            }
        });
    }

    function confirmSendToIngestion() {
        if (!confirm('Are you sure you want to send valid rows to ingestion? This cannot be undone.')) {
            return;
        }

        sendToIngestion();
    }

    function sendToIngestion() {
        let $btn = $('#btnSendToIngestion');

        $btn.prop('disabled', true).html('<i class="ti ti-loader"></i> Sending…');

        let token = $('input[name="__RequestVerificationToken"]').val();

        $.ajax({
            type:     'POST',
            url:      _config.sendToIngestionUrl,
            cache:    false,
            dataType: 'json',
            data: {
                id:                          _config.jobId,
                __RequestVerificationToken:  token
            }
        })
        .done(function (data) {
            if (data && data.success) {
                Notify.Success('Job sent to ingestion successfully.');
                startPolling();
            } else {
                Notify.Error(data.message || 'Failed to send to ingestion.');
                $btn.prop('disabled', false).html('<i class="ti ti-send"></i> Send to Ingestion');
            }
        })
        .fail(function () {
            Notify.Error('An error occurred. Please try again.');
            $btn.prop('disabled', false).html('<i class="ti ti-send"></i> Send to Ingestion');
        });
    }

    // ── polling ──────────────────────────────────────────────────
    function startPolling() {
        stopPolling();
        _pollTimer = setInterval(pollStatus, POLL_INTERVAL_MS);
    }

    function stopPolling() {
        if (_pollTimer !== null) {
            clearInterval(_pollTimer);
            _pollTimer = null;
        }
    }

    function pollStatus() {
        $.ajax({
            type:     'GET',
            url:      _config.statusUrl + '/' + _config.jobId,
            cache:    false,
            dataType: 'json'
        })
        .done(function (data) {
            if (!data) {
                return;
            }

            updateProgressBar(data);

            if (data.isComplete) {
                stopPolling();
                location.reload();
            }
        })
        .fail(function () {
            stopPolling();
        });
    }

    function updateProgressBar(data) {
        let pct = data.validPercent || 0;

        $('#progFill').css('width', pct + '%');
        $('#progPct').text(pct + '%');

        if (data.totalRows) {
            $('#progLabel').text(
                'Checked ' + formatNumber(data.totalRows) + ' rows — ' +
                formatNumber(data.validRows || 0) + ' valid, ' +
                formatNumber(data.errorRows || 0) + ' errors'
            );
        }
    }

    function formatNumber(n) {
        return n.toLocaleString();
    }

    // ── public ───────────────────────────────────────────────────
    return {
        init: init
    };

})();

$(document).ready(function () {
    FileImportModule.init();
});
