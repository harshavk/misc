using Common.Enums;

namespace Web.Areas.Vstar.Controllers.DocUpload.Models;

public class FileImportListViewModel
{
    public int Id { get; set; }
    public string FileName { get; set; } = string.Empty;
    public string Department { get; set; } = string.Empty;
    public string CsvFormat { get; set; } = string.Empty;
    public string UploadedBy { get; set; } = string.Empty;
    public DateTime UploadedAt { get; set; }
    public FileImportStatus Status { get; set; }
    public int? TotalRows { get; set; }
    public int? ValidRows { get; set; }
    public int? ErrorRows { get; set; }

    public string StatusDisplayText => Status switch
    {
        FileImportStatus.Uploading  => "Uploading",
        FileImportStatus.Validating => "Validating",
        FileImportStatus.Validated  => "Validated",
        FileImportStatus.Processing => "Processing",
        FileImportStatus.Ingested   => "Ingested",
        FileImportStatus.Failed     => "Failed",
        _                           => "Unknown"
    };

    public string StatusCssClass => Status switch
    {
        FileImportStatus.Uploading  => "badge-uploading",
        FileImportStatus.Validating => "badge-validating",
        FileImportStatus.Validated  => "badge-validated",
        FileImportStatus.Processing => "badge-processing",
        FileImportStatus.Ingested   => "badge-ingested",
        FileImportStatus.Failed     => "badge-failed",
        _                           => "badge-secondary"
    };

    public int ValidPercent
    {
        get
        {
            if (TotalRows is null || TotalRows == 0)
            {
                return 0;
            }

            return (int)Math.Round((double)(ValidRows ?? 0) / TotalRows.Value * 100);
        }
    }
}
