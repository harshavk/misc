namespace Web.Areas.Vstar.Controllers.DocUpload.Models;

public class FileImportStatusDto
{
    public int Id { get; set; }
    public string Status { get; set; } = string.Empty;
    public int? TotalRows { get; set; }
    public int? ValidRows { get; set; }
    public int? ErrorRows { get; set; }
    public int ValidPercent { get; set; }
    public bool IsComplete { get; set; }
    public bool IsActive { get; set; }
    public string? FailureReason { get; set; }
}
