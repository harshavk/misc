using Common.Enums;

namespace Web.Areas.Vstar.Controllers.DocUpload.Models;

public class FileImportDetailViewModel
{
    public int Id { get; set; }
    public string FileName { get; set; } = string.Empty;
    public string SavedFilePath { get; set; } = string.Empty;
    public string Department { get; set; } = string.Empty;
    public string CsvFormat { get; set; } = string.Empty;
    public string UploadedBy { get; set; } = string.Empty;
    public DateTime UploadedAt { get; set; }
    public FileImportStatus Status { get; set; }
    public int? TotalRows { get; set; }
    public int? ValidRows { get; set; }
    public int? ErrorRows { get; set; }
    public DateTime? JobStartedAt { get; set; }
    public DateTime? JobCompletedAt { get; set; }
    public string? ProcessedBy { get; set; }
    public DateTime? ProcessedAt { get; set; }
    public string? FailureReason { get; set; }
    public string JobNumber { get; set; } = string.Empty;

    public List<FileImportErrorRowViewModel> SampleErrors { get; set; } = [];

    public int TotalErrorCount { get; set; }

    public bool CanSendToIngestion => Status == FileImportStatus.Validated && (ValidRows ?? 0) > 0;

    public bool IsActive => Status == FileImportStatus.Validating
                         || Status == FileImportStatus.Uploading
                         || Status == FileImportStatus.Processing;

    public int ValidPercent
    {
        get
        {
            if (TotalRows is null || TotalRows == 0)
            {
                return 0;
            }

            return (int)Math.Round((double)(ValidRows ?? 0) / TotalRows.Value * 100);
        }
    }

    public string StatusDisplayText => Status switch
    {
        FileImportStatus.Uploading  => "Uploading",
        FileImportStatus.Validating => "Validating",
        FileImportStatus.Validated  => "Validated",
        FileImportStatus.Processing => "Processing",
        FileImportStatus.Ingested   => "Ingested",
        FileImportStatus.Failed     => "Failed",
        _                           => "Unknown"
    };
}
