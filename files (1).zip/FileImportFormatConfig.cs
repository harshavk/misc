namespace Common.Configuration;

public class FileImportFormatConfig
{
    public Dictionary<string, FileImportFormatDefinition> FileImportFormats { get; set; }
        = new Dictionary<string, FileImportFormatDefinition>();
}
