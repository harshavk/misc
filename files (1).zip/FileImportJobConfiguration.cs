using Common.EntityFramework.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Common.EntityFramework.Configurations;

public class FileImportJobConfiguration : IEntityTypeConfiguration<FileImportJob>
{
    public void Configure(EntityTypeBuilder<FileImportJob> builder)
    {
        builder.ToTable("FileImportJobs");

        builder.HasKey(x => x.Id);

        builder.Property(x => x.Id)
            .UseIdentityColumn();

        builder.Property(x => x.FileName)
            .IsRequired()
            .HasMaxLength(255);

        builder.Property(x => x.SavedFilePath)
            .IsRequired()
            .HasMaxLength(500);

        builder.Property(x => x.Department)
            .IsRequired()
            .HasMaxLength(100);

        builder.Property(x => x.UploadedBy)
            .IsRequired()
            .HasMaxLength(100);

        builder.Property(x => x.UploadedAt)
            .IsRequired();

        builder.Property(x => x.Status)
            .IsRequired()
            .HasConversion<string>()
            .HasMaxLength(20);

        builder.Property(x => x.CsvFormat)
            .IsRequired()
            .HasMaxLength(50);

        builder.Property(x => x.TotalRows)
            .IsRequired(false);

        builder.Property(x => x.ValidRows)
            .IsRequired(false);

        builder.Property(x => x.ErrorRows)
            .IsRequired(false);

        builder.Property(x => x.JobStartedAt)
            .IsRequired(false);

        builder.Property(x => x.JobCompletedAt)
            .IsRequired(false);

        builder.Property(x => x.ProcessedBy)
            .HasMaxLength(100)
            .IsRequired(false);

        builder.Property(x => x.ProcessedAt)
            .IsRequired(false);

        builder.Property(x => x.FailureReason)
            .HasMaxLength(500)
            .IsRequired(false);

        builder.HasMany(x => x.FileImportJobErrors)
            .WithOne(x => x.FileImportJob)
            .HasForeignKey(x => x.FileImportJobId)
            .OnDelete(DeleteBehavior.Cascade);
    }
}
