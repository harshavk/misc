namespace Common.Configuration;

public class FileImportFormatDefinition
{
    /// <summary>
    /// Expected header columns in order — used for format detection and validation.
    /// </summary>
    public List<string> Headers { get; set; } = [];

    /// <summary>
    /// Maps normalized domain field names to CSV column names for this format.
    /// Key   = domain field  e.g. "EmpId", "NationalId", "FileName"
    /// Value = CSV column    e.g. "employeeid", "SSN", "File_Name"
    /// </summary>
    public Dictionary<string, string> FieldMap { get; set; }
        = new Dictionary<string, string>();
}
