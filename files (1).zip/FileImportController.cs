using Common.DataAccess;
using Common.EntityFramework.Models;
using Common.Enums;
using Microsoft.AspNetCore.Mvc;
using System.Text.Json;
using Web.Areas.Vstar.Controllers.DocUpload.Models;

namespace Web.Areas.Vstar.Controllers.DocUpload;

[Area("Vstar")]
public class FileImportController : BaseController
{
    private readonly IFileImportJobRepository _fileImportJobRepository;
    private readonly IFileStorageService _fileStorageService;
    private readonly CommonDependencies _commonDependencies;
    private const int SampleErrorCount = 10;

    public FileImportController(
          ILogger<FileImportController> logger
        , IUserService userService
        , IFileImportJobRepository fileImportJobRepository
        , IFileStorageService fileStorageService
        , CommonDependencies commonDependencies) : base(logger, userService)
    {
        _fileImportJobRepository = fileImportJobRepository;
        _fileStorageService = fileStorageService;
        _commonDependencies = commonDependencies;
    }

    [HttpGet]
    public async Task<IActionResult> Index()
    {
        string userId = _userService.GetCurrentUserEmployeeId();

        await _commonDependencies.ActivityLogRepository
            .Insert("FileImport Index", userId, WebHelper.GetRemoteIp());

        IEnumerable<FileImportJob> jobs = await _fileImportJobRepository.GetAllAsync();

        List<FileImportListViewModel> viewModels = jobs
            .Select(MapToListViewModel)
            .ToList();

        return View(viewModels);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> Upload(IFormFile? csvFile, string? fileUrl)
    {
        string userId = _userService.GetCurrentUserEmployeeId();

        bool hasFile = csvFile is not null && csvFile.Length > 0;
        bool hasUrl = !string.IsNullOrWhiteSpace(fileUrl);

        if (!hasFile && !hasUrl)
        {
            TempData["ErrorMessage"] = "Please select a CSV file or provide a file URL.";
            return RedirectToAction(nameof(Index));
        }

        string savedPath = hasFile
            ? await SaveUploadedFileAsync(csvFile!)
            : fileUrl!;

        string fileName = hasFile
            ? csvFile!.FileName
            : Path.GetFileName(fileUrl!);

        FileImportJob job = BuildNewJob(fileName, savedPath, userId);

        int jobId = await _fileImportJobRepository.InsertAsync(job);

        await _commonDependencies.ActivityLogRepository
            .Insert("FileImport Upload", userId, WebHelper.GetRemoteIp());

        return RedirectToAction(nameof(Detail), new { id = jobId });
    }

    [HttpGet]
    public async Task<IActionResult> Detail(int id)
    {
        string userId = _userService.GetCurrentUserEmployeeId();

        FileImportJob? job = await _fileImportJobRepository.GetByIdAsync(id);

        if (job is null)
        {
            return NotFound();
        }

        FileImportDetailViewModel viewModel = await BuildDetailViewModelAsync(job);

        await _commonDependencies.ActivityLogRepository
            .Insert("FileImport Detail", userId, WebHelper.GetRemoteIp());

        return View(viewModel);
    }

    [HttpGet]
    public async Task<IActionResult> Status(int id)
    {
        FileImportJob? job = await _fileImportJobRepository.GetByIdAsync(id);

        if (job is null)
        {
            return NotFound();
        }

        FileImportStatusDto dto = MapToStatusDto(job);

        return Json(dto);
    }

    [HttpPost]
    [ValidateAntiForgeryToken]
    public async Task<IActionResult> SendToIngestion(int id)
    {
        string userId = _userService.GetCurrentUserEmployeeId();

        FileImportJob? job = await _fileImportJobRepository.GetByIdAsync(id);

        if (job is null)
        {
            return Json(new { success = false, message = "Job not found." });
        }

        if (job.Status != FileImportStatus.Validated)
        {
            return Json(new { success = false, message = "Job is not in Validated status." });
        }

        if ((job.ValidRows ?? 0) == 0)
        {
            return Json(new { success = false, message = "No valid rows to process." });
        }

        await _fileImportJobRepository.UpdateStatusAsync(id, FileImportStatus.Processing);

        await _commonDependencies.ActivityLogRepository
            .Insert("FileImport SendToIngestion", userId, WebHelper.GetRemoteIp());

        return Json(new { success = true });
    }

    [HttpGet]
    public async Task<IActionResult> DownloadErrors(int id)
    {
        FileImportJob? job = await _fileImportJobRepository.GetByIdAsync(id);

        if (job is null)
        {
            return NotFound();
        }

        IEnumerable<FileImportJobError> errors =
            await _fileImportJobRepository.GetErrorsByJobIdAsync(id);

        byte[] csvBytes = BuildErrorCsv(errors);

        string downloadFileName = $"errors_{job.FileName}_{DateTime.UtcNow:yyyyMMddHHmmss}.csv";

        return File(csvBytes, "text/csv", downloadFileName);
    }

    // ── private helpers ───────────────────────────────────────────────────────

    private async Task<string> SaveUploadedFileAsync(IFormFile csvFile)
    {
        string tempFolder = Path.Combine(Path.GetTempPath(), "FileImport");
        Directory.CreateDirectory(tempFolder);

        string savedPath = Path.Combine(
            tempFolder,
            $"{Guid.NewGuid()}_{csvFile.FileName}");

        using FileStream stream = new(savedPath, FileMode.Create);
        await csvFile.CopyToAsync(stream);

        return savedPath;
    }

    private FileImportJob BuildNewJob(string fileName, string savedPath, string userId)
    {
        return new FileImportJob
        {
            FileName      = fileName,
            SavedFilePath = savedPath,
            Department    = string.Empty,
            UploadedBy    = userId,
            UploadedAt    = DateTime.UtcNow,
            Status        = FileImportStatus.Validating,
            CsvFormat     = string.Empty
        };
    }

    private async Task<FileImportDetailViewModel> BuildDetailViewModelAsync(FileImportJob job)
    {
        IEnumerable<FileImportJobError> sampleErrors =
            await _fileImportJobRepository.GetErrorsByJobIdAsync(job.Id);

        List<FileImportJobError> sampleList = sampleErrors.Take(SampleErrorCount).ToList();

        return new FileImportDetailViewModel
        {
            Id              = job.Id,
            FileName        = job.FileName,
            SavedFilePath   = job.SavedFilePath,
            Department      = job.Department,
            CsvFormat       = job.CsvFormat,
            UploadedBy      = job.UploadedBy,
            UploadedAt      = job.UploadedAt,
            Status          = job.Status,
            TotalRows       = job.TotalRows,
            ValidRows       = job.ValidRows,
            ErrorRows       = job.ErrorRows,
            JobStartedAt    = job.JobStartedAt,
            JobCompletedAt  = job.JobCompletedAt,
            ProcessedBy     = job.ProcessedBy,
            ProcessedAt     = job.ProcessedAt,
            FailureReason   = job.FailureReason,
            JobNumber       = job.Id.ToString("D6"),
            TotalErrorCount = job.ErrorRows ?? 0,
            SampleErrors    = sampleList.Select(MapToErrorRowViewModel).ToList()
        };
    }

    private static FileImportErrorRowViewModel MapToErrorRowViewModel(FileImportJobError error)
    {
        Dictionary<string, string> rawFields = DeserializeRawJson(error.RawRowJson);

        return new FileImportErrorRowViewModel
        {
            RowNumber    = error.RowNumber,
            ErrorType    = error.ErrorType,
            ErrorMessage = error.ErrorMessage,
            RawFields    = rawFields
        };
    }

    private static Dictionary<string, string> DeserializeRawJson(string rawRowJson)
    {
        if (string.IsNullOrWhiteSpace(rawRowJson))
        {
            return new Dictionary<string, string>();
        }

        return JsonSerializer.Deserialize<Dictionary<string, string>>(rawRowJson)
            ?? new Dictionary<string, string>();
    }

    private static FileImportListViewModel MapToListViewModel(FileImportJob job)
    {
        return new FileImportListViewModel
        {
            Id         = job.Id,
            FileName   = job.FileName,
            Department = job.Department,
            CsvFormat  = job.CsvFormat,
            UploadedBy = job.UploadedBy,
            UploadedAt = job.UploadedAt,
            Status     = job.Status,
            TotalRows  = job.TotalRows,
            ValidRows  = job.ValidRows,
            ErrorRows  = job.ErrorRows
        };
    }

    private static FileImportStatusDto MapToStatusDto(FileImportJob job)
    {
        int validPercent = 0;

        if (job.TotalRows is not null && job.TotalRows > 0)
        {
            validPercent = (int)Math.Round(
                (double)(job.ValidRows ?? 0) / job.TotalRows.Value * 100);
        }

        bool isActive = job.Status == FileImportStatus.Validating
                     || job.Status == FileImportStatus.Uploading
                     || job.Status == FileImportStatus.Processing;

        bool isComplete = job.Status == FileImportStatus.Validated
                       || job.Status == FileImportStatus.Ingested
                       || job.Status == FileImportStatus.Failed;

        return new FileImportStatusDto
        {
            Id            = job.Id,
            Status        = job.Status.ToString(),
            TotalRows     = job.TotalRows,
            ValidRows     = job.ValidRows,
            ErrorRows     = job.ErrorRows,
            ValidPercent  = validPercent,
            IsComplete    = isComplete,
            IsActive      = isActive,
            FailureReason = job.FailureReason
        };
    }

    private static byte[] BuildErrorCsv(IEnumerable<FileImportJobError> errors)
    {
        using System.IO.MemoryStream ms = new();
        using System.IO.StreamWriter writer = new(ms, System.Text.Encoding.UTF8);

        writer.WriteLine("RowNumber,ErrorType,ErrorMessage,RawData");

        foreach (FileImportJobError error in errors)
        {
            string escapedRaw = error.RawRowJson.Replace("\"", "\"\"");
            writer.WriteLine(
                $"{error.RowNumber},{error.ErrorType},{error.ErrorMessage},\"{escapedRaw}\"");
        }

        writer.Flush();
        return ms.ToArray();
    }
}
