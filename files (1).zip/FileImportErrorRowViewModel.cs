using Common.Enums;

namespace Web.Areas.Vstar.Controllers.DocUpload.Models;

public class FileImportErrorRowViewModel
{
    public int RowNumber { get; set; }
    public FileImportErrorType ErrorType { get; set; }
    public string ErrorMessage { get; set; } = string.Empty;

    /// <summary>
    /// Deserialized from RawRowJson — original CSV columns as-is.
    /// Key = original CSV column name, Value = cell value.
    /// </summary>
    public Dictionary<string, string> RawFields { get; set; }
        = new Dictionary<string, string>();

    public string ErrorTypeDisplayText => ErrorType switch
    {
        FileImportErrorType.InvalidEmpIdFormat    => "Invalid EmpId Format",
        FileImportErrorType.EmpIdNotFound         => "EmpId Not Found",
        FileImportErrorType.NationalIdRequired    => "NationalId Required",
        FileImportErrorType.NationalIdNotFound    => "NationalId Not Found",
        FileImportErrorType.FileNameTooLong       => "File Name Too Long",
        FileImportErrorType.FileNameInvalidChars  => "File Name Invalid Characters",
        FileImportErrorType.FileNameLeadingSpace  => "File Name Leading Space",
        FileImportErrorType.FileNameMismatch      => "File Name Mismatch",
        FileImportErrorType.FileNotFound          => "File Not Found",
        FileImportErrorType.InvalidMimeType       => "Invalid MIME Type",
        FileImportErrorType.EmptyFile             => "Empty File",
        FileImportErrorType.DisallowedFileType    => "Disallowed File Type",
        FileImportErrorType.InvalidCountryFormat  => "Invalid Country Format",
        FileImportErrorType.CountryNotFound       => "Country Not Found",
        FileImportErrorType.CountryMappingNotFound => "Country Mapping Not Found",
        FileImportErrorType.InvalidDepartment     => "Invalid Department",
        FileImportErrorType.InvalidBarcode        => "Invalid Barcode",
        FileImportErrorType.InactiveBarcode       => "Inactive Barcode",
        FileImportErrorType.FutureDateNotAllowed  => "Future Date Not Allowed",
        _                                         => ErrorType.ToString()
    };
}
