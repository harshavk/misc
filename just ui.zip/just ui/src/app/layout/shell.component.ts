import {
  Component,
  ChangeDetectionStrategy,
  inject,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router, RouterModule } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';

import { AuthService } from '../core/services/auth.service';
import { Role } from '../core/models/role.enum';

interface NavItem {
  label: string;
  icon: string;
  route: string;
  roles?: Role[]; // if set, only users with any of these roles see it
}

@Component({
  selector: 'app-shell',
  standalone: true,
  imports: [CommonModule, RouterModule, MatIconModule, MatButtonModule],
  templateUrl: './shell.component.html',
  styleUrls: ['./shell.component.scss']
})

export class ShellComponent {
  private readonly auth = inject(AuthService);
  private readonly router = inject(Router);

  // convenience getter for template
  get currentUser() {
    return this.auth.currentUser();
  }

  // nav items mapped to your routes + roles
  private readonly navItems: NavItem[] = [
    { label: 'Dashboard', icon: 'dashboard', route: '/dashboard' },
    { label: 'Onboard', icon: 'playlist_add_check', route: '/onboard' },
    {
      label: 'Employee',
      icon: 'group',
      route: '/employee',
      roles: [Role.Employee, Role.Manager],
    },
    {
      label: 'Manager',
      icon: 'supervisor_account',
      route: '/manager',
      roles: [Role.Manager],
    },
    { label: 'My Buddy', icon: 'chat', route: '/my-buddy' },
    { label: 'Settings', icon: 'settings', route: '/settings' },
  ];

  // only show items user is allowed to see
  get visibleNavItems(): NavItem[] {
    return this.navItems.filter(
      (item) => !item.roles || this.auth.hasAnyRole(item.roles),
    );
  }

  // derive current page title from current URL
  get currentTitle(): string {
    const url = this.router.url;
    const match = this.navItems.find((n) => url.startsWith(n.route));
    return match?.label ?? '';
  }

  onLogout(): void {
    this.auth.logout();
    this.router.navigate(['/login']);
  }
}
