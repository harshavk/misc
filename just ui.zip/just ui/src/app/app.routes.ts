import { Routes } from '@angular/router';
import { authGuard } from './core/guards/auth.guard';
import { roleGuard } from './core/guards/role.guard';
import { Role } from './core/models/role.enum';

export const appRoutes: Routes = [
  {
    path: 'login',
    loadComponent: () =>
      import('./features/auth/login.component').then(m => m.LoginComponent),
  },
  {
    path: '',
    canActivate: [authGuard],
    loadComponent: () =>
      import('./layout/shell.component').then(m => m.ShellComponent),
    children: [
      { path: '', pathMatch: 'full', redirectTo: 'onboard' },
      {
        path: 'onboard',
        loadComponent: () =>
          import('./features/onboard/onboard.component').then(
            m => m.OnboardComponent
          ),
      },
      {
        path: 'dashboard',
        loadComponent: () =>
          import('./features/dashboard/dashboard.component').then(
            m => m.DashboardComponent
          ),
      },
      {
        path: 'employee',
        canActivate: [roleGuard],
        data: { roles: [Role.Employee, Role.Manager] },
        loadComponent: () =>
          import('./features/employee/employee.component').then(
            m => m.EmployeeComponent
          ),
      },
      {
        path: 'manager',
        canActivate: [roleGuard],
        data: { roles: [Role.Manager] },
        loadComponent: () =>
          import('./features/manager/manager.component').then(
            m => m.ManagerComponent
          ),
      },
      {
        path: 'settings',
        loadComponent: () =>
          import('./features/settings/settings.component').then(
            m => m.SettingsComponent
          ),
      },
      { path: 'my-buddy', loadComponent: () => import('./features/my-buddy/my-buddy.component').then(m => m.MyBuddyComponent) },
      {
        path: 'forbidden',
        loadComponent: () =>
          import('./features/error/forbidden.component').then(
            m => m.ForbiddenComponent
          ),
      },
      {
        path: '**',
        loadComponent: () =>
          import('./features/error/not-found.component').then(
            m => m.NotFoundComponent
          ),
      },
    ],
  },
  { path: '**', redirectTo: '' },
];
