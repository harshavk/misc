import { Component, ChangeDetectionStrategy, computed, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';
import { AuthService } from '../../core/services/auth.service';

@Component({
  standalone: true,
  selector: 'app-dashboard',
  imports: [CommonModule, MatCardModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <mat-card class="wf-elevate wf-fade-in">
      <mat-card-title>Dashboard</mat-card-title>
      <mat-card-subtitle>
        Overview of your current session.
      </mat-card-subtitle>
      <ng-container *ngIf="user(); else noUser">
        <p><strong>User:</strong> {{ user()?.name }}</p>
        <p><strong>Roles:</strong> {{ user()?.roles?.join(', ') }}</p>
      </ng-container>
      <ng-template #noUser>
        <p>You are not logged in.</p>
      </ng-template>
    </mat-card>
  `,
})
export class DashboardComponent {
  private auth = inject(AuthService);
  user = computed(() => this.auth.currentUser());
}
