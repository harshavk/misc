import { Injectable } from '@angular/core';
import { BehaviorSubject, Subscription } from 'rxjs';
import { MockApiService } from './mock-api.service';
import { MockReposService } from './mock-repos.service';
import { ChatMessage } from '../../../core/models/chat.model';

@Injectable({ providedIn: 'root' })
export class ChatService {
    private messagesSub = new BehaviorSubject<ChatMessage[]>([]);
    messages$ = this.messagesSub.asObservable();

    private typingSub = new BehaviorSubject<boolean>(false);
    typing$ = this.typingSub.asObservable();

    private apiSub: Subscription | null = null;

    constructor(private api: MockApiService, private repos: MockReposService) { }

    pushUserText(text: string) {
        this.push({ author: 'user', type: 'text', text });
        this.callApiForResponse(text);
    }

    pushUserFile(name: string, url: string, mime?: string) {
        this.push({ author: 'user', type: 'file', text: name, file: { name, url, mime } });
        // trigger parse action
        this.callApiForResponse(`parse ${name}`);
    }

    clear() { this.messagesSub.next([]); }

    private callApiForResponse(userText: string) {
        this.typingSub.next(true);
        if (this.apiSub) { this.apiSub.unsubscribe(); this.apiSub = null; }

        this.apiSub = this.api.respondToUser(userText).subscribe({
            next: (item: any) => {
                // item.kind could be hint, text, action
                if (item.kind === 'hint') {
                    this.push({ author: 'agent', type: 'hint', text: item.text });
                    return;
                }
                if (item.kind === 'text') {
                    // replace token {original}
                    const txt = (item.text || '').replace(/\{original\}/g, userText);
                    this.push({ author: 'agent', type: 'text', text: txt });
                    return;
                }
                if (item.kind === 'action') {
                    // handle known actions by calling repos and pushing meta messages
                    this.handleAction(item.action, item.meta, item.original);
                    return;
                }

                // fallback
                this.push({ author: 'agent', type: 'text', text: '...' });
            },
            error: (err) => {
                this.push({ author: 'agent', type: 'text', text: 'Sorry, something went wrong.' });
                this.typingSub.next(false);
            },
            complete: () => {
                this.typingSub.next(false);
                if (this.apiSub) { this.apiSub.unsubscribe(); this.apiSub = null; }
            }
        });
    }

    private handleAction(action: string, meta: any, original: string) {
        switch (action) {
            case 'generatePlan':
                {
                    const role = (meta?.roleFrom) ?? this.extractRoleFromText(original) ?? 'Engineer';
                    this.repos.generateOnboardingPlan(role, undefined, undefined).subscribe(plan => {
                        this.push({
                            author: 'agent',
                            type: 'text',
                            text: `Created onboarding plan for role: ${role}`,
                            meta: { type: 'onboardingPlan', plan }
                        });
                    });
                }
                break;
            case 'recommendRoleAccess':
                {
                    const role = this.extractRoleFromText(original) ?? 'Engineer';
                    this.repos.recommendRoleAccess(role).subscribe(items => {
                        this.push({
                            author: 'agent',
                            type: 'text',
                            text: `Recommended access for role: ${role}`,
                            meta: { type: 'roleAccess', items }
                        });
                    });
                }
                break;
            case 'buildCloudPc':
                {
                    const employee = { name: 'New Hire', role: this.extractRoleFromText(original) ?? 'Engineer', startDate: undefined };
                    this.repos.buildCloudPcRequest(employee).subscribe(cp => {
                        this.push({
                            author: 'agent',
                            type: 'text',
                            text: 'Cloud PC draft created',
                            meta: { type: 'cloudPc', cp }
                        });
                    });
                }
                break;
            case 'parseDocument':
                {
                    // In this mock flow we assume original carries filename; repos.parseDocument accepts url or blob
                    this.repos.parseDocument(original).subscribe(parsed => {
                        this.push({
                            author: 'agent',
                            type: 'text',
                            text: `Parsed document: ${parsed.extracted.name} — ${parsed.extracted.role}`,
                            meta: { type: 'parsedDocument', parsed }
                        });
                    });
                }
                break;

            default:
                this.push({ author: 'agent', type: 'text', text: `Action ${action} not implemented in mock.` });
        }
    }

    private extractRoleFromText(text: string): string | undefined {
        // naive extraction: look for common role words — can be improved later
        const candidates = ['engineer', 'backend', 'frontend', 'dev', 'analyst', 'manager', 'sre', 'designer'];
        const t = (text || '').toLowerCase();
        for (const c of candidates) if (t.includes(c)) return c[0].toUpperCase() + c.slice(1);
        return undefined;
    }

    private push(msg: Partial<ChatMessage>) {
        const next = [...this.messagesSub.value, this.normalize(msg)];
        this.messagesSub.next(next);
    }

    private normalize(m: Partial<ChatMessage>) {
        return {
            id: m.id ?? this.generateId(),
            author: m.author ?? 'agent',
            authorDisplay: m.author === 'user' ? 'You' : 'Buddy',
            type: m.type ?? 'text',
            text: m.text ?? '',
            time: m.time ?? Date.now(),
            file: m.file,
            meta: m.meta ?? null
        } as ChatMessage;
    }

    private generateId(): string {
        return (crypto && (crypto as any).randomUUID) ? (crypto as any).randomUUID() : Math.random().toString(36).substring(2);
    }
}
