import { Injectable } from '@angular/core';
import { Observable, from, timer } from 'rxjs';
import { concatMap, map } from 'rxjs/operators';

// simple in-memory rules — you can later replace with assets/chat-rules.json
const RULES = [
    {
        id: 'rule_checklist',
        match: { type: 'contains', value: 'checklist' },
        response: [
            { kind: 'hint', text: 'Preparing the checklist...' },
            { kind: 'action', action: 'generatePlan', meta: { roleFrom: 'Engineer' } },
        ]
    },
    {
        id: 'rule_role_access',
        match: { type: 'contains', value: 'access' },
        response: [
            { kind: 'hint', text: 'Looking up recommended access...' },
            { kind: 'action', action: 'recommendRoleAccess', meta: {} }
        ]
    },
    {
        id: 'rule_cloudpc',
        match: { type: 'contains', value: 'cloud pc' },
        response: [
            { kind: 'hint', text: 'Building Cloud PC draft...' },
            { kind: 'action', action: 'buildCloudPc', meta: {} }
        ]
    },
    {
        id: 'rule_parse',
        match: { type: 'contains', value: 'parse' },
        response: [
            { kind: 'hint', text: 'Parsing uploaded document...' },
            { kind: 'action', action: 'parseDocument', meta: {} }
        ]
    },
    {
        id: 'rule_default',
        match: { type: 'always', value: '' },
        response: [
            { kind: 'hint', text: 'Buddy is thinking...' },
            { kind: 'text', text: 'I got your message: "{original}". Try: "show checklist", "what access", "request cloud pc".' }
        ]
    }
];

@Injectable({ providedIn: 'root' })
export class MockApiService {
    private defaultDelay = 300;

    respondToUser(rawText: string): Observable<any> {
        const rule = this.pickRule(rawText);
        const seq = (rule.response || []).map(r => {
            // copy and attach original for token replacement
            return { ...r, original: rawText };
        });

        // stream sequence with small incrementing delays
        return from(seq).pipe(
            concatMap((item, idx) => timer(this.defaultDelay + idx * 300).pipe(map(() => item)))
        );
    }

    private pickRule(text: string) {
        const t = (text || '').toLowerCase();
        // priority: contains -> always
        for (const r of RULES) {
            if (r.match.type === 'contains' && t.includes(r.match.value.toLowerCase())) return r;
        }
        return RULES.find(r => r.match.type === 'always')!;
    }
}
