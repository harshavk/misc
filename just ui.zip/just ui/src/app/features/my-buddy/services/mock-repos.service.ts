import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';
import {
    OnboardingPlan,
    RoleAccessItem,
    CloudPcRequest,
    Ticket
} from '../../../core/models/chat.model';

import { EmailDraft } from '../../../core/models/email.model';

@Injectable({ providedIn: 'root' })
export class MockReposService {
    private rndId(prefix = '') { return prefix + Math.random().toString(36).slice(2, 9); }
    private simDelay<T>(ms = 350) {
        return (src: T): Observable<T> => of(src).pipe(delay(ms));
    }

    generateOnboardingPlan(role: string, name?: string, startDate?: string): Observable<OnboardingPlan> {
        const plan: OnboardingPlan = {
            id: this.rndId('plan-'),
            employee: { name: name ?? 'New Hire', role, startDate },
            tasks: [
                { id: this.rndId('t-'), title: 'Send welcome email', owner: 'manager', dueDate: startDate, status: 'open' },
                { id: this.rndId('t-'), title: 'Create Azure AD account', owner: 'it', dueDate: startDate, status: 'open' },
                { id: this.rndId('t-'), title: 'Request Cloud PC', owner: 'it', dueDate: startDate, status: 'open' },
                { id: this.rndId('t-'), title: 'Assign Buddy', owner: 'manager', dueDate: startDate, status: 'open' },
                { id: this.rndId('t-'), title: 'Enroll mandatory trainings', owner: 'hr', dueDate: startDate, status: 'open' }
            ],
            createdAt: new Date().toISOString()
        };
        return this.simDelay<OnboardingPlan>(700)(plan);
    }

    recommendRoleAccess(role: string): Observable<RoleAccessItem[]> {
        const items: RoleAccessItem[] = [
            { system: 'Azure AD', group: `${role}-default`, justification: 'base access', approver: 'it-lead@example.com', required: true },
            { system: 'GitHub', group: role.toLowerCase().includes('engineer') ? 'repo-write' : 'repo-read', justification: 'code access', approver: 'dev-lead@example.com', required: role.toLowerCase().includes('engineer') },
            { system: 'Confluence', group: 'team-docs', justification: 'documentation', approver: 'manager@example.com', required: true }
        ];
        return this.simDelay<RoleAccessItem[]>(450)(items);
    }

    buildCloudPcRequest(employee: { name: string; role: string; email?: string; startDate?: string }, spec?: any): Observable<CloudPcRequest> {
        const payload = {
            employee,
            spec: spec ?? { image: 'Windows-11-Dev', size: 'Standard_DS3_v2', software: ['VSCode', 'Dotnet8', 'Chrome'] },
            metadata: { urgency: 'normal' }
        };
        const req: CloudPcRequest = { requestId: this.rndId('cp-'), status: 'draft', payload };
        return this.simDelay<CloudPcRequest>(500)(req);
    }


    createTicket(summary: string, details: any): Observable<Ticket> {
        const t: Ticket = {
            ticketId: this.rndId('T-'),
            status: 'open',
            summary,
            assignee: 'it-queue',
            link: `https://mocktickets.local/${this.rndId('T-')}`
        };

        return this.simDelay<Ticket>(350)(t);
    }

    parseDocument(fileUrlOrBlob: string | Blob): Observable<any> {
        const parsed = {
            type: 'resume',
            extracted: { name: 'Alice Developer', role: 'Software Engineer', startDate: new Date(Date.now() + 7 * 24 * 3600 * 1000).toISOString().split('T')[0], email: 'alice@example.com' },
            textSnippet: 'Experienced backend engineer with 6 years...'
        };
        return this.simDelay(700)(parsed);
    }

    createWelcomeEmailDraft(employee: { name: string; role: string; startDate?: string; manager?: string; email?: string }): Observable<EmailDraft> {
        const safeLocalPart = (employee.name ?? 'new').trim().toLowerCase().replace(/\s+/g, '.').replace(/[^a-z0-9._-]/g, '') || 'new';
        const to = employee.email ?? `${safeLocalPart}@example.com`;
        const start = employee.startDate ?? 'TBD';

        const draft: EmailDraft = {
            subject: `Welcome to Company — ${employee.name}`,
            body: `Hi ${employee.name},\n\nWelcome to the ${employee.role} team. Your start date is ${start}.\n\nBest,\n${employee.manager ?? 'Your Manager'}`,
            to
        };

        return this.simDelay<EmailDraft>(250)(draft);
    }



    saveAudit(entry: any) {
        return this.simDelay(200)({ ok: true, savedAt: new Date().toISOString() });
    }


}
