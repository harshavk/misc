import { Component, ChangeDetectionStrategy, inject, OnInit, OnDestroy, ViewChild, ElementRef } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormBuilder, ReactiveFormsModule } from '@angular/forms';
import { Subject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { ChatService } from '../my-buddy/services/chat.service';
import { ChatMessage } from '../../core/models/chat.model';
import { MockReposService } from '../my-buddy/services/mock-repos.service';

import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatCardModule } from '@angular/material/card';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatTooltipModule } from '@angular/material/tooltip';

@Component({
    standalone: true,
    selector: 'app-my-buddy',
    imports: [
        CommonModule,
        ReactiveFormsModule,
        MatIconModule,
        MatButtonModule,
        MatInputModule,
        MatCardModule,
        MatProgressSpinnerModule,
        MatTooltipModule
    ],
    changeDetection: ChangeDetectionStrategy.OnPush,
    template: `
  <div class="mybuddy-shell">
    <mat-card class="mybuddy-card" role="region" aria-label="My Buddy Chat">
      <header class="mb-header">
        <div class="title">
          <div class="wf-logo-box">WF</div>
          <div class="title-text">
            <div class="main">My Buddy</div>
            <div class="sub">AI assistant for onboarding</div>
          </div>
        </div>
      </header>

      <section class="mb-body" #scrollHost>
        <div class="messages">
          <ng-container *ngFor="let m of messages">
            <div class="msg-row" [class.user]="m.author==='user'" [class.agent]="m.author!=='user'">
              <div class="bubble">
                <div class="meta">
                  <span class="author">{{ m.authorDisplay }}</span>
                  <span class="time" aria-hidden="true">{{ m.time | date:'shortTime' }}</span>
                </div>

                <div class="content">
                  <ng-container [ngSwitch]="m.type">
                    <div *ngSwitchCase="'text'">{{ m.text }}</div>
                    <div *ngSwitchCase="'hint'"><small>{{ m.text }}</small></div>

                    <!-- Rich meta-driven rendering -->
                    <div *ngIf="m.meta?.type === 'onboardingPlan'" class="card">
                      <div class="card-head">
                        <strong>Onboarding Plan</strong>
                        <small>for {{ m.meta.plan.employee.role || m.meta.plan.employee.name }}</small>
                      </div>
                      <div class="plan-tasks">
                        <div *ngFor="let t of m.meta.plan.tasks" class="task-row">
                          <div>{{ t.title }}</div>
                          <div class="task-meta">{{ t.owner }} • {{ t.dueDate || 'due: TBD' }}</div>
                        </div>
                      </div>
                      <div class="card-actions">
                        <button mat-stroked-button (click)="createTickets(m.meta.plan)">Create Tickets</button>
                        <button mat-stroked-button (click)="sendWelcomeEmail(m.meta.plan)">Draft Welcome Email</button>
                        <button mat-stroked-button (click)="exportJson(m.meta.plan)">Export JSON</button>
                      </div>
                    </div>

                    <div *ngIf="m.meta?.type === 'roleAccess'" class="card">
                      <div><strong>Recommended Access</strong></div>
                      <div *ngFor="let a of m.meta.items" class="access-row">
                        <div>{{ a.system }} — {{ a.group }}</div>
                        <div class="small">{{ a.justification }} • Approver: {{ a.approver }}</div>
                      </div>
                      <div class="card-actions">
                        <button mat-stroked-button (click)="requestSelectedAccess(m.meta.items)">Request Selected</button>
                      </div>
                    </div>

                    <div *ngIf="m.meta?.type === 'cloudPc'" class="card">
                      <div><strong>Cloud PC Draft</strong></div>
                      <pre style="white-space:pre-wrap">{{ m.meta.cp | json }}</pre>
                      <div class="card-actions">
                        <button mat-stroked-button (click)="submitCloudPc(m.meta.cp)">Submit Request</button>
                      </div>
                    </div>

                    <div *ngIf="m.meta?.type === 'parsedDocument'" class="card">
                      <div><strong>Parsed Document</strong></div>
                      <div>Name: {{ m.meta.parsed.extracted.name }}</div>
                      <div>Role: {{ m.meta.parsed.extracted.role }}</div>
                      <div>StartDate: {{ m.meta.parsed.extracted.startDate }}</div>
                      <div class="card-actions">
                        <button mat-stroked-button (click)="createPlanFromParsed(m.meta.parsed)">Create Plan</button>
                      </div>
                    </div>

                  </ng-container>
                </div>
              </div>
            </div>
          </ng-container>

          <div class="typing" *ngIf="isTyping">
            <mat-progress-spinner diameter="16" mode="indeterminate"></mat-progress-spinner>
            <span>Buddy is typing…</span>
          </div>
        </div>
      </section>

      <footer class="mb-footer">
        <form [formGroup]="form" class="input-row" (ngSubmit)="onSend()">
          <mat-form-field appearance="outline" class="input-field">
            <input matInput placeholder="Ask My Buddy anything..." formControlName="message" />
          </mat-form-field>

          <button mat-icon-button type="button" (click)="attachSample()" matTooltip="Attach sample file">
            <mat-icon>attach_file</mat-icon>
          </button>

          <button mat-flat-button color="primary" [disabled]="sending || (form.value.message||'').trim()===''" type="submit">
            <mat-icon *ngIf="!sending">send</mat-icon>
            <mat-progress-spinner *ngIf="sending" diameter="18" mode="indeterminate"></mat-progress-spinner>
          </button>
        </form>
      </footer>
    </mat-card>
  </div>
  `,
    styles: [`
    :host { display:block; padding: 16px; }
    .mybuddy-card { max-width: 1000px; margin: 0 auto; height: 72vh; display:flex; flex-direction:column; }
    .mb-body { flex:1; overflow:auto; padding:16px; background: linear-gradient(#fff,#fafafa); }
    .messages { display:flex; flex-direction:column; gap:12px; }
    .bubble { max-width:64%; background:#fff; padding:10px 12px; border-radius:12px; box-shadow:0 6px 18px rgba(15,23,42,0.06); position:relative; }
    .msg-row.user { justify-content:flex-end; }
    .msg-row.agent { justify-content:flex-start; }
    .meta { display:flex; gap:8px; align-items:center; font-size:0.75rem; color:#6b7280; margin-bottom:6px; }
    .input-row { display:flex; gap:8px; align-items:center; padding:12px 16px; border-top:1px solid #eee; }
    .input-field { flex:1; }
    .card { border:1px solid #eee; padding:8px; border-radius:8px; background:#fbfbff; margin-top:6px; }
    .card-head { display:flex; justify-content:space-between; align-items:center; margin-bottom:6px; }
    .plan-tasks .task-row { display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px dashed #efefef; }
    .card-actions { display:flex; gap:8px; margin-top:8px; }
    .access-row { padding:6px 0; border-bottom:1px dashed #efefef; }
  `]
})
export class MyBuddyComponent implements OnInit, OnDestroy {
    private fb = inject(FormBuilder);
    private chat = inject(ChatService);
    private repos = inject(MockReposService);
    private destroy$ = new Subject<void>();

    form = this.fb.group({ message: [''] });
    messages: ChatMessage[] = [];
    isTyping = false;
    sending = false;

    @ViewChild('scrollHost', { static: true }) scrollHost!: ElementRef<HTMLElement>;

    ngOnInit(): void {
        this.chat.messages$.pipe(takeUntil(this.destroy$)).subscribe(m => { this.messages = m; this.scrollToBottom(); });
        this.chat.typing$.pipe(takeUntil(this.destroy$)).subscribe(t => this.isTyping = t);

        // seed welcome
        this.chat.clear();
        this.chat['pushUserText'] === undefined; // noop for lint
        // push initial agent greeting
        (this as any).chat['pushUserText']; // noop
        // directly push one agent welcome message
        (this.chat as any)['push']?.({
            author: 'agent', type: 'text', text: "Hi — I'm your Buddy. Try: 'show checklist', 'what access', 'request cloud pc'"
        } as any);
    }

    ngOnDestroy(): void {
        this.destroy$.next();
        this.destroy$.complete();
    }

    onSend(): void {
        const txt = (this.form.value.message || '').trim();
        if (!txt) return;
        this.sending = true;
        this.chat.pushUserText(txt);
        this.form.reset();
        setTimeout(() => this.sending = false, 600);
    }

    attachSample() {
        // demo attach: push a fake file URL and let parser action run
        const sampleUrl = '/assets/files/welcome.docx';
        this.chat.pushUserFile('welcome.docx', sampleUrl, 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    }

    // UI actions for meta cards
    createTickets(plan: any) {
        // call repo directly for demo and push result into chat
        plan.tasks.forEach((t: any) => {
            this.repos.createTicket(t.title, t).subscribe(ticket => {
                this.chat.pushUserText(`Created ticket ${ticket.ticketId} for '${t.title}' (mock)`);
            });
        });
    }

    sendWelcomeEmail(plan: any) {
        const employee = plan.employee || { name: 'New Hire', role: plan.employee?.role };
        this.repos.createWelcomeEmailDraft(employee).subscribe(draft => {
            this.chat.pushUserText(`Drafted welcome email: "${draft.subject}"`);
            // push a chat message with the draft content
            (this.chat as any).push({
                author: 'agent',
                type: 'text',
                text: draft.body,
                meta: { type: 'emailDraft', draft }
            });
        });
    }

    exportJson(plan: any) {
        const json = JSON.stringify(plan, null, 2);
        const blob = new Blob([json], { type: 'application/json' });
        const url = URL.createObjectURL(blob);
        // push as downloadable file message
        (this.chat as any).push({
            author: 'agent', type: 'file', text: `${plan.id}.json`, file: { name: `${plan.id}.json`, url, mime: 'application/json' }
        });
        setTimeout(() => URL.revokeObjectURL(url), 60000);
    }

    requestSelectedAccess(items: any[]) {
        // For demo create a single ticket summarizing access
        const summary = `Access request: ${items.map(i => i.group).join(', ')}`;
        this.repos.createTicket(summary, { items }).subscribe(ticket => {
            this.chat.pushUserText(`Created access request ticket ${ticket.ticketId} (mock)`);
        });
    }

    submitCloudPc(cp: any) {
        // simulate submit by creating ticket
        this.repos.createTicket('Cloud PC request', cp).subscribe(ticket => {
            this.chat.pushUserText(`Submitted Cloud PC request. Ticket: ${ticket.ticketId}`);
        });
    }

    createPlanFromParsed(parsed: any) {
        const role = parsed.extracted.role ?? 'Engineer';
        this.repos.generateOnboardingPlan(role, parsed.extracted.name, parsed.extracted.startDate).subscribe(plan => {
            (this.chat as any).push({
                author: 'agent',
                type: 'text',
                text: `Onboarding plan created from document for ${parsed.extracted.name}`,
                meta: { type: 'onboardingPlan', plan }
            });
        });
    }

    private scrollToBottom() {
        try {
            const el = this.scrollHost?.nativeElement;
            if (el) el.scrollTop = el.scrollHeight;
        } catch (e) { }
    }
}
