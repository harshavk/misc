import {
  Component,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  inject,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import {
  FormBuilder,
  FormGroup,
  ReactiveFormsModule,
  Validators,
} from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import { finalize } from 'rxjs';

import { AuthService } from '../../core/services/auth.service';
import { AuthApiService } from '../../core/services/auth-api.service';

import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatProgressBarModule } from '@angular/material/progress-bar';

@Component({
  standalone: true,
  selector: 'app-login',
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatButtonModule,
    MatInputModule,
    MatFormFieldModule,
    MatProgressBarModule,
  ],
  changeDetection: ChangeDetectionStrategy.Default,
  template: `
    <div class="login-container">
      <div class="login-card">
        <!-- LEFT HALF -->
        <div class="login-left">
          <div class="left-top">
            <div class="wf-logo-lockup">
              <div class="wf-logo-box">WF</div>
              <div class="wf-logo-text">
                <div class="brand">WellsFargo</div>
                <div class="product">Onboard Assistant</div>
              </div>
            </div>
          </div>

          <div class="left-content">
            <h1 class="welcome">Welcome</h1>
            <p class="subtitle">Sign in to continue</p>
          </div>
        </div>

        <!-- RIGHT HALF -->
        <div class="login-right">
          <h2 class="title">Login</h2>

          <!-- ERROR BANNER -->
          <div class="error-banner" *ngIf="loginError">
            <span class="error-dot"></span>
            <span>{{ loginError }}</span>
          </div>

          <form
            [formGroup]="form"
            (ngSubmit)="onSubmit()"
            class="form"
            autocomplete="off"
            autocapitalize="off"
            spellcheck="false"
          >
            <!-- USER ID -->
            <mat-form-field appearance="outline" class="field">
              <mat-label>User ID</mat-label>
              <input
                matInput
                formControlName="userId"
                autocomplete="off"
                autocorrect="off"
                autocapitalize="off"
                spellcheck="false"
              />
              <mat-error *ngIf="userIdControl.hasError('required')">
                User ID is required
              </mat-error>
            </mat-form-field>

            <!-- PASSWORD -->
            <mat-form-field appearance="outline" class="field">
              <mat-label>Password</mat-label>
              <input
                matInput
                type="password"
                formControlName="password"
                autocomplete="new-password"
                autocorrect="off"
                autocapitalize="off"
                spellcheck="false"
              />
              <mat-error *ngIf="passwordControl.hasError('required')">
                Password is required
              </mat-error>
            </mat-form-field>

            <button
              mat-flat-button
              color="primary"
              class="login-btn"
              [disabled]="isSubmitting || form.invalid"
              type="submit"
            >
              Login
            </button>
          </form>
        </div>

        <!-- GOLDEN BOTTOM LOADER FOR RIGHT PANEL -->
        <div class="login-right-loader" *ngIf="isSubmitting">
          <mat-progress-bar mode="indeterminate"></mat-progress-bar>
        </div>
      </div>
    </div>
  `,
  styles: [
    `
      .login-container {
        height: 100vh;
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: #f4f4f6;
        padding: 16px;
      }

      .login-card {
        width: 760px;
        height: 440px;
        display: flex;
        border-radius: 28px;
        overflow: hidden;
        background-color: #ffffff;
        box-shadow: 0 18px 40px rgba(15, 23, 42, 0.18);
        position: relative;
      }

      /* LEFT HALF – WF gradient panel */
      .login-left {
        width: 45%;
        background: linear-gradient(180deg, #e52b32 0%, #b01b25 100%);
        border-right: 4px solid #ffcd41;
        color: #ffffff;
        padding: 28px 26px;
        display: flex;
        flex-direction: column;
      }

      .left-top {
        display: flex;
        justify-content: flex-start;
      }

      .wf-logo-lockup {
        display: inline-flex;
        align-items: center;
        gap: 10px;
      }

      .wf-logo-box {
        width: 32px;
        height: 32px;
        border-radius: 8px;
        background-color: #ffcd41;
        display: flex;
        align-items: center;
        justify-content: center;
        font-weight: 700;
        font-size: 0.85rem;
        color: #b01b25;
      }

      .wf-logo-text .brand {
        font-size: 0.9rem;
        font-weight: 600;
        letter-spacing: 0.04em;
      }

      .wf-logo-text .product {
        font-size: 0.75rem;
        opacity: 0.9;
      }

      .left-content {
        flex: 1;
        display: flex;
        flex-direction: column;
        justify-content: center;
      }

      .welcome {
        margin: 0 0 8px;
        font-size: 2rem;
        font-weight: 600;
      }

      .subtitle {
        margin: 0;
        font-size: 0.95rem;
        opacity: 0.92;
      }

      /* RIGHT HALF – Form */
      .login-right {
        width: 55%;
        padding: 32px 34px;
        display: flex;
        flex-direction: column;
        justify-content: center;
        background-color: #ffffff;
        color: #333333;
      }

      .title {
        margin: 0 0 16px;
        font-size: 1.45rem;
        font-weight: 600;
      }

      .form {
        display: flex;
        flex-direction: column;
        gap: 18px;
      }

      .field {
        width: 100%;
      }

      .field .mat-mdc-text-field-wrapper {
        border-radius: 14px;
      }

      .login-btn {
        margin-top: 8px;
        border-radius: 999px;
        padding: 10px 0;
        font-size: 0.98rem;
        font-weight: 600;
        background-color: #d71e28 !important;
        color: #ffffff !important;
      }

      .login-btn:hover {
        background-color: #b01b25 !important;
      }

      /* Error banner */
      .error-banner {
        display: flex;
        align-items: center;
        gap: 8px;
        background-color: #fee2e2;
        color: #b91c1c;
        border: 1px solid #fecaca;
        border-radius: 999px;
        padding: 6px 12px;
        font-size: 0.8rem;
        margin-bottom: 12px;
      }

      .error-dot {
        width: 8px;
        height: 8px;
        border-radius: 50%;
        background-color: #dc2626;
      }

      /* Golden bottom loader aligned with right panel */
      .login-right-loader {
        position: absolute;
        bottom: 0;
        right: 0;
        width: 55%;
        padding: 0;
      }

      .login-right-loader mat-progress-bar {
        height: 2px;
        border-radius: 999px;
        animation: wfFadeIn 0.25s ease-out;
      }

      /* WF gold color for the moving bar */
      .login-right-loader .mdc-linear-progress__bar-inner {
        border-color: #ffcd41 !important;
      }

      /* Subtle gold track */
      .login-right-loader .mdc-linear-progress__buffer-bar {
        background-color: rgba(255, 205, 65, 0.25) !important;
      }

      .login-right-loader .mdc-linear-progress {
        background-color: transparent !important;
      }

      @keyframes wfFadeIn {
        from {
          opacity: 0;
          transform: translateY(2px);
        }
        to {
          opacity: 1;
          transform: translateY(0);
        }
      }
    `,
  ],
})
export class LoginComponent {
  private readonly fb = inject(FormBuilder);
  private readonly auth = inject(AuthService);
  private readonly api = inject(AuthApiService);
  private readonly router = inject(Router);
  private readonly route = inject(ActivatedRoute);
  private readonly cdr = inject(ChangeDetectorRef);

  isSubmitting = false;
  loginError: string | null = null;

  readonly form: FormGroup = this.fb.group({
    userId: ['', Validators.required],
    password: ['', Validators.required],
  });

  get userIdControl() {
    return this.form.get('userId')!;
  }

  get passwordControl() {
    return this.form.get('password')!;
  }

  onSubmit(): void {
    if (this.isSubmitting) return;

    if (this.form.invalid) {
      this.form.markAllAsTouched();
      return;
    }

    this.setSubmitting(true);
    this.setLoginError(null);

    const { userId, password } = this.form.value;

    this.api
      .login({ userId: userId!, password: password! })
      .pipe(finalize(() => this.setSubmitting(false)))
      .subscribe({
        next: (response) => {
          if (!response.success) {
            this.handleInvalidCredentials();
            return;
          }

          this.auth.login(response.displayName, response.roles);

          const returnUrl =
            this.route.snapshot.queryParamMap.get('returnUrl') || '/';
          this.router.navigateByUrl(returnUrl);
        },
        error: () => {
          this.handleInvalidCredentials();
        },
      });
  }

  // ---- helpers -------------------------------------------------------------

  private setSubmitting(value: boolean): void {
    this.isSubmitting = value;
    this.cdr.markForCheck();
  }

  private setLoginError(message: string | null): void {
    this.loginError = message;
    this.cdr.markForCheck();
  }

  private handleInvalidCredentials(): void {
    this.setLoginError(
      'Invalid credentials. Please check your User ID and password.'
    );
  }
}
