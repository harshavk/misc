import { Component, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';

@Component({
  standalone: true,
  selector: 'app-settings',
  imports: [CommonModule, MatCardModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <mat-card class="wf-elevate wf-fade-in">
      <mat-card-title>Settings</mat-card-title>
      <mat-card-subtitle>
        Application settings.
      </mat-card-subtitle>
      <p>
        Add notification preferences, profile and other settings here later.
      </p>
    </mat-card>
  `,
})
export class SettingsComponent {}
