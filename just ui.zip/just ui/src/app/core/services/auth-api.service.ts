import { Injectable } from '@angular/core';
import { Observable, of, delay } from 'rxjs';
import { Role } from '../models/role.enum';
@Injectable({ providedIn: 'root' })
export class AuthApiService {

    login(payload: { userId: string; password: string }): Observable<any> {
        const id = payload.userId.trim().toLowerCase();

        const isPasswordValid = payload.password === 'manager';

        if (!isPasswordValid) {
            return of({ success: false }).pipe(delay(500));
        }

        const isManager = id === 'k059839';

        return of({
            success: true,
            displayName: isManager ? 'Manager User' : 'Employee User',
            roles: isManager ? [Role.Manager, Role.Employee] : [Role.Employee],
        }).pipe(delay(500));
    }
}
