export const environment = {
  production: true,
  aiApi: {
    baseUrl: 'http://localhost:5000/api',
    useMock: false,
    timeoutMs: 20000,
  },
};
