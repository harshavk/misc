import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';

// ✅ DIRECT MATERIAL IMPORTS
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';

import { NotificationItem } from '../../../../core/services/dashboard.service';

@Component({
  selector: 'app-quick-actions',
  standalone: true,
  imports: [CommonModule, MatButtonModule, MatIconModule, MatDividerModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './quick-actions.html',
  styleUrls: ['./quick-actions.css']
})
export class QuickActionsComponent {
  @Input() notifications: NotificationItem[] = [];
  @Input() isManager: boolean = false;

  @Output() actionTrigger = new EventEmitter<string>();
  @Output() clickNotification = new EventEmitter<string>();

  onAction(actionType: string) {
    this.actionTrigger.emit(actionType);
  }

  onNotificationClick(user: string) {
    this.clickNotification.emit(user);
  }
}