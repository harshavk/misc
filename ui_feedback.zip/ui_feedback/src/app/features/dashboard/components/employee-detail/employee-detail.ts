import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';

// ✅ DIRECT MATERIAL IMPORTS
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatDividerModule } from '@angular/material/divider';
import { MatProgressBarModule } from '@angular/material/progress-bar';

import { Employee } from '../../../../core/models/employee';

@Component({
  selector: 'app-employee-detail',
  standalone: true,
  imports: [
    CommonModule,
    MatButtonModule,
    MatIconModule,
    MatDividerModule,
    MatProgressBarModule
  ],
  changeDetection: ChangeDetectionStrategy.OnPush,
  templateUrl: './employee-detail.html',
  styleUrls: ['./employee-detail.css']
})
export class EmployeeDetailComponent {
  @Input() employee!: Employee; // Non-null assertion, we expect this

  @Input() isManager = false;
  @Output() close = new EventEmitter<void>();
  @Output() action = new EventEmitter<string>();

  activeTab = 'pre';

  onClose() {
    this.close.emit();
  }

  onAction(type: string) {
    this.action.emit(type);
  }
}