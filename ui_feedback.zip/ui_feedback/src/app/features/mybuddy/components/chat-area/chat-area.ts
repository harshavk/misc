import {
  Component,
  EventEmitter,
  Input,
  Output,
  ElementRef,
  ViewChild,
  ChangeDetectionStrategy,
  OnChanges,
  SimpleChanges,
  AfterViewInit,
  OnDestroy,
  inject
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { ReactiveFormsModule, FormControl } from '@angular/forms';

// Material Imports
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatChipsModule } from '@angular/material/chips';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatSnackBar } from '@angular/material/snack-bar';

import { ThreadMessage } from '../../../../core/models/ai-thread.models';
import { ActionResult } from '../../../../core/models/ai-search.models';

@Component({
  selector: 'app-chat-area',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatIconModule,
    MatButtonModule,
    MatInputModule,
    MatFormFieldModule,
    MatTooltipModule,
    MatChipsModule,
    MatProgressSpinnerModule
  ],
  templateUrl: './chat-area.html',
  styleUrls: ['./chat-area.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class ChatAreaComponent implements OnChanges, AfterViewInit, OnDestroy {
  private snackBar = inject(MatSnackBar);

  @Input() messages: ThreadMessage[] = [];
  @Input() isTyping = false;
  @Input() isLoading = false;
  @Input() isListening = false;
  @Input() error: string | null = null;
  @Input() helperHint = '';
  @Input() inputStatus = '';
  @Input() queryControl!: FormControl<string>;
  @Input() userName: string = 'Employee';

  @Input() suggestedActions: ActionResult[] = [];
  @Input() isManager: boolean = false;

  @Output() submitQuery = new EventEmitter<void>();
  @Output() toggleMic = new EventEmitter<void>();
  @Output() exportChat = new EventEmitter<void>();

  @Output() contentLinkClick = new EventEmitter<{ msg: ThreadMessage, event: MouseEvent }>();
  @Output() toolPayloadClick = new EventEmitter<{ msg: ThreadMessage, tool: any, event: MouseEvent }>();
  @Output() actionClick = new EventEmitter<string>();
  @Output() messageFeedback = new EventEmitter<{ index: number, type: 'like' | 'dislike' | null }>();

  @ViewChild('scrollContainer') private scrollContainer!: ElementRef;

  // Track if the user is currently "sticking" to the bottom of the chat
  private isNearBottom = true;
  private scrollListener: any;

  readonly capabilities = [
    { label: 'Order new hire equipment', icon: 'laptop_mac', query: 'How do I order a laptop and headset for my new hire?' },
    { label: 'Assign an onboarding buddy', icon: 'group_add', query: 'What is the process to assign a buddy to a new employee?' },
    { label: 'Set goals in Workday', icon: 'flag', query: 'Guide me through setting performance goals in Workday.' },
    { label: 'Request Cloud/LAN Access', icon: 'vpn_key', query: 'How do I request Cloud access and check LAN ID status?' },
    { label: 'View Benefits Summary', icon: 'health_and_safety', query: 'What benefits information should I review with the new hire?' }
  ];

  // ✅ 1. DETECT CHANGES (Instead of AfterViewChecked)
  ngOnChanges(changes: SimpleChanges) {
    if (changes['messages']) {
      const prev = changes['messages'].previousValue || [];
      const curr = changes['messages'].currentValue || [];

      // Case A: User just sent a message (always scroll down)
      const lastMsg = curr[curr.length - 1];
      if (lastMsg?.type === 'human') {
        this.scrollToBottom();
        return;
      }

      // Case B: Initial Load (0 -> N messages)
      if (prev.length === 0 && curr.length > 0) {
        this.scrollToBottom();
        return;
      }

      // Case C: AI is typing or new message arrived
      // Only scroll if user hasn't scrolled up to read history
      if (this.isNearBottom) {
        this.scrollToBottom();
      }
    }
  }

  // ✅ 2. SETUP SCROLL LISTENER
  ngAfterViewInit() {
    if (this.scrollContainer?.nativeElement) {
      this.scrollListener = () => this.checkScrollPosition();
      this.scrollContainer.nativeElement.addEventListener('scroll', this.scrollListener);

      // Initial scroll to bottom
      this.scrollToBottom();
    }
  }

  ngOnDestroy() {
    if (this.scrollContainer?.nativeElement && this.scrollListener) {
      this.scrollContainer.nativeElement.removeEventListener('scroll', this.scrollListener);
    }
  }

  // ✅ 3. TRACK USER SCROLL POSITION
  private checkScrollPosition() {
    const el = this.scrollContainer.nativeElement;
    // Calculate if user is near bottom (within 100px)
    const position = el.scrollTop + el.clientHeight;
    const height = el.scrollHeight;
    this.isNearBottom = position >= height - 100;
  }

  private scrollToBottom(): void {
    // Use setTimeout to ensure the DOM has updated with the new message
    setTimeout(() => {
      try {
        const el = this.scrollContainer.nativeElement;
        el.scrollTop = el.scrollHeight;
        // Reset flag so we stay stuck to bottom
        this.isNearBottom = true;
      } catch (err) { }
    }, 0);
  }

  onKeydownEnter(event: KeyboardEvent): void {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.submitQuery.emit();
    }
  }

  triggerAction(query: string) {
    this.queryControl.setValue(query);
    this.submitQuery.emit();
  }

  trackMessage(index: number, msg: ThreadMessage): string {
    return `${msg.type}-${index}-${msg.content?.slice(0, 20)}`;
  }

  copyToClipboard(content: string) {
    navigator.clipboard.writeText(content).then(() => {
      this.snackBar.open('Copied to clipboard', '', { duration: 1500, verticalPosition: 'top' });
    });
  }

  onFeedback(index: number, type: 'like' | 'dislike') {
    // Toggle logic: if clicking the same icon again, remove feedback (null)
    const current = this.messages[index].feedback;
    const newFeedback = current === type ? null : type;
    this.messageFeedback.emit({ index, type: newFeedback });
  }
}