import { ComponentFixture, TestBed } from '@angular/core/testing';

import { Mybuddy } from './mybuddy';

describe('Mybuddy', () => {
  let component: Mybuddy;
  let fixture: ComponentFixture<Mybuddy>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      imports: [Mybuddy]
    })
    .compileComponents();

    fixture = TestBed.createComponent(Mybuddy);
    component = fixture.componentInstance;
    await fixture.whenStable();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
