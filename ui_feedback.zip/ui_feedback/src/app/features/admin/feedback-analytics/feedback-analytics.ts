import { Component, inject, OnInit, signal, computed } from '@angular/core';
import { CommonModule } from '@angular/common';
import { AiSearchService, FeedbackEntry } from '../../../core/services/ai-search.service';

// Material Imports
import { MatCardModule } from '@angular/material/card';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatTableModule } from '@angular/material/table';
import { MatTooltipModule } from '@angular/material/tooltip';

@Component({
  selector: 'app-feedback-analytics',
  standalone: true,
  imports: [
    CommonModule,
    MatCardModule, MatIconModule, MatButtonModule,
    MatProgressBarModule, MatTableModule, MatTooltipModule
  ],
  template: `
    <div class="analytics-container">
      
      <div class="header">
        <h1>Feedback Analytics</h1>
        <button mat-stroked-button (click)="loadData()">
          <mat-icon>refresh</mat-icon> Refresh
        </button>
      </div>

      <div class="stats-grid">
        <mat-card class="stat-card">
          <div class="stat-value">{{ stats().total }}</div>
          <div class="stat-label">Rated Interactions</div>
        </mat-card>

        <mat-card class="stat-card green-border">
          <div class="stat-value text-green">{{ stats().likes }}</div>
          <div class="stat-label">Likes</div>
        </mat-card>

        <mat-card class="stat-card red-border">
          <div class="stat-value text-red">{{ stats().dislikes }}</div>
          <div class="stat-label">Dislikes</div>
        </mat-card>

        </div>

      <mat-card class="table-card">
        <table mat-table [dataSource]="feedbackData()">

          <ng-container matColumnDef="rating">
            <th mat-header-cell *matHeaderCellDef> Rating </th>
            <td mat-cell *matCellDef="let row">
              <mat-icon [class.text-green]="row.rating === 'like'" 
                        [class.text-red]="row.rating === 'dislike'"
                        [class.text-muted]="!row.rating">
                {{ row.rating === 'like' ? 'thumb_up' : (row.rating === 'dislike' ? 'thumb_down' : 'remove') }}
              </mat-icon>
            </td>
          </ng-container>

          <ng-container matColumnDef="query">
            <th mat-header-cell *matHeaderCellDef> Interaction Context </th>
            <td mat-cell *matCellDef="let row">
              <div class="interaction-cell">
                <div class="user-q">{{ row.query }}</div>
                <div class="ai-a">AI: {{ stripHtml(row.aiResponse) }}</div> 
              </div>
            </td>
          </ng-container>

          <ng-container matColumnDef="user">
            <th mat-header-cell *matHeaderCellDef> User </th>
            <td mat-cell *matCellDef="let row" class="text-muted"> {{ row.user }} </td>
          </ng-container>

          <ng-container matColumnDef="time">
            <th mat-header-cell *matHeaderCellDef> Time </th>
            <td mat-cell *matCellDef="let row" class="text-muted"> {{ row.timestamp | date:'shortDate' }} </td>
          </ng-container>

          <ng-container matColumnDef="actions">
            <th mat-header-cell *matHeaderCellDef> </th>
            <td mat-cell *matCellDef="let row">
              <button mat-icon-button (click)="openDetail(row)" matTooltip="View Full Context">
                <mat-icon>visibility</mat-icon>
              </button>
            </td>
          </ng-container>

          <tr mat-header-row *matHeaderRowDef="displayedColumns"></tr>
          <tr mat-row *matRowDef="let row; columns: displayedColumns;"></tr>
        </table>
        
        @if (feedbackData().length === 0) {
          <div class="empty-state">No feedback recorded yet.</div>
        }
      </mat-card>

    </div>

    @if (viewingEntry(); as entry) {
      <div class="modal-backdrop" (click)="closeDetail()">
        <div class="modal-content" (click)="$event.stopPropagation()">
          
          <div class="modal-header">
            <h2>Feedback Details</h2>
            <button mat-icon-button (click)="closeDetail()"><mat-icon>close</mat-icon></button>
          </div>

          <div class="modal-body">
            <div class="detail-row">
              <span class="label">User Asked:</span>
              <p class="text-query">{{ entry.query }}</p>
            </div>

            <div class="detail-row">
              <span class="label">AI Answered:</span>
              <div class="text-answer custom-scroll" [innerHTML]="entry.aiResponse"></div>
            </div>

            <div class="meta-row">
              <div class="meta-item">
                <span class="label">User:</span> {{ entry.user }}
              </div>
              <div class="meta-item">
                <span class="label">Rating:</span> 
                <span [class.text-green]="entry.rating === 'like'" 
                      [class.text-red]="entry.rating === 'dislike'"
                      style="font-weight: bold; text-transform: uppercase;">
                  {{ entry.rating }}
                </span>
              </div>
            </div>
          </div>

        </div>
      </div>
    }
  `,
  styles: [`
    /* ... existing styles ... */
    .analytics-container { padding: 24px; background: #f8f9fa; min-height: 100vh; }
    .header { display: flex; justify-content: space-between; margin-bottom: 24px; }
    h1 { margin: 0; font-family: 'Outfit', sans-serif; }
    .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 16px; margin-bottom: 24px; }
    .stat-card { padding: 16px; text-align: center; }
    .stat-value { font-size: 28px; font-weight: 700; }
    .stat-label { font-size: 13px; color: #666; text-transform: uppercase; letter-spacing: 1px; margin-top: 4px; }
    .text-green { color: #16a34a; }
    .text-red { color: #dc2626; }
    .green-border { border-top: 4px solid #16a34a; }
    .red-border { border-top: 4px solid #dc2626; }
    .table-card { overflow: hidden; }
    table { width: 100%; }
    .interaction-cell { max-width: 400px; padding: 12px 0; }
    .user-q { font-weight: 600; color: #1f2937; margin-bottom: 4px; }
    .ai-a { color: #6b7280; font-size: 13px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
    .text-muted { color: #9ca3af; font-size: 13px; }
    .empty-state { padding: 40px; text-align: center; color: #999; }
    
    .modal-backdrop { position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.4); z-index: 1000; display: flex; align-items: center; justify-content: center; }
    .modal-content { background: white; width: 600px; max-width: 90%; border-radius: 12px; box-shadow: 0 20px 25px -5px rgba(0,0,0,0.1); overflow: hidden; }
    .modal-header { padding: 16px 24px; border-bottom: 1px solid #eee; display: flex; justify-content: space-between; align-items: center; }
    .modal-body { padding: 24px; display: flex; flex-direction: column; gap: 20px; }
    .label { display: block; font-size: 12px; color: #666; text-transform: uppercase; letter-spacing: 0.5px; margin-bottom: 6px; font-weight: 600; }
    .text-query { font-size: 16px; font-weight: 500; color: #111; margin: 0; }
    
    .text-answer { background: #f3f4f6; padding: 16px; border-radius: 8px; color: #374151; line-height: 1.6; font-size: 14px; max-height: 300px; overflow-y: auto; }
    .meta-row { display: flex; gap: 32px; padding-top: 10px; border-top: 1px solid #eee; }

    ::ng-deep .text-answer p { margin-top: 0; margin-bottom: 8px; }
    ::ng-deep .text-answer ul, ::ng-deep .text-answer ol { margin-top: 0; padding-left: 20px; margin-bottom: 8px; }
    ::ng-deep .text-answer li { margin-bottom: 4px; }
    ::ng-deep .text-answer strong { color: #111; font-weight: 600; }
    ::ng-deep .text-answer a { color: #0284c7; text-decoration: none; }
    ::ng-deep .text-answer a:hover { text-decoration: underline; }
  `]
})
export class FeedbackAnalyticsComponent implements OnInit {
  private ai = inject(AiSearchService);

  feedbackData = signal<FeedbackEntry[]>([]);
  viewingEntry = signal<FeedbackEntry | null>(null);

  displayedColumns = ['rating', 'query', 'user', 'time', 'actions'];

  // ✅ SIMPLIFIED STATS (Removed approvalRate)
  stats = computed(() => {
    const data = this.feedbackData();
    const likes = data.filter(d => d.rating === 'like').length;
    const dislikes = data.filter(d => d.rating === 'dislike').length;
    const total = data.length;
    return { total, likes, dislikes };
  });

  ngOnInit() {
    this.loadData();
  }

  loadData() {
    this.ai.getFeedbackAnalytics().subscribe(data => {
      this.feedbackData.set(data);
    });
  }

  openDetail(entry: FeedbackEntry) {
    this.viewingEntry.set(entry);
  }

  closeDetail() {
    this.viewingEntry.set(null);
  }

  stripHtml(html: string): string {
    if (!html) return '';
    const tmp = document.createElement('DIV');
    tmp.innerHTML = html;
    return tmp.textContent || tmp.innerText || '';
  }
}