import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import { delay, map, switchMap, shareReplay } from 'rxjs/operators';

import { environment } from '../../../environments/environment';
import {
    AiThreadRequest,
    AiThreadResponse,
    ThreadMessage
} from '../models/ai-thread.models';
import {
    ActionResult,
    AnswerResult,
    AiSearchResponse,
} from '../models/ai-search.models';
import { MockScenario } from '../models/mock-ai.models';
import { AuthService } from './auth.service'; // ✅ IMPORT AUTH SERVICE

const MOCK_DATA_URL = 'assets/mock-ai-responses.json';

export interface FeedbackEntry {
    id: string;
    query: string;
    aiResponse: string;
    user: string;
    rating: 'like' | 'dislike' | null;
    timestamp: string;
    category: 'HR' | 'IT' | 'General';
}

export interface FeedbackStats {
    total: number;
    likes: number;
    dislikes: number;
    approvalRate: number;
}

@Injectable({ providedIn: 'root' })
export class AiSearchService {
    // ---------------------------------------------------------------------------
    // DEPENDENCIES & STATE
    // ---------------------------------------------------------------------------
    private readonly http = inject(HttpClient);
    private readonly auth = inject(AuthService); // ✅ INJECT AUTH


    // Cache for mock scenarios to avoid repeated HTTP calls
    private mockScenarios$: Observable<MockScenario[]> | null = null;


    // ---------------------------------------------------------------------------
    // 1. CHAT HISTORY (BROWSER STORAGE)
    // ---------------------------------------------------------------------------

    /**
     * Loads chat history for a specific thread from LocalStorage.
     * Returns Observable to mimic an API call.
     */
    loadHistory(threadId: string): Observable<ThreadMessage[]> {
        const userId = this.getCurrentUserId();
        const key = `wf_chat_${userId}_${threadId}`;

        // In the future, you can swap this line for a real API call:
        // return this.http.get<ThreadMessage[]>(`${environment.apiBaseUrl}/chat/history/${threadId}`);

        const raw = localStorage.getItem(key);
        const history = raw ? JSON.parse(raw) : [];

        return of(history).pipe(delay(200)); // Simulate network fetch
    }

    /**
     * Saves the entire message list to LocalStorage.
     */
    saveHistory(threadId: string, messages: ThreadMessage[]): Observable<void> {
        const userId = this.getCurrentUserId();
        const key = `wf_chat_${userId}_${threadId}`;

        localStorage.setItem(key, JSON.stringify(messages));
        return of(void 0);
    }

    /**
     * Clears history for a specific thread.
     */
    clearHistory(threadId: string): Observable<void> {
        const userId = this.getCurrentUserId();
        const key = `wf_chat_${userId}_${threadId}`;

        localStorage.removeItem(key);
        return of(void 0);
    }

    // ---------------------------------------------------------------------------
    // 2. PUBLIC API (SEARCH)
    // ---------------------------------------------------------------------------

    /**
     * Performs an AI search or chat interaction.
     */
    search(
        query: string,
        threadId: string,
        metadata: Record<string, unknown> = { workflow: 'onboarding' },
        actor_id?: string
    ): Observable<AiSearchResponse> {

        // ✅ Use injected ID if not provided explicitly
        const realActorId = actor_id || this.getCurrentUserId();

        const payload: AiThreadRequest = {
            message: query,
            thread_id: threadId,
            metadata,
            actor_id: realActorId,
        };

        // UX: Add artificial delay for "thinking" effect if needed
        const minDelayMs = environment.mockConfig.enableChat ? 1500 : 0;
        const started = Date.now();

        // 1. Determine Source (Mock vs Real)
        const rawResponse$ = environment.mockConfig.enableChat
            ? this.getMockResponse(query, payload)
            : this.http.post<AiThreadResponse>(`${environment.apiBaseUrl}/chat`, payload);

        // 2. Process & Map Response
        return rawResponse$.pipe(
            map((raw) =>
                this.mapToUi(query, raw, environment.mockConfig.enableChat ? 'mock' : 'python-api')
            ),
            switchMap((uiResponse) => {
                // Enforce minimum delay for better UX
                const elapsed = Date.now() - started;
                const remainingDelay = Math.max(0, minDelayMs - elapsed);
                return remainingDelay > 0 ? of(uiResponse).pipe(delay(remainingDelay)) : of(uiResponse);
            })
        );
    }

    isMockMode(): boolean {
        return environment.mockConfig.enableChat;
    }

    // ---------------------------------------------------------------------------
    // 3. ADMIN ANALYTICS (REAL BROWSER STORAGE)
    // ---------------------------------------------------------------------------

    getFeedbackAnalytics(): Observable<FeedbackEntry[]> {
        if (!environment.mockConfig.enableChat) {
            return this.http.get<FeedbackEntry[]>(`${environment.apiBaseUrl}/admin/feedback`);
        }

        const entries: FeedbackEntry[] = [];

        for (let i = 0; i < localStorage.length; i++) {
            const key = localStorage.key(i);

            if (key && key.startsWith('wf_chat_')) {
                try {
                    const parts = key.split('_');
                    const userId = parts[2] || 'Anonymous';
                    const raw = localStorage.getItem(key);
                    const messages: ThreadMessage[] = raw ? JSON.parse(raw) : [];

                    for (let m = 0; m < messages.length; m++) {
                        const msg = messages[m];

                        // ✅ CHANGED: Only process if it is AI AND has Feedback
                        if (msg.type === 'ai' && msg.feedback) {

                            // Find related user query (look backwards)
                            let relatedQuery = 'Unknown context';
                            for (let j = m - 1; j >= 0; j--) {
                                if (messages[j].type === 'human') {
                                    relatedQuery = messages[j].content;
                                    break;
                                }
                            }

                            entries.push({
                                id: `${key}-${m}`,
                                query: relatedQuery,
                                aiResponse: msg.content,
                                user: userId,
                                rating: msg.feedback, // Will never be null now
                                timestamp: msg.timestamp || new Date().toISOString(),
                                category: this.detectCategory(relatedQuery)
                            });
                        }
                    }

                } catch (err) {
                    console.warn('Failed to parse chat thread:', key, err);
                }
            }
        }

        entries.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime());

        return of(entries).pipe(delay(300));
    }

    // ---------------------------------------------------------------------------
    // PRIVATE: HELPERS
    // ---------------------------------------------------------------------------

    private getCurrentUserId(): string {
        return this.auth.currentUser()?.id || 'anonymous';
    }

    // ---------------------------------------------------------------------------
    // PRIVATE: MOCK LOGIC
    // ---------------------------------------------------------------------------
    private detectCategory(query: string): 'HR' | 'IT' | 'General' {
        const q = query.toLowerCase();
        if (q.includes('laptop') || q.includes('vpn') || q.includes('access') || q.includes('wifi') || q.includes('login')) {
            return 'IT';
        }
        if (q.includes('policy') || q.includes('holiday') || q.includes('pay') || q.includes('benefits') || q.includes('leave')) {
            return 'HR';
        }
        return 'General';
    }

    private getMockResponse(query: string, payload: AiThreadRequest): Observable<AiThreadResponse> {
        return this.loadMocks().pipe(
            map((scenarios) => {
                const scenario = this.pickScenario(query, scenarios);
                return this.buildThreadFromScenario(payload, scenario);
            })
        );
    }

    private loadMocks(): Observable<MockScenario[]> {
        if (!this.mockScenarios$) {
            this.mockScenarios$ = this.http.get<MockScenario[]>(MOCK_DATA_URL).pipe(
                shareReplay(1)
            );
        }
        return this.mockScenarios$;
    }

    private pickScenario(query: string, scenarios: MockScenario[]): MockScenario {
        const q = query.toLowerCase();
        const match = scenarios.find((s) =>
            (s.keywords || []).some((k) => q.includes(k.toLowerCase()))
        );
        if (match) return match;
        const fallback = scenarios.find((s) => s.id === 'generic-fallback');
        return fallback || scenarios[0];
    }

    private buildThreadFromScenario(
        req: AiThreadRequest,
        scenario: MockScenario
    ): AiThreadResponse {
        const now = new Date().toISOString();
        const base = scenario.thread;

        const messages: ThreadMessage[] = [
            {
                type: 'human',
                content: req.message,
                tool_call: null,
            },
            ...base.messages.filter((m) => m.type !== 'human'),
        ];

        return {
            reply: base.reply,
            thread_id: req.thread_id || base.thread_id || scenario.id,
            timestamp: base.timestamp || now,
            messages: messages,
        };
    }

    // ---------------------------------------------------------------------------
    // PRIVATE: UI MAPPING (ADAPTER)
    // ---------------------------------------------------------------------------

    private mapToUi(
        query: string,
        raw: AiThreadResponse,
        source: 'mock' | 'python-api'
    ): AiSearchResponse {
        const createdAt = raw.timestamp || new Date().toISOString();

        return {
            id: `${raw.thread_id}:${createdAt}`,
            query,
            createdAt,
            answers: this.extractAnswers(raw),
            actions: this.extractActions(raw),
            meta: {
                latencyMs: 0,
                model: 'thread-api-model',
                source,
            },
            threadId: raw.thread_id,
            historyMessages: raw.messages,
        };
    }

    private extractAnswers(raw: AiThreadResponse): AnswerResult[] {
        const answers: AnswerResult[] = [];
        const aiMessages = raw.messages.filter((m) => m.type === 'ai');

        const looksHtml = (text: string | null | undefined): boolean =>
            !!text && /<\s*(a|p|ul|ol|li|button|strong|em|div|span)\b/i.test(text);

        if (raw.reply && raw.reply.trim().length > 0) {
            answers.push({
                id: 'ans-summary',
                title: 'AI reply',
                content: raw.reply,
                type: 'summary',
                isHtml: looksHtml(raw.reply),
                confidence: 0.9,
                tags: [],
                references: [],
            });
        }

        aiMessages.forEach((m, idx) => {
            const content = m.content || '';
            if (raw.reply && content.trim() === raw.reply.trim()) return;

            answers.push({
                id: `ans-msg-${idx}`,
                title: 'AI reply',
                content,
                type: 'explanation',
                isHtml: looksHtml(content),
                confidence: 0.85,
                tags: [],
                references: [],
            });
        });

        return answers;
    }

    private extractActions(raw: AiThreadResponse): ActionResult[] {
        return raw.messages
            .filter((m) => !!m.tool_call)
            .map((m, idx) => {
                const tc = m.tool_call || {};
                const name = tc.name || tc.action || tc.type || 'Suggested action';
                const description = tc.description || 'Action suggested by the AI.';
                const lowerName = String(name).toLowerCase();
                let category: ActionResult['category'] = 'other';

                if (lowerName.includes('workday')) category = 'hr';
                else if (lowerName.includes('equipment') || lowerName.includes('access')) category = 'access';
                else if (lowerName.includes('email')) category = 'email';
                else if (lowerName.includes('navigate') || lowerName.includes('open')) category = 'navigation';

                return {
                    id: `act-${idx}`,
                    label: name,
                    description,
                    icon: 'bolt',
                    category,
                    primary: idx === 0,
                    confidence: 0.9,
                    payload: tc,
                    requiresConfirmation: true,
                    confirmLabel: 'Execute',
                    url: tc.url,
                    actionType: tc.url ? 'link' : 'workflow',
                };
            });
    }
}