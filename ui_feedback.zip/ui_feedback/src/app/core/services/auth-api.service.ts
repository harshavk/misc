import { inject, Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable, throwError } from 'rxjs';
import { delay, tap } from 'rxjs/operators';

import { environment } from '../../../environments/environment';
import { ApiEndpoints } from '../config/api-endpoints';
import { LoginResponse } from '../models/login-response';

/**
 * Service responsible for handling Authentication API calls.
 * Supports switching between Mock mode (local JSON) and Real API mode via environment config.
 */
@Injectable({ providedIn: 'root' })
export class AuthApiService {
    private readonly http = inject(HttpClient);

    /**
     * Authenticates a user with User ID and Password.
     *
     * @param credentials Object containing `userId` and `password`.
     * @returns Observable of `LoginResponse` containing the token and user profile.
     */
    login(credentials: { userId: string; password: string }): Observable<LoginResponse> {

        // -------------------------------------------------------------------------
        // 1. MOCK MODE (Local JSON)
        // -------------------------------------------------------------------------
        if (environment.mockConfig.enableAuth) {
            let mockFile = '';

            // Hardcoded Mock Credentials for Development
            if (credentials.userId === 'k059839' && credentials.password === 'manager') {
                mockFile = 'assets/data/login-manager.json';
            }
            else if (credentials.userId === 'k059838' && credentials.password === 'employee') {
                mockFile = 'assets/data/login-employee.json';
            }
            else {
                // Simulate 401 Unauthorized for invalid credentials
                return throwError(() => new Error('Invalid User ID or Password'));
            }

            // Fetch the specific mock file
            return this.http.get<LoginResponse>(mockFile).pipe(
                delay(800), // Simulate network latency
                tap(res => console.log(`✅ [Mock Login] Success: Logged in as ${res.role}`))
            );
        }

        // -------------------------------------------------------------------------
        // 2. REAL API MODE
        // -------------------------------------------------------------------------
        else {
            const url = `${environment.apiBaseUrl}${ApiEndpoints.AUTH.LOGIN}`;
            return this.http.post<LoginResponse>(url, credentials);
        }
    }
}