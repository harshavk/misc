import { DASH } from "@angular/cdk/keycodes";

export const ApiEndpoints = {
    AUTH: {
        LOGIN: '/login'
    },
    EMPLOYEES: {
        GET_MANAGED: (id: string) => `/employees/manager/${id}`,
        GET_ALL: '/employees',
        GET_BY_ID: (id: string) => `/employees/${id}`
    },
    CHAT: {
        SEND_MESSAGE: '/chat'
    },
    DASHBOARD: {
        ACTIONS: (id: string) => `/dashboard/actions/${id}`,
        METRICS: (id: string) => `/dashboard/metrics/${id}`,
        NOTIFICATIONS: (id: string) => `/dashboard/notifications/${id}`
    }
};