
using Common.Models;
using Common.Validation.Metadata.Interfaces;
using System.IO;

namespace Common.Validation.Metadata.CommonValidators;

public class FilesValidator : ICommonMetadataValidator
{
    private static readonly string[] AllowedExtensions =
        { ".pdf", ".tif", ".tiff", ".jpg", ".jpeg" };

    public Task ValidateAsync(DocumentImportsModel model, ValidationContext context)
    {
        if (string.IsNullOrWhiteSpace(model.FileName))
            return Task.CompletedTask;

        var ext = Path.GetExtension(model.FileName).ToLowerInvariant();

        if (!AllowedExtensions.Contains(ext))
            context.AddError("File", $"File type '{ext}' is not allowed");

        return Task.CompletedTask;
    }
}
