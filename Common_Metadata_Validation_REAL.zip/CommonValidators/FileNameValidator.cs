
using Common.Models;
using Common.Validation.Metadata.Interfaces;
using System.IO;

namespace Common.Validation.Metadata.CommonValidators;

public class FileNameValidator : ICommonMetadataValidator
{
    private static readonly char[] InvalidChars =
        { '<', '>', ':', '"', '/', '\', '|', '?', '*' };

    public Task ValidateAsync(DocumentImportsModel model, ValidationContext context)
    {
        if (string.IsNullOrWhiteSpace(model.FileName))
        {
            context.AddError("FileName", "File name is required");
            return Task.CompletedTask;
        }

        if (model.FileName.Length > 99)
            context.AddError("FileName", "File name exceeds 99 characters");

        if (model.FileName.IndexOfAny(InvalidChars) >= 0)
            context.AddError("FileName", "File name contains invalid characters");

        if (!Path.HasExtension(model.FileName))
            context.AddError("FileName", "File extension is missing");

        return Task.CompletedTask;
    }
}
