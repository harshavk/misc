
using Common.Models;
using Common.Validation.Metadata.Interfaces;
using System.Text.RegularExpressions;

namespace Common.Validation.Metadata.CommonValidators;

public class BarcodeValidator : ICommonMetadataValidator
{
    private static readonly Regex NumericRegex = new(@"^\d+$");

    public Task ValidateAsync(DocumentImportsModel model, ValidationContext context)
    {
        if (string.IsNullOrWhiteSpace(model.Barcode))
        {
            context.AddError("Barcode", "Barcode is required");
            return Task.CompletedTask;
        }

        if (!NumericRegex.IsMatch(model.Barcode))
            context.AddError("Barcode", "Barcode must be numeric");

        if (model.Barcode.Length < 6 || model.Barcode.Length > 20)
            context.AddError("Barcode", "Barcode length must be between 6 and 20");

        return Task.CompletedTask;
    }
}
