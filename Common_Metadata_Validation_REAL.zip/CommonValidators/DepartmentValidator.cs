
using Common.Models;
using Common.Validation.Metadata.Interfaces;

namespace Common.Validation.Metadata.CommonValidators;

public class DepartmentValidator : ICommonMetadataValidator
{
    public Task ValidateAsync(DocumentImportsModel model, ValidationContext context)
    {
        if (string.IsNullOrWhiteSpace(model.Department) &&
            string.IsNullOrWhiteSpace(model.DepartmentCode))
        {
            context.AddError(
                "Department",
                "Either Department or DepartmentCode must be provided");
        }

        return Task.CompletedTask;
    }
}
