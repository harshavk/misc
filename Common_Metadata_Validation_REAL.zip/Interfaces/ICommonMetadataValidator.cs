
using Common.Models;

namespace Common.Validation.Metadata.Interfaces;

public interface ICommonMetadataValidator
{
    Task ValidateAsync(DocumentImportsModel model, ValidationContext context);
}
