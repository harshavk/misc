
using Common.Models;
using Common.Validation.Metadata.Enums;

namespace Common.Validation.Metadata.Interfaces;

public interface IJobMetadataValidator
{
    IReadOnlyCollection<IngestionJobType> SupportedJobs { get; }

    Task ValidateAsync(DocumentImportsModel model, ValidationContext context);
}
