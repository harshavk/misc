
using Common.Models;
using Common.Validation.Metadata.Enums;
using Common.Validation.Metadata.Interfaces;
using System.Text.RegularExpressions;

namespace Common.Validation.Metadata.JobValidators.Shared;

public class EmployeeNationalEffectiveDateValidator : IJobMetadataValidator
{
    private static readonly Regex ElevenDigitRegex = new(@"^\d{11}$");

    public IReadOnlyCollection<IngestionJobType> SupportedJobs =>
        new[]
        {
            IngestionJobType.Carco,
            IngestionJobType.CarcoOngoing,
            IngestionJobType.Fadv
        };

    public Task ValidateAsync(DocumentImportsModel model, ValidationContext context)
    {
        if (string.IsNullOrWhiteSpace(model.EmployeeId))
            context.AddError("EmployeeId", "Employee ID is required");
        else if (!ElevenDigitRegex.IsMatch(model.EmployeeId))
            context.AddError("EmployeeId", "Employee ID must be exactly 11 digits");

        if (string.IsNullOrWhiteSpace(model.NationalId))
            context.AddError("NationalId", "National ID is required");

        if (model.EffectiveDate.HasValue &&
            model.EffectiveDate.Value.Date > DateTime.UtcNow.Date)
        {
            context.AddError("EffectiveDate", "Effective date cannot be in the future");
        }

        return Task.CompletedTask;
    }
}
