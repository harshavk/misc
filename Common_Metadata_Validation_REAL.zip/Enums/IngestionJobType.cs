
namespace Common.Validation.Metadata.Enums;

public enum IngestionJobType
{
    Carco,
    CarcoOngoing,
    Fadv
}
