
using Common.Models;
using Common.Validation.Metadata.Enums;
using Common.Validation.Metadata.Interfaces;

namespace Common.Validation.Metadata;

public class MetadataValidationService
{
    private readonly IEnumerable<ICommonMetadataValidator> _commonValidators;
    private readonly IEnumerable<IJobMetadataValidator> _jobValidators;

    public MetadataValidationService(
        IEnumerable<ICommonMetadataValidator> commonValidators,
        IEnumerable<IJobMetadataValidator> jobValidators)
    {
        _commonValidators = commonValidators;
        _jobValidators = jobValidators;
    }

    public async Task<(bool IsValid, string StatusMessage)> ValidateAsync(
        DocumentImportsModel model,
        IngestionJobType jobType)
    {
        var context = new ValidationContext();

        foreach (var v in _commonValidators)
            await v.ValidateAsync(model, context);

        foreach (var v in _jobValidators.Where(x => x.SupportedJobs.Contains(jobType)))
            await v.ValidateAsync(model, context);

        return (!context.HasErrors, context.ToStatusMessage());
    }
}
