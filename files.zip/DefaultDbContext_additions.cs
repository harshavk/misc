// ─────────────────────────────────────────────────────────────────────────────
// ADD these two DbSet properties to your existing DefaultDbContext.cs
// Place them alongside your existing DbSet declarations
// ─────────────────────────────────────────────────────────────────────────────

public DbSet<FileImportJob> FileImportJobs { get; set; }
public DbSet<FileImportJobError> FileImportJobErrors { get; set; }

// ─────────────────────────────────────────────────────────────────────────────
// ADD these two lines inside your existing OnModelCreating(ModelBuilder builder)
// Place them alongside your existing modelBuilder.ApplyConfiguration(...) calls
// ─────────────────────────────────────────────────────────────────────────────

modelBuilder.ApplyConfiguration(new FileImportJobConfiguration());
modelBuilder.ApplyConfiguration(new FileImportJobErrorConfiguration());
