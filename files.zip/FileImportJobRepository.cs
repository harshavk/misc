using Common.EntityFramework.Models;
using Common.Enums;
using Microsoft.EntityFrameworkCore;

namespace Common.DataAccess;

public class FileImportJobRepository : GenericRepository<FileImportJob>, IFileImportJobRepository
{
    private readonly DefaultDbContext _dbContext;

    public FileImportJobRepository(DefaultDbContext dbContext) : base(dbContext)
    {
        _dbContext = dbContext;
    }

    public async Task<IEnumerable<FileImportJob>> GetAllAsync()
    {
        return await _dbContext.FileImportJobs
            .OrderByDescending(x => x.UploadedAt)
            .ToListAsync();
    }

    public async Task<FileImportJob?> GetByIdAsync(int id)
    {
        return await _dbContext.FileImportJobs
            .Include(x => x.FileImportJobErrors)
            .FirstOrDefaultAsync(x => x.Id == id);
    }

    public async Task<IEnumerable<FileImportJob>> GetByStatusAsync(FileImportStatus status)
    {
        return await _dbContext.FileImportJobs
            .Where(x => x.Status == status)
            .OrderBy(x => x.UploadedAt)
            .ToListAsync();
    }

    public async Task<FileImportJob?> GetPendingValidationJobAsync()
    {
        return await _dbContext.FileImportJobs
            .Where(x => x.Status == FileImportStatus.Validating)
            .OrderBy(x => x.UploadedAt)
            .FirstOrDefaultAsync();
    }

    public async Task<FileImportJob?> GetPendingIngestionJobAsync()
    {
        return await _dbContext.FileImportJobs
            .Where(x => x.Status == FileImportStatus.Processing)
            .OrderBy(x => x.UploadedAt)
            .FirstOrDefaultAsync();
    }

    public async Task<int> InsertAsync(FileImportJob fileImportJob)
    {
        await _dbContext.FileImportJobs.AddAsync(fileImportJob);
        await _dbContext.SaveChangesAsync();
        return fileImportJob.Id;
    }

    public async Task UpdateStatusAsync(int id, FileImportStatus status)
    {
        FileImportJob? job = await GetJobOrThrowAsync(id);
        job.Status = status;
        await _dbContext.SaveChangesAsync();
    }

    public async Task UpdateProgressAsync(
        int id,
        FileImportStatus status,
        int totalRows,
        int validRows,
        int errorRows)
    {
        FileImportJob? job = await GetJobOrThrowAsync(id);
        job.Status = status;
        job.TotalRows = totalRows;
        job.ValidRows = validRows;
        job.ErrorRows = errorRows;
        await _dbContext.SaveChangesAsync();
    }

    public async Task UpdateJobStartedAsync(int id)
    {
        FileImportJob? job = await GetJobOrThrowAsync(id);
        job.JobStartedAt = DateTime.UtcNow;
        await _dbContext.SaveChangesAsync();
    }

    public async Task UpdateJobCompletedAsync(
        int id,
        FileImportStatus status,
        int totalRows,
        int validRows,
        int errorRows)
    {
        FileImportJob? job = await GetJobOrThrowAsync(id);
        job.Status = status;
        job.TotalRows = totalRows;
        job.ValidRows = validRows;
        job.ErrorRows = errorRows;
        job.JobCompletedAt = DateTime.UtcNow;
        await _dbContext.SaveChangesAsync();
    }

    public async Task UpdateJobFailedAsync(int id, string failureReason)
    {
        FileImportJob? job = await GetJobOrThrowAsync(id);
        job.Status = FileImportStatus.Failed;
        job.FailureReason = failureReason;
        job.JobCompletedAt = DateTime.UtcNow;
        await _dbContext.SaveChangesAsync();
    }

    public async Task UpdateIngestionAsync(int id, string processedBy)
    {
        FileImportJob? job = await GetJobOrThrowAsync(id);
        job.Status = FileImportStatus.Ingested;
        job.ProcessedBy = processedBy;
        job.ProcessedAt = DateTime.UtcNow;
        await _dbContext.SaveChangesAsync();
    }

    public async Task InsertErrorAsync(FileImportJobError error)
    {
        await _dbContext.FileImportJobErrors.AddAsync(error);
        await _dbContext.SaveChangesAsync();
    }

    public async Task InsertErrorsAsync(IEnumerable<FileImportJobError> errors)
    {
        await _dbContext.FileImportJobErrors.AddRangeAsync(errors);
        await _dbContext.SaveChangesAsync();
    }

    public async Task<IEnumerable<FileImportJobError>> GetErrorsByJobIdAsync(int jobId)
    {
        return await _dbContext.FileImportJobErrors
            .Where(x => x.FileImportJobId == jobId)
            .OrderBy(x => x.RowNumber)
            .ToListAsync();
    }

    public async Task<HashSet<int>> GetErrorRowNumbersByJobIdAsync(int jobId)
    {
        List<int> rowNumbers = await _dbContext.FileImportJobErrors
            .Where(x => x.FileImportJobId == jobId)
            .Select(x => x.RowNumber)
            .ToListAsync();

        return [.. rowNumbers];
    }

    private async Task<FileImportJob> GetJobOrThrowAsync(int id)
    {
        FileImportJob? job = await _dbContext.FileImportJobs.FindAsync(id);

        if (job is null)
        {
            throw new InvalidOperationException($"FileImportJob with id {id} not found.");
        }

        return job;
    }
}
