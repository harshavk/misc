using Common.Enums;

namespace Common.EntityFramework.Models;

public class FileImportJob
{
    public int Id { get; set; }
    public string FileName { get; set; } = string.Empty;
    public string SavedFilePath { get; set; } = string.Empty;
    public string Department { get; set; } = string.Empty;
    public string UploadedBy { get; set; } = string.Empty;
    public DateTime UploadedAt { get; set; }
    public FileImportStatus Status { get; set; }
    public int? TotalRows { get; set; }
    public int? ValidRows { get; set; }
    public int? ErrorRows { get; set; }
    public DateTime? JobStartedAt { get; set; }
    public DateTime? JobCompletedAt { get; set; }
    public string? ProcessedBy { get; set; }
    public DateTime? ProcessedAt { get; set; }
    public string? FailureReason { get; set; }

    public virtual ICollection<FileImportJobError> FileImportJobErrors { get; set; }
        = new List<FileImportJobError>();
}
