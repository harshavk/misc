using Common.Enums;

namespace Common.EntityFramework.Models;

public class FileImportJobError
{
    public int Id { get; set; }
    public int FileImportJobId { get; set; }
    public int RowNumber { get; set; }
    public string? EmpId { get; set; }
    public string? NationalId { get; set; }
    public string? FileName { get; set; }
    public string? CaseId { get; set; }
    public FileImportErrorType ErrorType { get; set; }
    public string ErrorMessage { get; set; } = string.Empty;
    public DateTime CreatedAt { get; set; }

    public virtual FileImportJob FileImportJob { get; set; } = null!;
}
