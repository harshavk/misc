namespace Common.Enums;

public enum FileImportErrorType
{
    // EmpId
    InvalidEmpIdFormat,
    EmpIdNotFound,

    // NationalId
    NationalIdRequired,
    NationalIdNotFound,

    // FileName
    FileNameTooLong,
    FileNameInvalidChars,
    FileNameLeadingSpace,
    FileNameMismatch,

    // Physical file
    FileNotFound,
    InvalidMimeType,
    EmptyFile,
    DisallowedFileType,

    // Country
    InvalidCountryFormat,
    CountryNotFound,
    CountryMappingNotFound,

    // Dept
    InvalidDepartment,

    // Barcode
    InvalidBarcode,
    InactiveBarcode,

    // EffectiveDate
    FutureDateNotAllowed
}
