namespace Common.Enums;

public enum FileImportStatus
{
    Uploading,
    Validating,
    Validated,
    Processing,
    Ingested,
    Failed
}
