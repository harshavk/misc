using Common.EntityFramework.Models;
using Common.Enums;

namespace Common.DataAccess;

public interface IFileImportJobRepository
{
    Task<IEnumerable<FileImportJob>> GetAllAsync();

    Task<FileImportJob?> GetByIdAsync(int id);

    Task<IEnumerable<FileImportJob>> GetByStatusAsync(FileImportStatus status);

    Task<FileImportJob?> GetPendingValidationJobAsync();

    Task<FileImportJob?> GetPendingIngestionJobAsync();

    Task<int> InsertAsync(FileImportJob fileImportJob);

    Task UpdateStatusAsync(int id, FileImportStatus status);

    Task UpdateProgressAsync(
        int id,
        FileImportStatus status,
        int totalRows,
        int validRows,
        int errorRows);

    Task UpdateJobStartedAsync(int id);

    Task UpdateJobCompletedAsync(
        int id,
        FileImportStatus status,
        int totalRows,
        int validRows,
        int errorRows);

    Task UpdateJobFailedAsync(int id, string failureReason);

    Task UpdateIngestionAsync(int id, string processedBy);

    Task InsertErrorAsync(FileImportJobError error);

    Task InsertErrorsAsync(IEnumerable<FileImportJobError> errors);

    Task<IEnumerable<FileImportJobError>> GetErrorsByJobIdAsync(int jobId);

    Task<HashSet<int>> GetErrorRowNumbersByJobIdAsync(int jobId);
}
