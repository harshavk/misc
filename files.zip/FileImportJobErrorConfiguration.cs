using Common.EntityFramework.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata.Builders;

namespace Common.EntityFramework.Configurations;

public class FileImportJobErrorConfiguration : IEntityTypeConfiguration<FileImportJobError>
{
    public void Configure(EntityTypeBuilder<FileImportJobError> builder)
    {
        builder.ToTable("FileImportJobErrors");

        builder.HasKey(x => x.Id);

        builder.Property(x => x.Id)
            .UseIdentityColumn();

        builder.Property(x => x.FileImportJobId)
            .IsRequired();

        builder.Property(x => x.RowNumber)
            .IsRequired();

        builder.Property(x => x.EmpId)
            .HasMaxLength(50)
            .IsRequired(false);

        builder.Property(x => x.NationalId)
            .HasMaxLength(50)
            .IsRequired(false);

        builder.Property(x => x.FileName)
            .HasMaxLength(255)
            .IsRequired(false);

        builder.Property(x => x.CaseId)
            .HasMaxLength(50)
            .IsRequired(false);

        builder.Property(x => x.ErrorType)
            .IsRequired()
            .HasConversion<string>()
            .HasMaxLength(100);

        builder.Property(x => x.ErrorMessage)
            .IsRequired()
            .HasMaxLength(500);

        builder.Property(x => x.CreatedAt)
            .IsRequired();

        builder.HasOne(x => x.FileImportJob)
            .WithMany(x => x.FileImportJobErrors)
            .HasForeignKey(x => x.FileImportJobId)
            .OnDelete(DeleteBehavior.Cascade);

        builder.HasIndex(x => x.FileImportJobId)
            .HasDatabaseName("IX_FileImportJobErrors_FileImportJobId");

        builder.HasIndex(x => new { x.FileImportJobId, x.RowNumber })
            .HasDatabaseName("IX_FileImportJobErrors_JobId_RowNumber");
    }
}
