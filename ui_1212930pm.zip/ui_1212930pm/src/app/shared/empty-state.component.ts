import { Component, Input } from '@angular/core';
import { MatIconModule } from '@angular/material/icon';
import { MatCardModule } from '@angular/material/card';

@Component({
  selector: 'app-empty-state',
  standalone: true,
  imports: [MatIconModule, MatCardModule],
  templateUrl: './empty-state.component.html',
  styles: [`.empty-card{padding:24px;text-align:center;color:rgba(0,0,0,0.6)}`]
})
export class EmptyStateComponent {
  @Input() message = 'No items yet.';
}
