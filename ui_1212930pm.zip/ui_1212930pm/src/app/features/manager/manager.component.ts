import { Component, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatCardModule } from '@angular/material/card';

@Component({
  standalone: true,
  selector: 'app-manager',
  imports: [CommonModule, MatCardModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <mat-card class="wf-elevate wf-fade-in">
      <mat-card-title>Manager Area</mat-card-title>
      <mat-card-subtitle>
        Only accessible to users with the manager role.
      </mat-card-subtitle>
      <p>
        Manager dashboards, approvals and reports can go here.
      </p>
    </mat-card>
  `,
})
export class ManagerComponent {}
