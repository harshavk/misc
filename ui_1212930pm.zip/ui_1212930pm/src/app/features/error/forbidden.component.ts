import { Component, ChangeDetectionStrategy } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { MatCardModule } from '@angular/material/card';

@Component({
  standalone: true,
  selector: 'app-forbidden',
  imports: [CommonModule, RouterLink, MatCardModule],
  changeDetection: ChangeDetectionStrategy.OnPush,
  template: `
    <mat-card class="wf-elevate wf-fade-in">
      <mat-card-title>403 – Forbidden</mat-card-title>
      <mat-card-subtitle>
        You don't have permission to access this page.
      </mat-card-subtitle>
      <a routerLink="/dashboard">Go back to Dashboard</a>
    </mat-card>
  `,
})
export class ForbiddenComponent {}
