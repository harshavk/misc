import { Component, ChangeDetectionStrategy, signal, computed, inject, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClientModule } from '@angular/common/http'; // Ensure HTTP is available

// Services & Models
import { AuthService } from '../../core/services/auth.service';
import { DashboardService } from '../../core/services/dashboard.service'; // Import Service
import { Role } from '../../core/models/role.enum';
import { Employee } from '../../core/models/employee'; // Import Model

// Material Imports
import { MatButtonModule } from '@angular/material/button';
import { MatIconModule } from '@angular/material/icon';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatProgressSpinnerModule } from '@angular/material/progress-spinner';
import { MatInputModule } from '@angular/material/input';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatDividerModule } from '@angular/material/divider';
import { MatCardModule } from '@angular/material/card';
import { finalize } from 'rxjs';


@Component({
  selector: 'app-dashboard',
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule, // Needed for fetching JSON
    MatButtonModule,
    MatIconModule,
    MatProgressBarModule,
    MatProgressSpinnerModule,
    MatInputModule,
    MatFormFieldModule,
    MatDividerModule,
    MatCardModule
  ],
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class DashboardComponent implements OnInit {
  private readonly router = inject(Router);
  private readonly auth = inject(AuthService);
  private readonly dashboardService = inject(DashboardService); // Inject Data Service

  // --- State ---
  searchQuery = signal('');
  isLoading = signal(true);
  activeFilter = signal<'All' | 'Starting Soon' | 'In Progress'>('All');
  selectedEmployeeId = signal<string | null>(null);
  activeTab: 'pre' | 'first3' | 'week1' = 'first3';

  // Bulk Mode
  isBulkMode = signal(false);
  selectedIds = signal<Set<string>>(new Set());

  // Role Logic
  userRole = signal<Role>(Role.Manager);
  isManager = computed(() => this.userRole() === Role.Manager);

  readonly employees = signal<Employee[]>([]); // The List
  readonly selectedEmployee = signal<Employee | null>(null); // The Detail View
  private allEmployees = signal<Employee[]>([]);
  readonly isLoadingList = signal(false);   // Loader for Left Panel
  readonly isLoadingDetail = signal(false); // Loader for Center Panel
  readonly error = signal<string | null>(null); // Error Banner

  ngOnInit() {
    this.loadDashboardData();
  }
  // --- 1. LOAD LIST (Based on Role) ---
  loadDashboardData() {
    this.isLoadingList.set(true);
    this.error.set(null);

    // Get Current User Role
    const user = this.auth.currentUser();
    const isMgr = user?.roles.includes(Role.Manager) ?? false;
    this.userRole.set(isMgr ? Role.Manager : Role.Employee);

    this.dashboardService.getEmployees().pipe(
      finalize(() => this.isLoadingList.set(false)) // Runs on success or error
    ).subscribe({
      next: (data) => {
        if (isMgr) {
          // Manager: Show everyone
          this.employees.set(data);
        } else {
          const myProfile = data.find(e => e.id === user?.id || e.email === user?.email);
          this.employees.set(myProfile ? [myProfile] : []);

          // Auto-select themselves
          if (myProfile) this.onEmployeeClick(myProfile.id);
        }
      },
      error: (err) => this.error.set(err.message)
    });
  }

  // --- 2. CLICK HANDLER (Fetch Details) ---
  onEmployeeClick(id: string) {
    this.selectedEmployeeId.set(id); // Highlight visually immediately
    this.isLoadingDetail.set(true);  // Show spinner in center panel

    // Fetch fresh details (mock or real)
    this.dashboardService.getEmployeeById(id).pipe(
      finalize(() => this.isLoadingDetail.set(false))
    ).subscribe({
      next: (details) => {
        if (details) {
          this.selectedEmployee.set(details);
        }
      },
      error: (err) => {
        // Optional: Show snackbar or specific error in center panel
        console.error('Failed to load details', err);
      }
    });
  }

  // Separate method to filter initial view based on role
  private initView(data: Employee[]) {
    if (this.isManager()) {
      this.employees.set(data);
    } else {
      // Mocking 'John Doe' as current user
      const myProfile = data.find(e => e.id === 'E12345');
      this.employees.set(myProfile ? [myProfile] : []);
      if (myProfile) this.selectEmployee(myProfile.id);
    }
  }

  // --- Computed Logic ---

  readonly totalJoiners = computed(() => this.employees().length);

  readonly startingSoonCount = computed(() =>
    this.employees().filter(e => new Date(e.startDate) > new Date()).length
  );

  readonly avgProgress = computed(() => {
    const list = this.employees();
    if (!list.length) return 0;
    const total = list.reduce((sum, emp) => sum + (emp.progress || 0), 0);
    return Math.round(total / list.length);
  });

  readonly filteredEmployees = computed(() => {
    const query = this.searchQuery().toLowerCase();
    const filter = this.activeFilter();
    const all = this.employees();

    return all.filter(emp => {
      const matchesSearch = emp.name.toLowerCase().includes(query) ||
        emp.id.toLowerCase().includes(query);

      let matchesFilter = true;
      if (filter === 'In Progress') matchesFilter = (emp.progress || 0) > 0 && (emp.progress || 0) < 100;
      else if (filter === 'Starting Soon') matchesFilter = new Date(emp.startDate) > new Date();

      if (!this.isManager()) return true;

      return matchesSearch && matchesFilter;
    });
  });

  // readonly selectedEmployee = computed(() =>
  //   this.employees().find(e => e.id === this.selectedEmployeeId()) || null
  // );

  // --- Actions ---

  setFilter(filter: 'All' | 'Starting Soon' | 'In Progress') {
    this.activeFilter.set(filter);
  }

  selectEmployee(id: string) {
    this.selectedEmployeeId.set(id);
  }

  toggleBulkMode() {
    if (!this.isManager()) return;
    this.isBulkMode.update(v => !v);
    this.selectedIds.update(set => { set.clear(); return new Set(set); });
    this.selectedEmployeeId.set(null);
  }

  toggleSelection(id: string, event: Event) {
    event.stopPropagation();
    this.selectedIds.update(set => {
      const newSet = new Set(set);
      if (newSet.has(id)) newSet.delete(id);
      else newSet.add(id);
      return newSet;
    });
  }

  handleNotificationClick(employeeName: string) {
    if (!this.isManager()) return;
    const emp = this.employees().find(e => e.name.includes(employeeName));
    if (emp) {
      this.activeFilter.set('All');
      this.selectedEmployeeId.set(emp.id);
      this.isBulkMode.set(false);
    }
  }

  performQuickAction(actionType: string) {
    let prompt = '';
    const emp = this.selectedEmployee();

    if (this.isManager()) {
      if (this.isBulkMode() && this.selectedIds().size > 0) {
        const names = this.employees()
          .filter(e => this.selectedIds().has(e.id)).map(e => e.name).join(', ');

        switch (actionType) {
          case 'buddy': prompt = `Assign onboarding buddies to: ${names}`; break;
          case 'cloud': prompt = `Request cloud access for: ${names}`; break;
          case 'equipment': prompt = `Order equipment for: ${names}`; break;
          default: prompt = `Help with onboarding for: ${names}`;
        }
      } else if (emp) {
        switch (actionType) {
          case 'buddy': prompt = `Assign an onboarding buddy to ${emp.name}`; break;
          case 'cloud': prompt = `Request cloud access for ${emp.name} (${emp.role})`; break;
          case 'equipment': prompt = `Order standard equipment for ${emp.name}`; break;
          case 'meeting': prompt = `Schedule a 1:1 onboarding sync with ${emp.name}`; break;
        }
      } else {
        prompt = `Start an onboarding task`;
      }
    } else {
      switch (actionType) {
        case 'buddy_contact': prompt = `Who is my onboarding buddy and how do I contact them?`; break;
        case 'it_help': prompt = `I need IT support for my laptop setup.`; break;
        case 'benefits': prompt = `Show me my benefits enrollment status.`; break;
        case 'policies': prompt = `Where can I find the remote work policy?`; break;
      }
    }

    this.router.navigate(['/ally'], { queryParams: { q: prompt } });
  }
}