import { Component, Input, Output, EventEmitter, ChangeDetectionStrategy, OnChanges, SimpleChanges } from '@angular/core';
import { CommonModule } from '@angular/common';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatListModule } from '@angular/material/list';
import { MatDividerModule } from '@angular/material/divider';

interface QuickLink {
  label: string;
  icon: string;
  desc: string;
}

interface Task {
  label: string;
  due: string;
}

@Component({
  selector: 'app-audit-panel',
  standalone: true,
  imports: [CommonModule, MatIconModule, MatButtonModule, MatListModule, MatDividerModule],
  templateUrl: './audit-panel.html',
  styleUrls: ['./audit-panel.css'],
  changeDetection: ChangeDetectionStrategy.OnPush
})
export class AuditPanelComponent implements OnChanges {
  @Input() userName: string = 'User';
  @Input() isManager: boolean = true; // <--- Controls the view mode

  @Output() actionClick = new EventEmitter<string>();

  // --- DATA SOURCES ---

  // 1. MANAGER DATA (Existing)
  private readonly managerLinks: QuickLink[] = [
    { label: 'Workday', icon: 'account_balance_wallet', desc: 'Team Goals & Org' },
    { label: 'AIMS Access', icon: 'vpn_key', desc: 'Identity Management' },
    { label: 'Procurement', icon: 'shopping_cart', desc: 'Order Equipment' },
    { label: 'Develop You', icon: 'school', desc: 'Assign Training' }
  ];

  private readonly managerTasks: Task[] = [
    { label: 'Verify I-9 Documents', due: 'Day 1' },
    { label: 'Set Team Goals', due: 'Day 3' },
    { label: 'Assign Buddy', due: 'Overdue' }
  ];

  // 2. EMPLOYEE DATA (New)
  private readonly employeeLinks: QuickLink[] = [
    { label: 'My Benefits', icon: 'health_and_safety', desc: 'Enrollment (30 Days)' },
    { label: 'Payroll', icon: 'payments', desc: 'View Payslips' },
    { label: 'MyIT Support', icon: 'devices', desc: 'Laptop Issues' },
    { label: 'Develop You', icon: 'school', desc: 'My Training' }
  ];

  private readonly employeeTasks: Task[] = [
    { label: 'Complete I-9', due: 'Day 1' },
    { label: 'Enroll in Benefits', due: 'Day 30' },
    { label: 'Meet Your Buddy', due: 'This Week' }
  ];

  // --- CURRENT VIEW STATE ---
  currentLinks: QuickLink[] = [];
  currentTasks: Task[] = [];
  panelTitle: string = '';

  ngOnChanges(changes: SimpleChanges): void {
    if (changes['isManager'] || changes['userName']) {
      this.updateView();
    }
  }

  private updateView() {
    if (this.isManager) {
      this.panelTitle = 'Manager Toolkit';
      this.currentLinks = this.managerLinks;
      this.currentTasks = this.managerTasks;
    } else {
      this.panelTitle = 'My Resources';
      this.currentLinks = this.employeeLinks;
      this.currentTasks = this.employeeTasks;
    }
  }

  triggerAction(action: string) {
    this.actionClick.emit(action);
  }
}