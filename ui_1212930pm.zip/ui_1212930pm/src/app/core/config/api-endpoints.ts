export const ApiEndpoints = {
    AUTH: {
        LOGIN: '/login'
    },
    EMPLOYEES: {
        GET_ALL: '/employees',
        GET_BY_ID: (id: string) => `/employees/${id}`
    },
    CHAT: {
        SEND_MESSAGE: '/chat'
    }
};