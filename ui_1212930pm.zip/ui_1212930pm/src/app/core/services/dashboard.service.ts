import { Injectable, inject } from '@angular/core';
import { HttpClient, HttpErrorResponse } from '@angular/common/http';
import { Observable, of, throwError } from 'rxjs';
import { catchError, map, delay, shareReplay } from 'rxjs/operators';
import { Employee } from '../models/employee';
import { environment } from '../../../environments/environment';
import { ApiEndpoints } from '../config/api-endpoints';

@Injectable({
    providedIn: 'root'
})
export class DashboardService {
    private readonly http = inject(HttpClient);

    // --- 1. GET ALL EMPLOYEES (List) ---
    getEmployees(): Observable<Employee[]> {

        if (environment.mockConfig.enableDashboard) {
            // MOCK: Load local JSON
            return this.http.get<Employee[]>('assets/data/employees.json').pipe(
                delay(600),
                catchError(this.handleError),
                shareReplay(1)
            );
        } else {
            // REAL API: Base URL + Endpoint Constant
            const url = `${environment.apiBaseUrl}${ApiEndpoints.EMPLOYEES.GET_ALL}`;
            return this.http.get<Employee[]>(url).pipe(
                catchError(this.handleError)
            );
        }
    }

    // --- 2. GET SINGLE EMPLOYEE (Details) ---
    getEmployeeById(id: string): Observable<Employee | undefined> {

        if (environment.mockConfig.enableDashboard) {
            // MOCK: Filter client-side
            return this.http.get<Employee[]>('assets/data/employees.json').pipe(
                delay(400),
                map(employees => employees.find(e => e.id === id)),
                catchError(this.handleError)
            );
        } else {
            // REAL API: Base URL + Dynamic Endpoint
            const url = `${environment.apiBaseUrl}${ApiEndpoints.EMPLOYEES.GET_BY_ID(id)}`;
            return this.http.get<Employee>(url).pipe(
                catchError(this.handleError)
            );
        }
    }

    private handleError(error: HttpErrorResponse) {
        console.error('API Error:', error);
        return throwError(() => new Error('Something went wrong. Please try again.'));
    }
}