import { Injectable, signal, effect, inject } from '@angular/core';
import { DOCUMENT } from '@angular/common';

@Injectable({
    providedIn: 'root'
})
export class ThemeService {
    private readonly document = inject(DOCUMENT);

    // Signal to track state
    readonly isDarkMode = signal<boolean>(false);

    constructor() {
        // 1. Load saved preference or default to system setting
        const saved = localStorage.getItem('theme');
        if (saved) {
            this.isDarkMode.set(saved === 'dark');
        } else {
            const systemDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
            this.isDarkMode.set(systemDark);
        }

        // 2. Apply class whenever signal changes
        effect(() => {
            if (this.isDarkMode()) {
                this.document.body.classList.add('dark-theme');
                localStorage.setItem('theme', 'dark');
            } else {
                this.document.body.classList.remove('dark-theme');
                localStorage.setItem('theme', 'light');
            }
        });
    }

    toggle() {
        this.isDarkMode.update(v => !v);
    }
}