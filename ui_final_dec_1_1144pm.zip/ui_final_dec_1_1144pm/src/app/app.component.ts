import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
  ViewChild,
  ElementRef,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormControl, ReactiveFormsModule, Validators } from '@angular/forms';

import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatChipsModule } from '@angular/material/chips';
import { MatDividerModule } from '@angular/material/divider';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { AiSearchService } from './services/ai-search.service';
import {
  AiSearchResponse,
  ChatHistoryItem,
  ActionResult,
} from './models/ai-search.models';

import { ThreadMessage } from './models/ai-thread.models';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatToolbarModule,
    MatIconModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatListModule,
    MatSnackBarModule,
    MatProgressBarModule,
    MatChipsModule,
    MatDividerModule,
    MatTooltipModule,
    MatSlideToggleModule,
    MatSlideToggleModule,
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AppComponent {
  private ai = inject(AiSearchService);
  private snackBar = inject(MatSnackBar);
  private readonly HTML_TAG_REGEX = /<\/?[a-z][\s\S]*>/i;

  readonly title = 'Onboarding AI Assistant';

  readonly queryControl = new FormControl<string>('', {
    nonNullable: true,
    validators: [Validators.required, Validators.minLength(3)],
  });

  readonly isLoading = signal(false);
  readonly error = signal<string | null>(null);
  readonly actorId = signal<'m001' | 'e001'>('m001');

  // typing indicator for AI
  readonly isAiTyping = signal(false);
  readonly isManager = signal<boolean>(true);

  readonly statusLine = computed(() => {
    if (!this.isLoading()) return '';

    const roleLabel = this.isManager() ? 'Manager' : 'Employee';
    return `Assistant is analyzing for role: ${roleLabel}…`;
  });


  // full chat transcript for current thread
  chatMessages = signal<ThreadMessage[]>([]);

  readonly currentThreadId = signal<string>('onboarding-session-1');
  readonly lastResponse = signal<AiSearchResponse | null>(null);
  // All actions coming from the latest AI response
  readonly suggestedActions = computed<ActionResult[]>(() =>
    this.lastResponse()?.actions ?? []
  );

  // Index of the selected action in the list
  readonly selectedActionIndex = signal<number>(0);

  // Convenience: currently selected action (or null)
  readonly selectedAction = computed<ActionResult | null>(() => {
    const actions = this.suggestedActions();
    if (!actions.length) return null;

    const idx = this.selectedActionIndex();
    return actions[Math.max(0, Math.min(idx, actions.length - 1))];
  });

  readonly chatHistory = signal<ChatHistoryItem[]>([]);
  readonly auditLog = signal<string[]>([]);
  private typingTimer: any = null;
  private threadMessagesStore = new Map<string, ThreadMessage[]>();
  private threadResponseStore = new Map<string, AiSearchResponse>();

  readonly isMockMode = this.ai.isMockMode();
  readonly hasResults = computed(
    () =>
      !!this.lastResponse() &&
      ((this.lastResponse()!.answers?.length ?? 0) > 0 ||
        (this.lastResponse()!.actions?.length ?? 0) > 0),
  );

  @ViewChild('chatThread') private chatThreadRef?: ElementRef<HTMLDivElement>;

  // ------------ helpers ------------
  isRichMessage(msg: ThreadMessage): boolean {
    if (msg.tool_call) {
      return true; // any tool_call => treat as rich content
    }

    if (!msg.content) return false;

    // simple check: string contains HTML-like tags
    return this.HTML_TAG_REGEX.test(msg.content);
  }
  private startTypingEffect(
    aiMessage: ThreadMessage,
    baseMessages: ThreadMessage[]
  ) {
    const fullText = aiMessage.content || '';

    // If this is a rich/HTML message, just show it fully – no typing
    if (this.isRichMessage(aiMessage)) {
      this.chatMessages.set([...baseMessages, aiMessage]);
      this.scrollToBottom();
      this.isAiTyping.set(false);
      return;
    }

    // Working copy that we'll mutate
    let index = 0;
    const speed = 20; // ms per character

    const workingMsg: ThreadMessage = {
      ...aiMessage,
      content: '',
    };

    // Show everything before this AI message + empty bubble for the AI
    this.chatMessages.set([...baseMessages, workingMsg]);
    this.scrollToBottom();

    // Clear any previous timer
    if (this.typingTimer) {
      clearInterval(this.typingTimer);
    }

    this.typingTimer = setInterval(() => {
      index++;

      // update content slice
      const updated: ThreadMessage = {
        ...workingMsg,
        content: fullText.slice(0, index),
      };

      // replace last message in the list with updated one
      this.chatMessages.update(list => {
        const next = [...list];
        next[next.length - 1] = updated;
        return next;
      });

      this.scrollToBottom();

      if (index >= fullText.length) {
        clearInterval(this.typingTimer);
        this.typingTimer = null;
        this.isAiTyping.set(false);
      }
    }, speed);
  }
  private scrollToBottom() {
    // wait for DOM to render
    setTimeout(() => {
      const el = this.chatThreadRef?.nativeElement;
      if (el) {
        el.scrollTop = el.scrollHeight;
      }
    }, 0);
  }

  private withLocalTimestamp(msg: ThreadMessage): ThreadMessage {
    return {
      ...msg,
      localTimestamp: new Date().toISOString(),
    };
  }

  toggleActor() {
    this.actorId.update(a => (a === 'm001' ? 'e001' : 'm001'));
    this.setRole(this.actorId() === 'm001' ? true : false);
  }
  setRole(isManager: boolean) {
    this.isManager.set(isManager);
  }

  // ------------ main send ------------

  submitQuery() {
    this.error.set(null);

    if (this.queryControl.invalid) {
      this.queryControl.markAsTouched();
      this.error.set('Please enter at least 3 characters.');
      return;
    }

    const query = this.queryControl.value.trim();
    if (!query) {
      this.error.set('Query cannot be empty.');
      return;
    }

    // 1) append user message to chat
    const userMsg: ThreadMessage = this.withLocalTimestamp({
      type: 'human',
      content: query,
      tool_call: null,
    });
    this.chatMessages.update((list) => [...list, userMsg]);
    this.scrollToBottom();

    this.isLoading.set(true);
    this.isAiTyping.set(true);

    this.ai
      .search(query, this.currentThreadId(), {
        workflow: 'onboarding',

      }, this.actorId())
      .subscribe({
        next: (res) => {
          // stop spinner but keep "AI is typing" while we think
          this.isLoading.set(false);

          const threadId = res.threadId;

          const fromApi = (res.historyMessages || [])
            .filter(m => (m.type === 'human' || m.type === 'ai') && m.content !== '')
            .map(m => this.withLocalTimestamp(m));

          // Optional: compute delay based on reply size
          const aiMsgsForDelay = fromApi.filter(m => m.type === 'ai');
          const delay = this.getTypingDelayMs
            ? this.getTypingDelayMs(aiMsgsForDelay)
            : 600;

          setTimeout(() => {
            this.lastResponse.set(res);
            this.currentThreadId.set(threadId);

            // --- find last AI message to animate ---
            const lastAiIndex = [...fromApi]
              .map((m, i) => ({ m, i }))
              .reverse()
              .find(x => x.m.type === 'ai')?.i;

            if (lastAiIndex == null) {
              // no AI message – just show everything
              this.chatMessages.set(fromApi);
              this.scrollToBottom();
              this.isAiTyping.set(false);
            } else {
              const base = fromApi.slice(0, lastAiIndex);
              const lastAi = fromApi[lastAiIndex];

              // hide the dot-typing bubble and start char typing
              this.isAiTyping.set(false);
              this.startTypingEffect(lastAi, base);
            }

            // store thread state
            this.threadMessagesStore.set(threadId, this.chatMessages());
            this.threadResponseStore.set(threadId, res);

            const allMsgs = this.chatMessages();
            const msgCount = allMsgs.length;

            const lastMsgPreview =
              [...allMsgs].reverse().find(m => m.type === 'ai' && m.content)?.content ??
              [...allMsgs].reverse().find(m => !!m.content)?.content ??
              res.answers?.[0]?.content ??
              '';

            const previewRaw = this.stripHtml(lastMsgPreview || '');
            const preview =
              previewRaw.length > 80 ? previewRaw.slice(0, 80).trimEnd() + '…' : previewRaw;

            const hint = this.getActivityHint(msgCount);
            const nowIso = new Date().toISOString();

            this.chatHistory.update(items => {
              const others = items.filter(i => i.id !== threadId);
              return [
                {
                  id: threadId,
                  query: res.query,
                  createdAt: nowIso,
                  messagesCount: msgCount,
                  lastPreview: preview,
                  activityHint: hint,
                },
                ...others,
              ];
            });
          }, delay);
        },

        error: (err) => {
          this.isLoading.set(false);
          this.isAiTyping.set(false);
          const msg =
            err?.message || 'Something went wrong while calling the AI API.';
          this.error.set(msg);
          console.error(err);
          this.snackBar.open(msg, 'Dismiss', { duration: 4000 });
        },
      });

    this.queryControl.setValue('');
  }

  onContentLinkClick(msg: ThreadMessage, event: MouseEvent) {
    const target = event.target as HTMLElement | null;
    if (!target) return;

    // Bubble up if the click was inside a link (span inside <a>, etc.)
    const anchor = target.closest('a') as HTMLAnchorElement | null;
    if (!anchor) return;

    const href = anchor.href;
    const label = (anchor.textContent || '').trim() || href;

    const stamp = new Date().toLocaleTimeString();
    const entry = `✓ Link clicked: "${label}" — ${stamp}`;

    this.auditLog.update(list => [entry, ...list]);
    // we let the browser follow the link; no preventDefault()
  }

  onToolPayloadClick(msg: ThreadMessage, tool: any, event: MouseEvent) {
    const target = event.target as HTMLElement | null;
    if (!target) return;

    const anchor = target.closest('a') as HTMLAnchorElement | null;
    if (!anchor) return;

    const href = anchor.href;
    const label =
      (tool?.name as string | undefined)?.replaceAll('_', ' ') ||
      (anchor.textContent || '').trim() ||
      href;

    const stamp = new Date().toLocaleTimeString();
    const entry = `✓ Action: ${label} — ${stamp}`;

    this.auditLog.update(list => [entry, ...list]);
    // again, we don’t block navigation
  }

  private getTypingDelayMs(aiMessages: ThreadMessage[]): number {
    if (!aiMessages.length) {
      return 400; // tiny blip
    }

    const text = aiMessages
      .map(m => this.stripHtml(m.content || ''))
      .join(' ');

    const length = text.length;

    const base = 700;      // min typing time (ms)
    const perChar = 18;    // ms per character
    const maxExtra = 3500; // cap

    const extra = Math.min(length * perChar, maxExtra);
    return base + extra;
  }

  // ENTER to send, SHIFT+ENTER for newline
  onKeydownEnter(event: KeyboardEvent) {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.submitQuery();
    }
  }

  //------------- fresh thread ------------
  // Create a fresh thread and clear current chat area
  startNewChat() {
    const newId = `thread-${Date.now()}`;
    this.currentThreadId.set(newId);
    this.chatMessages.set([]);
    this.lastResponse.set(null);
    this.error.set(null);
    this.isAiTyping.set(false);
    this.queryControl.setValue('');
  }

  // Clear all history + current chat
  clearHistory() {
    this.chatHistory.set([]);
    this.chatMessages.set([]);
    this.lastResponse.set(null);
    this.auditLog.set([]);
    this.error.set(null);
    this.isAiTyping.set(false);

    this.threadMessagesStore.clear();
    this.threadResponseStore.clear();

    this.currentThreadId.set(`thread-${Date.now()}`);
  }

  // ------------ thread switching ------------

  reuseHistoryItem(item: ChatHistoryItem) {
    this.currentThreadId.set(item.id);
    this.error.set(null);
    this.isAiTyping.set(false);
    this.isLoading.set(false);

    const msgs = this.threadMessagesStore.get(item.id);
    if (msgs) {
      this.chatMessages.set(msgs);

      const msgCount = msgs.length;
      const lastMsg =
        [...msgs].reverse().find((m) => m.type === 'ai' && m.content)?.content ??
        [...msgs].reverse().find((m) => !!m.content)?.content ??
        item.lastPreview;

      const previewRaw = this.stripHtml(lastMsg || '');
      const preview =
        previewRaw.length > 80 ? previewRaw.slice(0, 80).trimEnd() + '…' : previewRaw;
      const hint = this.getActivityHint(msgCount);

      // resync preview + activity hint
      this.chatHistory.update((items) =>
        items.map((i) =>
          i.id === item.id
            ? { ...i, messagesCount: msgCount, lastPreview: preview, activityHint: hint }
            : i,
        ),
      );

      this.scrollToBottom();
    } else {
      this.chatMessages.set([]);
    }

    const resp = this.threadResponseStore.get(item.id);
    this.lastResponse.set(resp ?? null);

    this.queryControl.setValue(item.query);
  }

  // ------------ actions & tracking ------------
  // When user clicks an item in the right-panel list
  selectAction(index: number) {
    const actions = this.suggestedActions();
    if (!actions.length) return;
    if (index < 0 || index >= actions.length) return;

    this.selectedActionIndex.set(index);
  }

  // Execute the currently selected action (used by "Execute Next Step")
  executeSelected() {
    const act = this.selectedAction();
    if (!act) return;

    this.triggerAction(act);
  }

  triggerAction(action: ActionResult) {
    if (action.actionType === 'link' && action.url) {
      window.open(action.url, '_blank', 'noopener');
    }

    const time = new Date().toLocaleTimeString();

    this.auditLog.update(list => [
      `✔ ${action.label} — ${time}`,
      ...list,
    ]);
  }


  trackMessage(index: number, msg: ThreadMessage): string {
    return `${msg.type}-${index}-${msg.content?.slice(0, 20)}`;
  }

  trackByHistoryId(_: number, item: ChatHistoryItem) {
    return item.id;
  }

  removeThread(threadId: string) {
    // remove sidebar entry
    this.chatHistory.update((items) =>
      items.filter((i) => i.id !== threadId),
    );

    // remove stored messages
    this.threadMessagesStore.delete(threadId);
    this.threadResponseStore.delete(threadId);

    // if deleting active chat, reset to new
    if (this.currentThreadId() === threadId) {
      this.startNewChat();
    }

    this.snackBar.open('Conversation removed', 'OK', {
      duration: 1800,
    });
  }

  // strip basic HTML tags for preview
  private stripHtml(content: string): string {
    return content ? content.replace(/<[^>]+>/g, '') : '';
  }

  // map message count -> activity label
  private getActivityHint(count: number): 'New' | 'Short' | 'Active' | 'Long' {
    if (count <= 1) return 'New';
    if (count <= 4) return 'Short';
    if (count <= 10) return 'Active';
    return 'Long';
  }

  private extractLinkActionsFromMessages(msgs: ThreadMessage[]): ActionResult[] {
    const actions: ActionResult[] = [];
    const seenUrls = new Set<string>();

    msgs.forEach((m, msgIndex) => {
      if (!m.content) return;

      const html = m.content;
      const regex = /<a\s+[^>]*href="([^"]+)"[^>]*>(.*?)<\/a>/gi;
      let match: RegExpExecArray | null;

      while ((match = regex.exec(html)) !== null) {
        const url = match[1];
        let label = this.stripHtml(match[2] || '').trim();

        if (!url) continue;
        if (!label) label = 'Open link';
        if (seenUrls.has(url)) continue;

        seenUrls.add(url);

        const description = this.stripHtml(html).slice(0, 140);

        actions.push({
          id: `link-${msgIndex}-${actions.length}`,
          label,
          description,
          icon: 'open_in_new',
          category: 'link',
          primary: actions.length === 0,
          confidence: 0.9,
          payload: { url, sourceMessageIndex: msgIndex },
          requiresConfirmation: true,
          actionType: 'link',
          url,
        });
      }
    });

    return actions;
  }

  //Export Chat History
  exportConversation() {
    const messages = this.chatMessages();
    const actions = this.lastResponse()?.actions ?? [];
    const audit = this.auditLog();

    const title = 'Onboarding AI Assistant – Conversation Export';
    const dateStr = new Date().toLocaleString();

    const escapeHtml = (s: string) =>
      (s || '').replace(/[&<>]/g, ch =>
        ({ '&': '&amp;', '<': '&lt;', '>': '&gt;' } as any)[ch] || ch
      );

    const msgsHtml = messages
      .map(m => {
        const role = m.type === 'human' ? 'You' : 'AI assistant';
        const content = m.content || '';
        const isHtml = /<[a-z][\s\S]*>/i.test(content);

        return `
        <div class="msg msg-${m.type}">
          <div class="msg-role">${escapeHtml(role)}</div>
          <div class="msg-body">
            ${isHtml ? content : `<p>${escapeHtml(content)}</p>`}
          </div>
        </div>`;
      })
      .join('\n');

    const actionsHtml = actions
      .map(a => `
      <li>
        <strong>${escapeHtml(a.label)}</strong><br/>
        <span>${escapeHtml(a.description || '')}</span>
      </li>`)
      .join('\n');

    const auditHtml = audit
      .map(entry => `<li>${escapeHtml(entry)}</li>`)
      .join('\n');

    const html = `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8" />
  <title>${escapeHtml(title)}</title>
  <style>
    body {
      font-family: system-ui, -apple-system, BlinkMacSystemFont, 'Segoe UI', sans-serif;
      margin: 24px;
      color: #111827;
    }
    h1 { font-size: 1.4rem; margin-bottom: 4px; }
    h2 { font-size: 1.1rem; margin-top: 20px; border-bottom: 1px solid #e5e7eb; padding-bottom: 4px; }
    .meta { font-size: 0.8rem; color: #6b7280; margin-bottom: 16px; }
    .msg { margin-bottom: 10px; padding: 8px 10px; border-radius: 10px; }
    .msg-human { background: #ecfeff; }
    .msg-ai { background: #fef2f2; }
    .msg-role { font-size: 0.8rem; font-weight: 600; color: #6b7280; margin-bottom: 2px; }
    .msg-body p { margin: 0; }
    ul { padding-left: 1.1rem; }
  </style>
</head>
<body>
  <h1>${escapeHtml(title)}</h1>
  <div class="meta">Exported at ${escapeHtml(dateStr)}</div>

  <h2>Conversation</h2>
  ${msgsHtml || '<p><em>No messages in this conversation.</em></p>'}

  <h2>Suggested actions</h2>
  ${actions.length ? `<ul>${actionsHtml}</ul>` : '<p><em>No actions.</em></p>'}

  <h2>Audit trail</h2>
  ${audit.length ? `<ul>${auditHtml}</ul>` : '<p><em>No audit entries.</em></p>'}
</body>
</html>`;

    const blob = new Blob([html], { type: 'text/html;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');

    const fileNameDate = new Date().toISOString().slice(0, 19).replace(/[:T]/g, '-');
    a.href = url;
    a.download = `onboarding-chat-${fileNameDate}.html`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  }

}
