export const environment = {
  production: true,
  aiApi: {
    baseUrl: 'https://localhost:7152',
    useMock: false,
    timeoutMs: 20000,
  },
};
