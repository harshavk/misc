import {
  MatFormFieldModule
} from "./chunk-RLQXOOLK.js";
import {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
} from "./chunk-BPXQJRSP.js";
import "./chunk-OQLDDXIK.js";
import "./chunk-5EWDFH2O.js";
import "./chunk-5H6MBJA4.js";
import "./chunk-KYP7WMFK.js";
import "./chunk-XYBFVC5N.js";
import "./chunk-42QFQP6S.js";
import "./chunk-N4DOILP3.js";
import "./chunk-GUGIMSVJ.js";
import "./chunk-FHXNRTFX.js";
import "./chunk-7LA4MYMM.js";
import "./chunk-UC72YTJX.js";
import "./chunk-SZYYS24I.js";
import "./chunk-AOQ4RCD5.js";
import "./chunk-WKLQYTUL.js";
import "./chunk-PJVWDKLX.js";
export {
  MAT_ERROR,
  MAT_FORM_FIELD,
  MAT_FORM_FIELD_DEFAULT_OPTIONS,
  MAT_PREFIX,
  MAT_SUFFIX,
  MatError,
  MatFormField,
  MatFormFieldControl,
  MatFormFieldModule,
  MatHint,
  MatLabel,
  MatPrefix,
  MatSuffix,
  getMatFormFieldDuplicatedHintError,
  getMatFormFieldMissingControlError,
  getMatFormFieldPlaceholderConflictError
};
