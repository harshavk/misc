export const environment = {
  production: true,
  aiApi: {
    baseUrl: 'http://localhost:5000/api',
    useMock: true,
    timeoutMs: 20000,
  },
};
