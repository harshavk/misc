import { Injectable, inject } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { map, of, switchMap, delay } from 'rxjs';

import { environment } from '../../environments/environment';
import { AiThreadRequest, AiThreadResponse } from '../models/ai-thread.models';
import {
  ActionResult,
  AnswerResult,
  AiSearchResponse,
} from '../models/ai-search.models';
import { MockScenario } from '../models/mock-ai.models';

@Injectable({ providedIn: 'root' })
export class AiSearchService {
  private http = inject(HttpClient);
  private cfg = environment.aiApi;

  // cache for JSON mocks
  private mockScenarios: MockScenario[] | null = null;

  // ---------------------------------------------------------------------------
  // Public API
  // ---------------------------------------------------------------------------
  search(
    query: string,
    threadId: string,
    metadata: Record<string, unknown> = { workflow: 'onboarding' },
    actor_id?: string,
  ) {
    const payload: AiThreadRequest = {
      message: query,
      thread_id: threadId,
      metadata,
      actor_id: actor_id,
    };

    // 👇 min “typing” time
    const minDelayMs = this.cfg.useMock ? 2000 : 1000;
    const started = Date.now();

    // 1) build an observable that emits the *raw thread*
    const raw$ = !this.cfg.useMock
      ? this.http.post<AiThreadResponse>(`${this.cfg.baseUrl}/chat`, payload)
      : this.loadMocks().pipe(
        switchMap((scenarios) => {
          const scenario = this.pickScenario(query, scenarios);
          const raw = this.buildThreadFromScenario(payload, scenario);
          return of(raw);
        }),
      );

    // 2) map to UI shape + enforce minimum delay
    return raw$.pipe(
      map((raw) => this.mapToUi(query, raw, this.cfg.useMock ? 'mock' : 'python-api')),
      switchMap((ui) => {
        const elapsed = Date.now() - started;
        const remaining = Math.max(0, minDelayMs - elapsed);

        // ensure at least minDelayMs total “thinking” time
        return remaining > 0 ? of(ui).pipe(delay(remaining)) : of(ui);
      }),
    );
  }


  isMockMode(): boolean {
    return this.cfg.useMock;
  }

  // ---------------------------------------------------------------------------
  // Mock loading
  // ---------------------------------------------------------------------------
  private loadMocks() {
    if (this.mockScenarios) {
      return of(this.mockScenarios);
    }

    return this.http
      .get<MockScenario[]>('assets/mock-ai-responses.json')
      .pipe(
        map((data) => {
          this.mockScenarios = data ?? [];
          return this.mockScenarios;
        })
      );
  }

  private pickScenario(query: string, scenarios: MockScenario[]): MockScenario {
    const q = query.toLowerCase();

    // try keyword match
    const match =
      scenarios.find((s) =>
        (s.keywords || []).some((k) => q.includes(k.toLowerCase()))
      ) ||
      // fallback scenario (id or empty keywords)
      scenarios.find((s) => s.id === 'generic-fallback') ||
      scenarios[0];

    return match;
  }

  private buildThreadFromScenario(
    req: AiThreadRequest,
    scenario: MockScenario
  ): AiThreadResponse {
    const now = new Date().toISOString();

    const base = scenario.thread;

    return {
      reply: base.reply,
      thread_id: req.thread_id || base.thread_id || scenario.id,
      messages: [
        // always include the real user input as first message
        {
          type: 'human',
          content: req.message,
          tool_call: null,
        },
        ...base.messages.filter((m) => m.type !== 'human'),
      ],
      timestamp: base.timestamp || now,
    };
  }

  // ---------------------------------------------------------------------------
  // Adapter: raw thread -> UI answer/actions
  // ---------------------------------------------------------------------------
  private mapToUi(
    query: string,
    raw: AiThreadResponse,
    source: 'mock' | 'python-api'
  ): AiSearchResponse {
    const looksHtml = (text: string | null | undefined) =>
      !!text &&
      /<\s*(a|p|ul|ol|li|button|strong|em|div|span)\b/i.test(text);

    const aiMessages = raw.messages.filter((m) => m.type === 'ai');

    const answers: AnswerResult[] = [];

    // 1) Summary card from raw.reply
    if (raw.reply && raw.reply.trim().length > 0) {
      answers.push({
        id: 'ans-summary',
        title: 'AI reply',
        content: raw.reply,
        type: 'summary',
        isHtml: looksHtml(raw.reply),
        confidence: 0.9,
        tags: [],
        references: [],
      });
    }

    // 2) One answer per AI message (all titled "AI reply")
    aiMessages.forEach((m, idx) => {
      const isDuplicate =
        raw.reply &&
        raw.reply.trim().length > 0 &&
        m.content.trim() === raw.reply.trim();

      if (isDuplicate) return;

      answers.push({
        id: `ans-msg-${idx}`,
        title: 'AI reply',
        content: m.content,
        type: 'explanation',
        isHtml: looksHtml(m.content),
        confidence: 0.85,
        tags: [],
        references: [],
      });
    });

    // 3) Actions from tool_call only
    const actions: ActionResult[] = raw.messages
      .filter((m) => !!m.tool_call)
      .map((m, idx) => {
        const tc = m.tool_call || {};

        const name =
          tc.name ||
          tc.action ||
          tc.type ||
          'Suggested action';

        const description =
          tc.description ||
          'Action suggested by the AI based on this conversation.';

        const lowerName = String(name).toLowerCase();
        let category: ActionResult['category'] = 'other';
        if (lowerName.includes('workday')) category = 'hr';
        else if (
          lowerName.includes('equipment') ||
          lowerName.includes('access')
        )
          category = 'access';
        else if (lowerName.includes('email')) category = 'email';
        else if (
          lowerName.includes('navigate') ||
          lowerName.includes('open')
        )
          category = 'navigation';

        return {
          id: `act-${idx}`,
          label: name,
          description,
          icon: 'bolt',
          category,
          primary: idx === 0,
          confidence: 0.9,
          payload: tc,
          requiresConfirmation: true,
          confirmLabel: 'Execute',
          url: tc.url,
          actionType: tc.url ? 'link' : 'workflow',
        };
      });

    // 4) Final UI response
    return {
      id: `${raw.thread_id}:${raw.timestamp}`,
      query,
      createdAt: raw.timestamp,
      answers,
      actions,
      meta: {
        latencyMs: 0,
        model: 'thread-api-mock',
        source,
      },
      threadId: raw.thread_id,
      historyMessages: raw.messages,
    };
  }
}
