export interface ChatHistoryItem {
    id: string;
    query: string;
    createdAt: string;
    answersCount: number;
    actionsCount: number;
}
