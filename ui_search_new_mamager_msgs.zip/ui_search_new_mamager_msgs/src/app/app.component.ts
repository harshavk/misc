import {
  ChangeDetectionStrategy,
  Component,
  computed,
  inject,
  signal,
  ViewChild,
  ElementRef,
} from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormControl, ReactiveFormsModule, Validators } from '@angular/forms';

import { MatToolbarModule } from '@angular/material/toolbar';
import { MatIconModule } from '@angular/material/icon';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatInputModule } from '@angular/material/input';
import { MatListModule } from '@angular/material/list';
import { MatSnackBar, MatSnackBarModule } from '@angular/material/snack-bar';
import { MatProgressBarModule } from '@angular/material/progress-bar';
import { MatChipsModule } from '@angular/material/chips';
import { MatDividerModule } from '@angular/material/divider';
import { MatTooltipModule } from '@angular/material/tooltip';
import { MatSlideToggleModule } from '@angular/material/slide-toggle';
import { AiSearchService } from './services/ai-search.service';
import {
  AiSearchResponse,
  ChatHistoryItem,
  ActionResult,
} from './models/ai-search.models';
//import { AnswerResultCardComponent } from './components/answer-result-card/answer-result-card.component';
import { ActionResultItemComponent } from './components/action-result-item/action-result-item.component';
import { ThreadMessage } from './models/ai-thread.models';

@Component({
  selector: 'app-root',
  standalone: true,
  imports: [
    CommonModule,
    ReactiveFormsModule,
    MatToolbarModule,
    MatIconModule,
    MatButtonModule,
    MatFormFieldModule,
    MatInputModule,
    MatListModule,
    MatSnackBarModule,
    MatProgressBarModule,
    MatChipsModule,
    MatDividerModule,
    MatTooltipModule,
    MatSlideToggleModule,
    MatSlideToggleModule,
    //AnswerResultCardComponent,
    ActionResultItemComponent,
  ],
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss'],
  changeDetection: ChangeDetectionStrategy.OnPush,
})
export class AppComponent {
  private ai = inject(AiSearchService);
  private snackBar = inject(MatSnackBar);

  readonly title = 'Onboarding AI Assistant';

  readonly queryControl = new FormControl<string>('', {
    nonNullable: true,
    validators: [Validators.required, Validators.minLength(3)],
  });

  readonly isLoading = signal(false);
  readonly error = signal<string | null>(null);
  readonly actorId = signal<'m001' | 'e001'>('m001');

  // typing indicator for AI
  readonly isAiTyping = signal(false);

  // full chat transcript for current thread
  chatMessages = signal<ThreadMessage[]>([]);

  readonly currentThreadId = signal<string>('onboarding-session-1');
  readonly lastResponse = signal<AiSearchResponse | null>(null);

  readonly chatHistory = signal<ChatHistoryItem[]>([]);
  readonly auditLog = signal<string[]>([]);

  private threadMessagesStore = new Map<string, ThreadMessage[]>();
  private threadResponseStore = new Map<string, AiSearchResponse>();

  readonly isMockMode = this.ai.isMockMode();
  readonly hasResults = computed(
    () =>
      !!this.lastResponse() &&
      ((this.lastResponse()!.answers?.length ?? 0) > 0 ||
        (this.lastResponse()!.actions?.length ?? 0) > 0),
  );

  readonly suggestedActions = computed<ActionResult[]>(() => {
    const res = this.lastResponse();
    if (!res) return [];

    const base = res.actions ?? [];
    const fromLinks = this.extractLinkActionsFromMessages(
      res.historyMessages ?? [],
    );

    // de-dupe by url if backend also sent link actions
    const seen = new Set(
      base
        .map((a) => a.url)
        .filter((u): u is string => !!u),
    );

    const extras = fromLinks.filter((a) =>
      a.url ? !seen.has(a.url) : true,
    );

    return [...base, ...extras];
  });

  @ViewChild('chatThread') private chatThreadRef?: ElementRef<HTMLDivElement>;

  // ------------ helpers ------------

  private scrollToBottom() {
    // wait for DOM to render
    setTimeout(() => {
      const el = this.chatThreadRef?.nativeElement;
      if (el) {
        el.scrollTop = el.scrollHeight;
      }
    }, 0);
  }

  private withLocalTimestamp(msg: ThreadMessage): ThreadMessage {
    return {
      ...msg,
      localTimestamp: new Date().toISOString(),
    };
  }

  toggleActor() {
    this.actorId.update(a => (a === 'm001' ? 'e001' : 'm001'));
  }

  // ------------ main send ------------

  submitQuery() {
    this.error.set(null);

    if (this.queryControl.invalid) {
      this.queryControl.markAsTouched();
      this.error.set('Please enter at least 3 characters.');
      return;
    }

    const query = this.queryControl.value.trim();
    if (!query) {
      this.error.set('Query cannot be empty.');
      return;
    }

    // 1) append user message to chat
    const userMsg: ThreadMessage = this.withLocalTimestamp({
      type: 'human',
      content: query,
      tool_call: null,
    });
    this.chatMessages.update((list) => [...list, userMsg]);
    this.scrollToBottom();

    this.isLoading.set(true);
    this.isAiTyping.set(true);

    this.ai
      .search(query, this.currentThreadId(), {
        workflow: 'onboarding',
        actor_id: this.actorId()
      })
      .subscribe({
        next: (res) => {
          this.isLoading.set(false);
          this.isAiTyping.set(false);
          this.lastResponse.set(res);
          this.currentThreadId.set(res.threadId);

          const threadId = res.threadId;

          // ✅ Rebuild chat from API history every time
          const fromApi = (res.historyMessages || [])
            // optional: hide pure system messages in the UI
            .filter(m => m.type === 'human' || m.type === 'ai')
            .map(m => this.withLocalTimestamp(m));

          this.chatMessages.set(fromApi);
          this.scrollToBottom();

          // persist per-thread state
          this.threadMessagesStore.set(threadId, fromApi);
          this.threadResponseStore.set(threadId, res);

          const allMsgs = fromApi;
          const msgCount = allMsgs.length;

          // last message preview for left sidebar
          const lastMsg =
            [...allMsgs].reverse().find(m => m.type === 'ai' && m.content)?.content ??
            [...allMsgs].reverse().find(m => !!m.content)?.content ??
            res.answers?.[0]?.content ??
            '';

          const previewRaw = this.stripHtml(lastMsg || '');
          const preview =
            previewRaw.length > 80
              ? previewRaw.slice(0, 80).trimEnd() + '…'
              : previewRaw;

          const hint = this.getActivityHint(msgCount);
          const nowIso = new Date().toISOString();

          this.chatHistory.update(items => {
            const others = items.filter(i => i.id !== threadId);
            return [
              {
                id: threadId,
                query: res.query,
                createdAt: nowIso,
                messagesCount: msgCount,
                lastPreview: preview,
                activityHint: hint,
              },
              ...others,
            ];
          });
        },

        error: (err) => {
          this.isLoading.set(false);
          this.isAiTyping.set(false);
          const msg =
            err?.message || 'Something went wrong while calling the AI API.';
          this.error.set(msg);
          console.error(err);
          this.snackBar.open(msg, 'Dismiss', { duration: 4000 });
        },
      });

    this.queryControl.setValue('');
  }


  // ENTER to send, SHIFT+ENTER for newline
  onKeydownEnter(event: KeyboardEvent) {
    if (event.key === 'Enter' && !event.shiftKey) {
      event.preventDefault();
      this.submitQuery();
    }
  }

  //------------- fresh thread ------------
  // Create a fresh thread and clear current chat area
  startNewChat() {
    const newId = `thread-${Date.now()}`;
    this.currentThreadId.set(newId);
    this.chatMessages.set([]);
    this.lastResponse.set(null);
    this.error.set(null);
    this.isAiTyping.set(false);
    this.queryControl.setValue('');
  }

  // Clear all history + current chat
  clearHistory() {
    this.chatHistory.set([]);
    this.chatMessages.set([]);
    this.lastResponse.set(null);
    this.auditLog.set([]);
    this.error.set(null);
    this.isAiTyping.set(false);

    this.threadMessagesStore.clear();
    this.threadResponseStore.clear();

    this.currentThreadId.set(`thread-${Date.now()}`);
  }

  // ------------ thread switching ------------

  reuseHistoryItem(item: ChatHistoryItem) {
    this.currentThreadId.set(item.id);
    this.error.set(null);
    this.isAiTyping.set(false);
    this.isLoading.set(false);

    const msgs = this.threadMessagesStore.get(item.id);
    if (msgs) {
      this.chatMessages.set(msgs);

      const msgCount = msgs.length;
      const lastMsg =
        [...msgs].reverse().find((m) => m.type === 'ai' && m.content)?.content ??
        [...msgs].reverse().find((m) => !!m.content)?.content ??
        item.lastPreview;

      const previewRaw = this.stripHtml(lastMsg || '');
      const preview =
        previewRaw.length > 80 ? previewRaw.slice(0, 80).trimEnd() + '…' : previewRaw;
      const hint = this.getActivityHint(msgCount);

      // resync preview + activity hint
      this.chatHistory.update((items) =>
        items.map((i) =>
          i.id === item.id
            ? { ...i, messagesCount: msgCount, lastPreview: preview, activityHint: hint }
            : i,
        ),
      );

      this.scrollToBottom();
    } else {
      this.chatMessages.set([]);
    }

    const resp = this.threadResponseStore.get(item.id);
    this.lastResponse.set(resp ?? null);

    this.queryControl.setValue(item.query);
  }

  // ------------ actions & tracking ------------

  triggerAction(action: ActionResult) {
    if (action.actionType === 'link' && action.url) {
      window.open(action.url, '_blank', 'noopener');
    } else {
      console.log('Execute workflow action:', action.payload || action.label);
    }

    const log = `Action: ${action.label}`;
    this.auditLog.update((list) => [log, ...list]);
    this.snackBar.open(`Mock action executed: ${action.label}`, 'OK', {
      duration: 2500,
    });
  }

  trackMessage(index: number, msg: ThreadMessage): string {
    return `${msg.type}-${index}-${msg.content?.slice(0, 20)}`;
  }

  trackByHistoryId(_: number, item: ChatHistoryItem) {
    return item.id;
  }

  removeThread(threadId: string) {
    // remove sidebar entry
    this.chatHistory.update((items) =>
      items.filter((i) => i.id !== threadId),
    );

    // remove stored messages
    this.threadMessagesStore.delete(threadId);
    this.threadResponseStore.delete(threadId);

    // if deleting active chat, reset to new
    if (this.currentThreadId() === threadId) {
      this.startNewChat();
    }

    this.snackBar.open('Conversation removed', 'OK', {
      duration: 1800,
    });
  }

  // strip basic HTML tags for preview
  private stripHtml(content: string): string {
    return content ? content.replace(/<[^>]+>/g, '') : '';
  }

  // map message count -> activity label
  private getActivityHint(count: number): 'New' | 'Short' | 'Active' | 'Long' {
    if (count <= 1) return 'New';
    if (count <= 4) return 'Short';
    if (count <= 10) return 'Active';
    return 'Long';
  }

  private extractLinkActionsFromMessages(msgs: ThreadMessage[]): ActionResult[] {
    const actions: ActionResult[] = [];
    const seenUrls = new Set<string>();

    msgs.forEach((m, msgIndex) => {
      if (!m.content) return;

      const html = m.content;
      const regex = /<a\s+[^>]*href="([^"]+)"[^>]*>(.*?)<\/a>/gi;
      let match: RegExpExecArray | null;

      while ((match = regex.exec(html)) !== null) {
        const url = match[1];
        let label = this.stripHtml(match[2] || '').trim();

        if (!url) continue;
        if (!label) label = 'Open link';
        if (seenUrls.has(url)) continue;

        seenUrls.add(url);

        const description = this.stripHtml(html).slice(0, 140);

        actions.push({
          id: `link-${msgIndex}-${actions.length}`,
          label,
          description,
          icon: 'open_in_new',
          category: 'link',
          primary: actions.length === 0,
          confidence: 0.9,
          payload: { url, sourceMessageIndex: msgIndex },
          requiresConfirmation: true,
          actionType: 'link',
          url,
        });
      }
    });

    return actions;
  }
}
